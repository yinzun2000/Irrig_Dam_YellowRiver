#will read water balance related info
source('lib/lib_wb.R')

var <-  c('et','evp','tsp','etp','tspp','int','sm','run','dra')
irr <-  c('ni','ir','fi')
reg <-  c('cn','yz','yl')
freq    <-  c('m','a','c')

#mean value
#ORCHIDEE first var*irr
for (i in 1:length(var))
for (j in 1:length(irr))
{
    #read total mean, et.t.oc, etc
    eval(parse(text=
       paste0(var[i],'.t.',irr[j],' <-
           as.matrix(read.table(\'tab/wb/',var[i],'.t.',irr[j],'\'))')))

    #read  spatial annual mean, monthly mean, and seasonal
    for (k in 1:length(reg))
    for (l in 1:length(freq))
        eval(parse(text=
           paste0(var[i],'.',reg[k],'.',freq[l],'.',irr[j],' <-
               as.matrix(read.table(\'tab/wb/',var[i],'.',reg[k],'.',freq[l],'.',irr[j],'\'))')))

    #read monthly trend
    #if (var[i] != 'tspp')
    #{
    #  eval(parse(text=
    #     paste0('tr.p.',var[i],'.m.',irr[j],' <-
    #         as.matrix(read.table(\'tab/tr.p.',var[i],'.m.',irr[j],'\'))')))
    #  eval(parse(text=
    #     paste0('tr.k.',var[i],'.m.',irr[j],' <-
    #         as.matrix(read.table(\'tab/tr.k.',var[i],'.m.',irr[j],'\'))')))
    #}
}
