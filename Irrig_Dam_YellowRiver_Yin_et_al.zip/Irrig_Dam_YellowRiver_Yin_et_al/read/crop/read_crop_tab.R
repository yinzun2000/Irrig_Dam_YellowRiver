#read some data fast from tab/

ReadTable   <-  function(filei,ncol,nrow,len){
    output  <-  array(0,dim=c(ncol,nrow,len))
    v.tmp   <-  as.matrix(read.table(filei))

    for (i in 1:len)
        output[,,i] <-  v.tmp[,(nrow*(i-1)+1):(nrow*i)]

    return(output)
}

#irr crop data

n.lons  <-  132
n.lats  <-  76
ncrop   <-  3


irr.crop.t.ir   <-  ReadTable('tab/irr.crop.t.ir',n.lons,n.lats,ncrop)
irr.crop.t.fi   <-  ReadTable('tab/irr.crop.t.fi',n.lons,n.lats,ncrop)

irr.crop.cn.a.ir    <-  as.matrix(read.table('tab/irr.crop.cn.a.ir'))
irr.crop.cn.a.fi    <-  as.matrix(read.table('tab/irr.crop.cn.a.fi'))
irr.crop.yz.a.ir    <-  as.matrix(read.table('tab/irr.crop.yz.a.ir'))
irr.crop.yz.a.fi    <-  as.matrix(read.table('tab/irr.crop.yz.a.fi'))
irr.crop.yl.a.ir    <-  as.matrix(read.table('tab/irr.crop.yl.a.ir'))
irr.crop.yl.a.fi    <-  as.matrix(read.table('tab/irr.crop.yl.a.fi'))

irr.crop.cn.m.ir    <-  as.matrix(read.table('tab/irr.crop.cn.m.ir'))
irr.crop.cn.m.fi    <-  as.matrix(read.table('tab/irr.crop.cn.m.fi'))
irr.crop.yz.m.ir    <-  as.matrix(read.table('tab/irr.crop.yz.m.ir'))
irr.crop.yz.m.fi    <-  as.matrix(read.table('tab/irr.crop.yz.m.fi'))
irr.crop.yl.m.ir    <-  as.matrix(read.table('tab/irr.crop.yl.m.ir'))
irr.crop.yl.m.fi    <-  as.matrix(read.table('tab/irr.crop.yl.m.fi'))

yie.crop.t.oc   <-  ReadTable('tab/yie.crop.t.oc',n.lons,n.lats,ncrop)
yie.crop.t.ni   <-  ReadTable('tab/yie.crop.t.ni',n.lons,n.lats,ncrop)
yie.crop.t.ir   <-  ReadTable('tab/yie.crop.t.ir',n.lons,n.lats,ncrop)
yie.crop.t.fi   <-  ReadTable('tab/yie.crop.t.fi',n.lons,n.lats,ncrop)

yie.crop.cn.a.oc    <-  as.matrix(read.table('tab/yie.crop.cn.a.oc'))
yie.crop.cn.a.ni    <-  as.matrix(read.table('tab/yie.crop.cn.a.ni'))
yie.crop.cn.a.ir    <-  as.matrix(read.table('tab/yie.crop.cn.a.ir'))
yie.crop.cn.a.fi    <-  as.matrix(read.table('tab/yie.crop.cn.a.fi'))


