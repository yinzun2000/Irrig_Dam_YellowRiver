#In this script we will read monthly ET data from simulation
#from 1982-2011
#the units are mm.d-1
#et: total ET
#evp: evaporation
#tsp: transpiration
#etp: potential ET corrected 
#int: interception
#ets: sublimation

#since the period of comparison is 1982-2011, nothing changed compared with
#read_sm_m_orc.R

library('RNetCDF')
source('../../lib_vyin/rlib_vyin.R')
source('lib/lib_et.R')

num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)

nvm <-  15

t.s <-  1
t.c <-  360

#irr <-  c('oc','ni','fi','ir')
irr <-  c('ni','fi','ir')

var <-  'et'

id  <-  'evap'

reg <-  c('cn','yz','yl')

# time series
time.m  =   seq(as.Date('1982-01-15'),as.Date('2011-12-15'),by='months')
time.a  =   seq(as.Date('1982-01-01'),as.Date('2011-01-01'),by='years')

len.m   <-  length(time.m)
len.a   <-  length(time.a)

for (i in 1:length(irr))
for (j in 1: length(var))
{
    #read the data
    #et.m.oc <-  ReadET('evap','M','oc')
    eval(parse(text=
        paste0(var[j],'.m.',irr[i],' <-
            ReadET(\'',id[j],'\',\'M\',\'',irr[i],'\',t.s,t.c)')))

    #mask cn
    eval(parse(text=
               paste0(var[j],'.m.',irr[i],'[cnland < .5]  <-  NA')))

    #change unit from mm.d-1 to mm.mon-1

    for (yr in 1:len.a)
    for (mon in 1:12)
        eval(parse(text=
            paste0(var[j],'.m.',irr[i],'[,,12*(yr-1)+mon]    <- ',
                var[j],'.m.',irr[i],'[,,12*(yr-1)+mon]*num.day[mon]')))

    #calculate annual averaged value [mm.yr-1]
    eval(parse(text=
        paste0(var[j],'.a.',irr[i],' <-
               AnnualAverage(',var[j],'.m.',irr[i],',len.a)*12')))

    #get total mean value [mm.yr-1]
    eval(parse(text=
        paste0(var[j],'.t.',irr[i],' <-
            apply(',var[j],'.a.',irr[i],',c(1,2),mean,na.rm=T)')))

    #get total seasonal mean data [mm.yr-1]
    eval(parse(text=
        paste0(var[j],'.c.',irr[i],' <-
            SeasonalAverage(',var[j],'.m.',irr[i],',len.a)')))

    #get spatial mean annual and monthly data
    for (k in 1:length(reg))
    {
        eval(parse(text=
            paste0(var[j],'.',reg[k],'.a.',irr[i],' <-
                SpatialAverage(id.',reg[k],',',var[j],'.a.',irr[i],',bmap,len.a)')))

        eval(parse(text=
            paste0(var[j],'.',reg[k],'.m.',irr[i],' <-
                SpatialAverage(id.',reg[k],',',var[j],'.m.',irr[i],',bmap,len.m)')))

        eval(parse(text=
            paste0(var[j],'.',reg[k],'.c.',irr[i],' <-
                SeasonalAverage1D(',var[j],'.',reg[k],'.m.',irr[i],',len.a)')))
    }

}
