#will read ET related info
source('lib/lib_et.R')

n.lat <-  length(lats)
Read3D  <-  function(filei,nlat){
  #read 3D matrix from txt file: [lon,lat,other]
  #filei: input file name
  #nlat: number of lat 
  val.tmp <-  as.matrix(read.table(filei))

  nD  <-  dim(val.tmp)[2]/nlat
  val <-  array(NA,dim=c(dim(val.tmp)[1],nlat,nD))

  for (i in 1:nD)
    val[,,i]  <-  val.tmp[,(nlat*(i-1)+1):(nlat*i)]

  return(val)
}


var.orc <-  c('et','evp','tsp','int','etp','ets')
var.gl  <-  c('et','evp','tsp','int','etp','ets','etw')
var <-  'et'
#irr <-  c('oc','ni','ir','fi')
irr <-  c('ni','ir','fi')
dat <-  c('gl','mp','ut','pk')
reg <-  c('cn','yz','yl')
freq    <-  c('m','a','c')
ind <-  c('cor','p','rmse','sb','sdsd','lcs','dif')

#mean value
#ORCHIDEE first var*irr
for (i in 1:length(var.orc))
for (j in 1:length(irr))
{
    #read total mean, et.t.oc, etc
    eval(parse(text=
       paste0(var.orc[i],'.t.',irr[j],' <-
           as.matrix(read.table(\'tab/',var.orc[i],'.t.',irr[j],'\'))')))

    #read  spatial annual mean, monthly mean, and seasonal
    for (k in 1:length(reg))
    for (l in 1:length(freq))
        eval(parse(text=
           paste0(var.orc[i],'.',reg[k],'.',freq[l],'.',irr[j],' <-
               as.matrix(read.table(\'tab/',var.orc[i],'.',reg[k],'.',freq[l],'.',irr[j],'\'))')))

    #read monthly trend
    eval(parse(text=
       paste0('tr.p.',var.orc[i],'.m.',irr[j],' <-
           as.matrix(read.table(\'tab/tr.p.',var.orc[i],'.m.',irr[j],'\'))')))
    eval(parse(text=
       paste0('tr.k.',var.orc[i],'.m.',irr[j],' <-
           as.matrix(read.table(\'tab/tr.k.',var.orc[i],'.m.',irr[j],'\'))')))
}

#GLEAM 
for (i in 1:length(var.gl))
{
    #read total mean, et.t.oc, etc
    eval(parse(text=
       paste0(var.gl[i],'.t.',dat[1],' <-
           as.matrix(read.table(\'tab/',var.gl[i],'.t.',dat[1],'\'))')))

    #read  spatial annual mean, monthly mean, and seasonal
    for (k in 1:length(reg))
    for (l in 1:length(freq))
        eval(parse(text=
           paste0(var.gl[i],'.',reg[k],'.',freq[l],'.',dat[1],' <-
               as.matrix(read.table(\'tab/',var.gl[i],'.',reg[k],'.',freq[l],'.',dat[1],'\'))')))

    #read monthly trend
    if (var.gl[i] != 'etw')
    {
      eval(parse(text=
         paste0('tr.p.',var.gl[i],'.m.',dat[1],' <-
             as.matrix(read.table(\'tab/tr.p.',var.gl[i],'.m.',dat[1],'\'))')))
      eval(parse(text=
         paste0('tr.k.',var.gl[i],'.m.',dat[1],' <-
             as.matrix(read.table(\'tab/tr.k.',var.gl[i],'.m.',dat[1],'\'))')))
    }
}

#other ET product
for (i in 1:length(var))
for (j in 2:length(dat))
{
  #read total mean,  etc
  eval(parse(text=
     paste0(var[i],'.t.',dat[j],' <-
         as.matrix(read.table(\'tab/',var[i],'.t.',dat[j],'\'))')))

  for (k in 1:length(reg))
  for (l in 1:length(freq))
      eval(parse(text=
         paste0(var[i],'.',reg[k],'.',freq[l],'.',dat[j],' <-
             as.matrix(read.table(\'tab/',var[i],'.',reg[k],'.',freq[l],'.',dat[j],'\'))')))

  #read monthly trend
  eval(parse(text=
     paste0('tr.p.',var[i],'.m.',dat[j],' <-
         as.matrix(read.table(\'tab/tr.p.',var[i],'.m.',dat[j],'\'))')))
  eval(parse(text=
     paste0('tr.k.',var[i],'.m.',dat[j],' <-
         as.matrix(read.table(\'tab/tr.k.',var[i],'.m.',dat[j],'\'))')))
}

#compare

for (i in 1:length(irr))
for (j in 1:length(dat))
for (k in 1:length(ind))
{
    if (dat[j] == 'gl')
    {
        var.tmp <-  var.orc
    } else
    {
        var.tmp <-  'et'
    }

    for (l in 1:length(var.tmp))
    {
        if (ind[k] != 'dif')
        {
            eval(parse(text=
               paste0(ind[k],'.',var.tmp[l],'.m.',dat[j],'.',irr[i],' <-
                   as.matrix(read.table(\'tab/',ind[k],'.',var.tmp[l],'.m.',dat[j],'.',irr[i],'\'))')))
        } else
            eval(parse(text=
               paste0(ind[k],'.',var.tmp[l],'.t.',dat[j],'.',irr[i],' <-
                   as.matrix(read.table(\'tab/',ind[k],'.',var.tmp[l],'.t.',dat[j],'.',irr[i],'\'))')))
    }
}
