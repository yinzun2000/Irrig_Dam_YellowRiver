# This script will read monthly ET data from GLEAM v3.2a
# period: 1982-2014
# including:
# et:   total evaporation [mm.d-1]
# tsp:  transpiration [mm.d-1]
# evp:  bare soil evaporation [mm.d-1]
# int:  interception loss [mm.d-1]
# etp:  potential evaporation [mm.d-1]
# ets:  snow sublimation [mm.d-1]
# etw:  open water evaporation [mm.d-1]


library('RNetCDF')
source('lib/lib_et.R')

num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)

# time series
time.m  =   seq(as.Date('1982-01-15'),as.Date('2014-12-15'),by='months')
time.a  =   seq(as.Date('1982-01-01'),as.Date('2014-01-01'),by='years')

len.m   <-  length(time.m)
len.a   <-  length(time.a)

# total evaporation
id  <-  'E'
et.m.gl <-  ReadGLEAM(id)

# transpiration 
id  <-  'Et'
tsp.m.gl    <-  ReadGLEAM(id)

# bare soil evaporation
id  <-  'Eb'
evp.m.gl    <-  ReadGLEAM(id)

# interception loss 
id  <-  'Ei'
int.m.gl    <-  ReadGLEAM(id)

#  potential evaporation
id  <-  'Ep'
etp.m.gl    <-  ReadGLEAM(id)

# snow sublimation 
id  <-  'Es'
ets.m.gl    <-  ReadGLEAM(id)

# open water evaporation
id  <-  'Ew'
etw.m.gl    <-  ReadGLEAM(id)

et.m.gl[cnland < .5]    <-  NA
tsp.m.gl[cnland < .5]   <-  NA
evp.m.gl[cnland < .5]   <-  NA
int.m.gl[cnland < .5]   <-  NA
etp.m.gl[cnland < .5]   <-  NA
ets.m.gl[cnland < .5]   <-  NA
etw.m.gl[cnland < .5]   <-  NA

#unit from mm.d-1 to mm.mon-1
for (yr in 1:len.a)
for (mon in 1:12)
{
    et.m.gl[,,12*(yr-1)+mon]    <-  et.m.gl[,,12*(yr-1)+mon]*num.day[mon]
    tsp.m.gl[,,12*(yr-1)+mon]   <-  tsp.m.gl[,,12*(yr-1)+mon]*num.day[mon]
    evp.m.gl[,,12*(yr-1)+mon]   <-  evp.m.gl[,,12*(yr-1)+mon]*num.day[mon]
    int.m.gl[,,12*(yr-1)+mon]   <-  int.m.gl[,,12*(yr-1)+mon]*num.day[mon]
    etp.m.gl[,,12*(yr-1)+mon]   <-  etp.m.gl[,,12*(yr-1)+mon]*num.day[mon]
    ets.m.gl[,,12*(yr-1)+mon]   <-  ets.m.gl[,,12*(yr-1)+mon]*num.day[mon]
    etw.m.gl[,,12*(yr-1)+mon]   <-  etw.m.gl[,,12*(yr-1)+mon]*num.day[mon]
}

#get annual averaged data [mm.yr-1]
et.a.gl     <-  AnnualAverage(et.m.gl,len.a)*12
tsp.a.gl    <-  AnnualAverage(tsp.m.gl,len.a)*12
evp.a.gl    <-  AnnualAverage(evp.m.gl,len.a)*12
int.a.gl    <-  AnnualAverage(int.m.gl,len.a)*12
etp.a.gl    <-  AnnualAverage(etp.m.gl,len.a)*12
ets.a.gl    <-  AnnualAverage(ets.m.gl,len.a)*12
etw.a.gl    <-  AnnualAverage(etw.m.gl,len.a)*12

#get total mean data
et.t.gl     <-  apply(et.a.gl,c(1,2),mean,na.rm=T)
tsp.t.gl    <-  apply(tsp.a.gl,c(1,2),mean,na.rm=T)
evp.t.gl    <-  apply(evp.a.gl,c(1,2),mean,na.rm=T)
int.t.gl    <-  apply(int.a.gl,c(1,2),mean,na.rm=T)
etp.t.gl    <-  apply(etp.a.gl,c(1,2),mean,na.rm=T)
ets.t.gl    <-  apply(ets.a.gl,c(1,2),mean,na.rm=T)
etw.t.gl    <-  apply(etw.a.gl,c(1,2),mean,na.rm=T)

#write out
write.table(et.t.gl,'tab/et.t.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.t.gl,'tab/tsp.t.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.t.gl,'tab/evp.t.gl',col.names=F,row.names=F,sep='\t')
write.table(int.t.gl,'tab/int.t.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.t.gl,'tab/etp.t.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.t.gl,'tab/ets.t.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.t.gl,'tab/etw.t.gl',col.names=F,row.names=F,sep='\t')

#get total seasonal mean data
et.c.gl     <-  SeasonalAverage(et.m.gl,len.a)
tsp.c.gl    <-  SeasonalAverage(tsp.m.gl,len.a)
evp.c.gl    <-  SeasonalAverage(evp.m.gl,len.a)
int.c.gl    <-  SeasonalAverage(int.m.gl,len.a)
etp.c.gl    <-  SeasonalAverage(etp.m.gl,len.a)
ets.c.gl    <-  SeasonalAverage(ets.m.gl,len.a)
etw.c.gl    <-  SeasonalAverage(etw.m.gl,len.a)

#get spatial mean annual and monthly data
et.cn.a.gl  <-  SpatialAverage(-1,et.a.gl,bmap,len.a)
tsp.cn.a.gl <-  SpatialAverage(-1,tsp.a.gl,bmap,len.a)
evp.cn.a.gl <-  SpatialAverage(-1,evp.a.gl,bmap,len.a)
int.cn.a.gl <-  SpatialAverage(-1,int.a.gl,bmap,len.a)
etp.cn.a.gl <-  SpatialAverage(-1,etp.a.gl,bmap,len.a)
ets.cn.a.gl <-  SpatialAverage(-1,ets.a.gl,bmap,len.a)
etw.cn.a.gl <-  SpatialAverage(-1,etw.a.gl,bmap,len.a)

write.table(et.cn.a.gl,'tab/et.cn.a.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.cn.a.gl,'tab/tsp.cn.a.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.cn.a.gl,'tab/evp.cn.a.gl',col.names=F,row.names=F,sep='\t')
write.table(int.cn.a.gl,'tab/int.cn.a.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.cn.a.gl,'tab/etp.cn.a.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.cn.a.gl,'tab/ets.cn.a.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.cn.a.gl,'tab/etw.cn.a.gl',col.names=F,row.names=F,sep='\t')

et.yz.a.gl  <-  SpatialAverage(id.yz,et.a.gl,bmap,len.a)
tsp.yz.a.gl <-  SpatialAverage(id.yz,tsp.a.gl,bmap,len.a)
evp.yz.a.gl <-  SpatialAverage(id.yz,evp.a.gl,bmap,len.a)
int.yz.a.gl <-  SpatialAverage(id.yz,int.a.gl,bmap,len.a)
etp.yz.a.gl <-  SpatialAverage(id.yz,etp.a.gl,bmap,len.a)
ets.yz.a.gl <-  SpatialAverage(id.yz,ets.a.gl,bmap,len.a)
etw.yz.a.gl <-  SpatialAverage(id.yz,etw.a.gl,bmap,len.a)

write.table(et.yz.a.gl,'tab/et.yz.a.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.yz.a.gl,'tab/tsp.yz.a.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.yz.a.gl,'tab/evp.yz.a.gl',col.names=F,row.names=F,sep='\t')
write.table(int.yz.a.gl,'tab/int.yz.a.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.yz.a.gl,'tab/etp.yz.a.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.yz.a.gl,'tab/ets.yz.a.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.yz.a.gl,'tab/etw.yz.a.gl',col.names=F,row.names=F,sep='\t')


et.yl.a.gl  <-  SpatialAverage(id.yl,et.a.gl,bmap,len.a)
tsp.yl.a.gl <-  SpatialAverage(id.yl,tsp.a.gl,bmap,len.a)
evp.yl.a.gl <-  SpatialAverage(id.yl,evp.a.gl,bmap,len.a)
int.yl.a.gl <-  SpatialAverage(id.yl,int.a.gl,bmap,len.a)
etp.yl.a.gl <-  SpatialAverage(id.yl,etp.a.gl,bmap,len.a)
ets.yl.a.gl <-  SpatialAverage(id.yl,ets.a.gl,bmap,len.a)
etw.yl.a.gl <-  SpatialAverage(id.yl,etw.a.gl,bmap,len.a)

write.table(et.yl.a.gl,'tab/et.yl.a.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.yl.a.gl,'tab/tsp.yl.a.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.yl.a.gl,'tab/evp.yl.a.gl',col.names=F,row.names=F,sep='\t')
write.table(int.yl.a.gl,'tab/int.yl.a.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.yl.a.gl,'tab/etp.yl.a.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.yl.a.gl,'tab/ets.yl.a.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.yl.a.gl,'tab/etw.yl.a.gl',col.names=F,row.names=F,sep='\t')

et.cn.m.gl  <-  SpatialAverage(-1,et.m.gl,bmap,len.m)
tsp.cn.m.gl <-  SpatialAverage(-1,tsp.m.gl,bmap,len.m)
evp.cn.m.gl <-  SpatialAverage(-1,evp.m.gl,bmap,len.m)
int.cn.m.gl <-  SpatialAverage(-1,int.m.gl,bmap,len.m)
etp.cn.m.gl <-  SpatialAverage(-1,etp.m.gl,bmap,len.m)
ets.cn.m.gl <-  SpatialAverage(-1,ets.m.gl,bmap,len.m)
etw.cn.m.gl <-  SpatialAverage(-1,etw.m.gl,bmap,len.m)

write.table(et.cn.m.gl,'tab/et.cn.m.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.cn.m.gl,'tab/tsp.cn.m.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.cn.m.gl,'tab/evp.cn.m.gl',col.names=F,row.names=F,sep='\t')
write.table(int.cn.m.gl,'tab/int.cn.m.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.cn.m.gl,'tab/etp.cn.m.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.cn.m.gl,'tab/ets.cn.m.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.cn.m.gl,'tab/etw.cn.m.gl',col.names=F,row.names=F,sep='\t')

et.yz.m.gl  <-  SpatialAverage(id.yz,et.m.gl,bmap,len.m)
tsp.yz.m.gl <-  SpatialAverage(id.yz,tsp.m.gl,bmap,len.m)
evp.yz.m.gl <-  SpatialAverage(id.yz,evp.m.gl,bmap,len.m)
int.yz.m.gl <-  SpatialAverage(id.yz,int.m.gl,bmap,len.m)
etp.yz.m.gl <-  SpatialAverage(id.yz,etp.m.gl,bmap,len.m)
ets.yz.m.gl <-  SpatialAverage(id.yz,ets.m.gl,bmap,len.m)
etw.yz.m.gl <-  SpatialAverage(id.yz,etw.m.gl,bmap,len.m)

write.table(et.yz.m.gl,'tab/et.yz.m.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.yz.m.gl,'tab/tsp.yz.m.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.yz.m.gl,'tab/evp.yz.m.gl',col.names=F,row.names=F,sep='\t')
write.table(int.yz.m.gl,'tab/int.yz.m.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.yz.m.gl,'tab/etp.yz.m.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.yz.m.gl,'tab/ets.yz.m.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.yz.m.gl,'tab/etw.yz.m.gl',col.names=F,row.names=F,sep='\t')

et.yl.m.gl  <-  SpatialAverage(id.yl,et.m.gl,bmap,len.m)
tsp.yl.m.gl <-  SpatialAverage(id.yl,tsp.m.gl,bmap,len.m)
evp.yl.m.gl <-  SpatialAverage(id.yl,evp.m.gl,bmap,len.m)
int.yl.m.gl <-  SpatialAverage(id.yl,int.m.gl,bmap,len.m)
etp.yl.m.gl <-  SpatialAverage(id.yl,etp.m.gl,bmap,len.m)
ets.yl.m.gl <-  SpatialAverage(id.yl,ets.m.gl,bmap,len.m)
etw.yl.m.gl <-  SpatialAverage(id.yl,etw.m.gl,bmap,len.m)

write.table(et.yl.m.gl,'tab/et.yl.m.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.yl.m.gl,'tab/tsp.yl.m.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.yl.m.gl,'tab/evp.yl.m.gl',col.names=F,row.names=F,sep='\t')
write.table(int.yl.m.gl,'tab/int.yl.m.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.yl.m.gl,'tab/etp.yl.m.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.yl.m.gl,'tab/ets.yl.m.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.yl.m.gl,'tab/etw.yl.m.gl',col.names=F,row.names=F,sep='\t')

et.cn.c.gl  <-  SeasonalAverage1D(et.cn.m.gl,len.a) 
tsp.cn.c.gl <-  SeasonalAverage1D(tsp.cn.m.gl,len.a) 
evp.cn.c.gl <-  SeasonalAverage1D(evp.cn.m.gl,len.a) 
int.cn.c.gl <-  SeasonalAverage1D(int.cn.m.gl,len.a) 
etp.cn.c.gl <-  SeasonalAverage1D(etp.cn.m.gl,len.a) 
ets.cn.c.gl <-  SeasonalAverage1D(ets.cn.m.gl,len.a) 
etw.cn.c.gl <-  SeasonalAverage1D(etw.cn.m.gl,len.a) 

write.table(et.cn.c.gl,'tab/et.cn.c.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.cn.c.gl,'tab/tsp.cn.c.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.cn.c.gl,'tab/evp.cn.c.gl',col.names=F,row.names=F,sep='\t')
write.table(int.cn.c.gl,'tab/int.cn.c.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.cn.c.gl,'tab/etp.cn.c.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.cn.c.gl,'tab/ets.cn.c.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.cn.c.gl,'tab/etw.cn.c.gl',col.names=F,row.names=F,sep='\t')

et.yz.c.gl  <-  SeasonalAverage1D(et.yz.m.gl,len.a) 
tsp.yz.c.gl <-  SeasonalAverage1D(tsp.yz.m.gl,len.a) 
evp.yz.c.gl <-  SeasonalAverage1D(evp.yz.m.gl,len.a) 
int.yz.c.gl <-  SeasonalAverage1D(int.yz.m.gl,len.a) 
etp.yz.c.gl <-  SeasonalAverage1D(etp.yz.m.gl,len.a) 
ets.yz.c.gl <-  SeasonalAverage1D(ets.yz.m.gl,len.a) 
etw.yz.c.gl <-  SeasonalAverage1D(etw.yz.m.gl,len.a) 

write.table(et.yz.c.gl,'tab/et.yz.c.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.yz.c.gl,'tab/tsp.yz.c.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.yz.c.gl,'tab/evp.yz.c.gl',col.names=F,row.names=F,sep='\t')
write.table(int.yz.c.gl,'tab/int.yz.c.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.yz.c.gl,'tab/etp.yz.c.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.yz.c.gl,'tab/ets.yz.c.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.yz.c.gl,'tab/etw.yz.c.gl',col.names=F,row.names=F,sep='\t')

et.yl.c.gl  <-  SeasonalAverage1D(et.yl.m.gl,len.a) 
tsp.yl.c.gl <-  SeasonalAverage1D(tsp.yl.m.gl,len.a) 
evp.yl.c.gl <-  SeasonalAverage1D(evp.yl.m.gl,len.a) 
int.yl.c.gl <-  SeasonalAverage1D(int.yl.m.gl,len.a) 
etp.yl.c.gl <-  SeasonalAverage1D(etp.yl.m.gl,len.a) 
ets.yl.c.gl <-  SeasonalAverage1D(ets.yl.m.gl,len.a) 
etw.yl.c.gl <-  SeasonalAverage1D(etw.yl.m.gl,len.a) 

write.table(et.yl.c.gl,'tab/et.yl.c.gl',col.names=F,row.names=F,sep='\t')
write.table(tsp.yl.c.gl,'tab/tsp.yl.c.gl',col.names=F,row.names=F,sep='\t')
write.table(evp.yl.c.gl,'tab/evp.yl.c.gl',col.names=F,row.names=F,sep='\t')
write.table(int.yl.c.gl,'tab/int.yl.c.gl',col.names=F,row.names=F,sep='\t')
write.table(etp.yl.c.gl,'tab/etp.yl.c.gl',col.names=F,row.names=F,sep='\t')
write.table(ets.yl.c.gl,'tab/ets.yl.c.gl',col.names=F,row.names=F,sep='\t')
write.table(etw.yl.c.gl,'tab/etw.yl.c.gl',col.names=F,row.names=F,sep='\t')
