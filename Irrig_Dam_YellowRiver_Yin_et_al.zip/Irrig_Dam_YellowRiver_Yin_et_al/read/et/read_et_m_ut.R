#In this script we will read monthly ET data from the data from UT 
#data is from 2001 -- 2015: but we only read 2001-2014
#unit is mm.mon-1

library('RNetCDF')
source('lib/lib_et.R')

path    <-  '/home/surface4/vyin/data/ET_twente/origin_nc/'

#start and count
t.s <-  1
t.c <-  168

# time series
time.m  <-  seq(as.Date('2001-01-15'),as.Date('2014-12-15'),by='months')
time.a  <-  seq(as.Date('2001-01-01'),as.Date('2014-01-01'),by='years')

len.m   <-  length(time.m)
len.a   <-  length(time.a)


filei   =   paste(path,'ET_ITC_05deg_0115_CN_M.nc',sep='')
nc.ut   =   open.nc(filei)

#read data from 2001-2015
et.m.ut =   var.get.nc(nc.ut,'et',start=c(NA,NA,t.s),count=c(NA,NA,t.c))
close.nc(nc.ut)

#mask by chinese region
et.m.ut[cnland < .5] <-  NA

#get annual averaged data
et.a.ut <-  AnnualAverage(et.m.ut,len.a)*12

#get total mean data
et.t.ut <-  apply(et.a.ut,c(1,2),mean,na.rm=T)

write.table(et.t.ut,'tab/et.t.ut',col.names=F,row.names=F,sep='\t')

#get total seasonal mean data
et.c.ut <-  SeasonalAverage(et.m.ut,len.a)

#get spatial mean annual and monthly data
et.cn.a.ut <-  SpatialAverage(id.cn,et.a.ut,bmap,len.a)
et.yz.a.ut <-  SpatialAverage(id.yz,et.a.ut,bmap,len.a)
et.yl.a.ut <-  SpatialAverage(id.yl,et.a.ut,bmap,len.a)

write.table(et.cn.a.ut,'tab/et.cn.a.ut',col.names=F,row.names=F,sep='\t')
write.table(et.yz.a.ut,'tab/et.yz.a.ut',col.names=F,row.names=F,sep='\t')
write.table(et.yl.a.ut,'tab/et.yl.a.ut',col.names=F,row.names=F,sep='\t')

et.cn.m.ut <-  SpatialAverage(id.cn,et.m.ut,bmap,len.m)
et.yz.m.ut <-  SpatialAverage(id.yz,et.m.ut,bmap,len.m)
et.yl.m.ut <-  SpatialAverage(id.yl,et.m.ut,bmap,len.m)

write.table(et.cn.m.ut,'tab/et.cn.m.ut',col.names=F,row.names=F,sep='\t')
write.table(et.yz.m.ut,'tab/et.yz.m.ut',col.names=F,row.names=F,sep='\t')
write.table(et.yl.m.ut,'tab/et.yl.m.ut',col.names=F,row.names=F,sep='\t')

et.cn.c.ut <-  SeasonalAverage1D(et.cn.m.ut,len.a)
et.yz.c.ut <-  SeasonalAverage1D(et.yz.m.ut,len.a)
et.yl.c.ut <-  SeasonalAverage1D(et.yl.m.ut,len.a)

write.table(et.cn.c.ut,'tab/et.cn.c.ut',col.names=F,row.names=F,sep='\t')
write.table(et.yz.c.ut,'tab/et.yz.c.ut',col.names=F,row.names=F,sep='\t')
write.table(et.yl.c.ut,'tab/et.yl.c.ut',col.names=F,row.names=F,sep='\t')

