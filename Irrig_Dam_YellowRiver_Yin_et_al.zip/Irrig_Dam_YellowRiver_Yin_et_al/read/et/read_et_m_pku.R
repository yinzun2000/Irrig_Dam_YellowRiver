#In this script we will read monthly ET data from the data from PKU
#data is from 1982 -- 2009: but we only read 1982-2009
#unit is mm.mon-1

library('RNetCDF')
source('lib/lib_et.R')

path    <-  '/home/surface4/vyin/data/et_pku/china/'

#start and count
t.s <-  1
t.c <-  336

# time series
time.m  <-  seq(as.Date('1982-01-15'),as.Date('2009-12-15'),by='months')
time.a  <-  seq(as.Date('1982-01-01'),as.Date('2009-01-01'),by='years')

len.m   <-  length(time.m)
len.a   <-  length(time.a)


filei   =   paste0(path,'PKU_ET_05deg_8209_CN_M.nc')
nc.pk   =   open.nc(filei)

#read data from 2001-2015
et.m.pk =   var.get.nc(nc.pk,'ET',start=c(NA,NA,t.s),count=c(NA,NA,t.c))
close.nc(nc.pk)

#mask by chinese region
et.m.pk[cnland < .5] <-  NA

#get annual averaged data
et.a.pk <-  AnnualAverage(et.m.pk,len.a)*12

#get total mean data
et.t.pk <-  apply(et.a.pk,c(1,2),mean,na.rm=T)

write.table(et.t.pk,'tab/et.t.pk',col.names=F,row.names=F,sep='\t')

#get total seasonal mean data
et.c.pk <-  SeasonalAverage(et.m.pk,len.a)

#get spatial mean annual and monthly data
et.cn.a.pk <-  SpatialAverage(id.cn,et.a.pk,bmap,len.a)
et.yz.a.pk <-  SpatialAverage(id.yz,et.a.pk,bmap,len.a)
et.yl.a.pk <-  SpatialAverage(id.yl,et.a.pk,bmap,len.a)

write.table(et.cn.a.pk,'tab/et.cn.a.pk',col.names=F,row.names=F,sep='\t')
write.table(et.yz.a.pk,'tab/et.yz.a.pk',col.names=F,row.names=F,sep='\t')
write.table(et.yl.a.pk,'tab/et.yl.a.pk',col.names=F,row.names=F,sep='\t')

et.cn.m.pk <-  SpatialAverage(id.cn,et.m.pk,bmap,len.m)
et.yz.m.pk <-  SpatialAverage(id.yz,et.m.pk,bmap,len.m)
et.yl.m.pk <-  SpatialAverage(id.yl,et.m.pk,bmap,len.m)

write.table(et.cn.m.pk,'tab/et.cn.m.pk',col.names=F,row.names=F,sep='\t')
write.table(et.yz.m.pk,'tab/et.yz.m.pk',col.names=F,row.names=F,sep='\t')
write.table(et.yl.m.pk,'tab/et.yl.m.pk',col.names=F,row.names=F,sep='\t')

et.cn.c.pk <-  SeasonalAverage1D(et.cn.m.pk,len.a)
et.yz.c.pk <-  SeasonalAverage1D(et.yz.m.pk,len.a)
et.yl.c.pk <-  SeasonalAverage1D(et.yl.m.pk,len.a)

write.table(et.cn.c.pk,'tab/et.cn.c.pk',col.names=F,row.names=F,sep='\t')
write.table(et.yz.c.pk,'tab/et.yz.c.pk',col.names=F,row.names=F,sep='\t')
write.table(et.yl.c.pk,'tab/et.yl.c.pk',col.names=F,row.names=F,sep='\t')
