#In this script we will read monthly ET data from the data from MPI
#data is from 1982--2011: but we only read 1982-2011
#NOTE: the initial variable is latent heat flux and the initial
#unit is MJ.m-2.d-1
#will be converted to mm.mon-1 and mm.yr-1

library('RNetCDF')
source('lib/lib_et.R')

path    <-  '/home/surface4/vyin/data/MPI/ET/'

num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)

#start and count
t.s <-  1
t.c <-  360

l   <-  1e6/(3600*24*28.94)

# time series
time.m  <-  seq(as.Date('1982-01-15'),as.Date('2011-12-15'),by='months')
time.a  <-  seq(as.Date('1982-01-01'),as.Date('2011-01-01'),by='years')

len.m   <-  length(time.m)
len.a   <-  length(time.a)

#read data from netcdf
et.m.mp <-  ReadMPI('fluxlat',t.s,t.c)

#change unit from mm.d-1 to mm.mon-1
for (yr in 1:len.a)
for (mon in 1:12)
    et.m.mp[,,12*(yr-1)+mon]    <-  et.m.mp[,,12*(yr-1)+mon]*num.day[mon]

#mask by chinese region
et.m.mp[cnland < .5] <-  NA

#get annual averaged data
et.a.mp <-  AnnualAverage(et.m.mp,len.a)*12

#get total mean data
et.t.mp <-  apply(et.a.mp,c(1,2),mean,na.rm=T)

write.table(et.t.mp,'tab/et.t.mp',col.names=F,row.names=F,sep='\t')

#get total seasonal mean data
et.c.mp <-  SeasonalAverage(et.m.mp,len.a)

#get spatial mean annual and monthly data
et.cn.a.mp <-  SpatialAverage(id.cn,et.a.mp,bmap,len.a)
et.yz.a.mp <-  SpatialAverage(id.yz,et.a.mp,bmap,len.a)
et.yl.a.mp <-  SpatialAverage(id.yl,et.a.mp,bmap,len.a)

write.table(et.cn.a.mp,'tab/et.cn.a.mp',col.names=F,row.names=F,sep='\t')
write.table(et.yz.a.mp,'tab/et.yz.a.mp',col.names=F,row.names=F,sep='\t')
write.table(et.yl.a.mp,'tab/et.yl.a.mp',col.names=F,row.names=F,sep='\t')

et.cn.m.mp <-  SpatialAverage(id.cn,et.m.mp,bmap,len.m)
et.yz.m.mp <-  SpatialAverage(id.yz,et.m.mp,bmap,len.m)
et.yl.m.mp <-  SpatialAverage(id.yl,et.m.mp,bmap,len.m)

write.table(et.cn.m.mp,'tab/et.cn.m.mp',col.names=F,row.names=F,sep='\t')
write.table(et.yz.m.mp,'tab/et.yz.m.mp',col.names=F,row.names=F,sep='\t')
write.table(et.yl.m.mp,'tab/et.yl.m.mp',col.names=F,row.names=F,sep='\t')

#calculate the time series of all averaged lai
et.cn.c.mp <-  SeasonalAverage1D(et.cn.m.mp,len.a)
et.yz.c.mp <-  SeasonalAverage1D(et.yz.m.mp,len.a)
et.yl.c.mp <-  SeasonalAverage1D(et.yl.m.mp,len.a)

write.table(et.cn.c.mp,'tab/et.cn.c.mp',col.names=F,row.names=F,sep='\t')
write.table(et.yz.c.mp,'tab/et.yz.c.mp',col.names=F,row.names=F,sep='\t')
write.table(et.yl.c.mp,'tab/et.yl.c.mp',col.names=F,row.names=F,sep='\t')

