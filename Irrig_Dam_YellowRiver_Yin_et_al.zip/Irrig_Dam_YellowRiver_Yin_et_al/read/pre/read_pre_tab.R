#here we will read precipitation data from tab/
source("lib/lib_pre.R")

#ORHICDEE-GSWP3
pre.t.orc <-  as.matrix(read.table("tab/pre.t.orc"))

pre.cn.a.orc  <-  as.matrix(read.table("tab/pre.cn.a.orc"))
pre.yz.a.orc  <-  as.matrix(read.table("tab/pre.yz.a.orc"))
pre.yl.a.orc  <-  as.matrix(read.table("tab/pre.yl.a.orc"))

pre.cn.m.orc  <-  as.matrix(read.table("tab/pre.cn.m.orc"))
pre.yz.m.orc  <-  as.matrix(read.table("tab/pre.yz.m.orc"))
pre.yl.m.orc  <-  as.matrix(read.table("tab/pre.yl.m.orc"))

pre.cn.c.orc  <-  as.matrix(read.table("tab/pre.cn.c.orc"))
pre.yz.c.orc  <-  as.matrix(read.table("tab/pre.yz.c.orc"))
pre.yl.c.orc  <-  as.matrix(read.table("tab/pre.yl.c.orc"))

tr.k.pre.m.orc  <-  as.matrix(read.table("tab/tr.k.pre.m.orc"))
tr.p.pre.m.orc  <-  as.matrix(read.table("tab/tr.p.pre.m.orc"))

tr.k.pre.m.orc4tws  <-  as.matrix(read.table("tab/tr.k.pre.m.orc4tws"))
tr.p.pre.m.orc4tws  <-  as.matrix(read.table("tab/tr.p.pre.m.orc4tws"))

#MSWEP
#pre.t.ms <-  as.matrix(read.table("tab/pre.t.ms"))
#
#pre.cn.a.ms  <-  as.matrix(read.table("tab/pre.cn.a.ms"))
#pre.yz.a.ms  <-  as.matrix(read.table("tab/pre.yz.a.ms"))
#pre.yl.a.ms  <-  as.matrix(read.table("tab/pre.yl.a.ms"))
#
#pre.cn.m.ms  <-  as.matrix(read.table("tab/pre.cn.m.ms"))
#pre.yz.m.ms  <-  as.matrix(read.table("tab/pre.yz.m.ms"))
#pre.yl.m.ms  <-  as.matrix(read.table("tab/pre.yl.m.ms"))
#
#pre.cn.c.ms  <-  as.matrix(read.table("tab/pre.cn.c.ms"))
#pre.yz.c.ms  <-  as.matrix(read.table("tab/pre.yz.c.ms"))
#pre.yl.c.ms  <-  as.matrix(read.table("tab/pre.yl.c.ms"))
