#here we will read precipitation data from tab/
source("lib/lib_pre.R")

#ORHICDEE-GSWP3
pre.t.orc <-  as.matrix(read.table("tab/pre.t.orc"))

prel.t.orc <-  as.matrix(read.table("tab/prel.t.orc"))

prel.cn.a.orc  <-  as.matrix(read.table("tab/prel.cn.a.orc"))
prel.yz.a.orc  <-  as.matrix(read.table("tab/prel.yz.a.orc"))
prel.yl.a.orc  <-  as.matrix(read.table("tab/prel.yl.a.orc"))

prel.cn.m.orc  <-  as.matrix(read.table("tab/prel.cn.m.orc"))
prel.yz.m.orc  <-  as.matrix(read.table("tab/prel.yz.m.orc"))
prel.yl.m.orc  <-  as.matrix(read.table("tab/prel.yl.m.orc"))

prel.cn.c.orc  <-  as.matrix(read.table("tab/prel.cn.c.orc"))
prel.yz.c.orc  <-  as.matrix(read.table("tab/prel.yz.c.orc"))
prel.yl.c.orc  <-  as.matrix(read.table("tab/prel.yl.c.orc"))

v.tmp <-  as.matrix(read.table('tab/prel.c.orc'))
n.lat <-  dim(prel.t.orc)[2]
prel.c.orc <-  array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  prel.c.orc[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]


v.tmp <-  as.matrix(read.table('tab/pre.97.m'))
n.lat <-  dim(prel.t.orc)[2]
pre.97.m  <-  array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  pre.97.m[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]

v.tmp <-  as.matrix(read.table('tab/pre.98.m'))
n.lat <-  dim(prel.t.orc)[2]
pre.98.m  <-  array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  pre.98.m[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]

v.tmp <-  as.matrix(read.table('tab/pre.03.m'))
n.lat <-  dim(prel.t.orc)[2]
pre.03.m  <-  array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  pre.03.m[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]

pre.97.a <-  as.matrix(read.table('tab/pre.97.a'))
pre.98.a <-  as.matrix(read.table('tab/pre.98.a'))
pre.03.a <-  as.matrix(read.table('tab/pre.03.a'))

prel.sr2.yl.m <-  as.matrix(read.table('tab/prel.sr2.yl.m'))
prel.sr2.yz.m <-  as.matrix(read.table('tab/prel.sr2.yz.m'))
prel.sr2.yl.a <-  as.matrix(read.table('tab/prel.sr2.yl.a'))
prel.sr2.yz.a <-  as.matrix(read.table('tab/prel.sr2.yz.a'))


pre.qtl.97.a <-  as.matrix(read.table('tab/pre.qtl.97.a'))
pre.qtl.98.a <-  as.matrix(read.table('tab/pre.qtl.98.a'))
pre.qtl.03.a <-  as.matrix(read.table('tab/pre.qtl.03.a'))

v.tmp <-  as.matrix(read.table('tab/pre.qtl.97.m'))
pre.qtl.97.m <- array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  pre.qtl.97.m[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]

v.tmp <-  as.matrix(read.table('tab/pre.qtl.98.m'))
pre.qtl.98.m <- array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  pre.qtl.98.m[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]

v.tmp <-  as.matrix(read.table('tab/pre.qtl.03.m'))
pre.qtl.03.m <- array(NA,dim=c(dim(prel.t.orc)[1:2],12))
for (i in 1:12)
  pre.qtl.03.m[,,i] <-  v.tmp[,(n.lat*(i-1)+1):(n.lat*i)]

