source("lib/lib_tws.R")

var <-  'tws'
#irr <-  c('oc','ni','ir')
irr <-  c('ni','ir')
dat <-  c('csr','jpl','gsf')
reg <-  c('cn','yz','yl')
freq    <-  c('m','a','c')
ind <-  c('cor','p','rmse','sb','sdsd','lcs','dif')

time.a.oc <-  seq(as.Date("1982-01-01"),as.Date("2014-01-01"),by="years")
time.m.oc <-  seq(as.Date("1982-01-15"),as.Date("2014-12-15"),by="months")

time.a.gr <-  seq(as.Date("2003-01-01"),as.Date("2015-01-01"),by="years")
time.m.gr <-  seq(as.Date("2003-01-15"),as.Date("2015-12-15"),by="months")

time.a.all <-  seq(as.Date("1982-01-01"),as.Date("2015-01-01"),by="years")
time.m.all <-  seq(as.Date("1982-01-15"),as.Date("2015-12-15"),by="months")

time.a.oc4gr  <-  seq(as.Date("2003-01-01"),as.Date("2014-01-01"),by="years")
time.m.oc4gr  <-  seq(as.Date("2003-01-15"),as.Date("2014-12-15"),by="months")

#read value from ORCHIDEE
for (i in 1:length(var))
for (j in 1:length(irr))
{
  #note that we don't have to calculate total tws, it is meaningless

  #read  spatial annual mean, monthly mean, and seasonal
  for (k in 1:length(reg))
  for (l in 1:length(freq))
  {
    eval(parse(text=
       paste0(var[i],'.',reg[k],'.',freq[l],'.',irr[j],' <-
           as.matrix(read.table(\'tab/',var[i],'.',reg[k],
                                '.',freq[l],'.',irr[j],'\'))')))
    eval(parse(text=
       paste0(var[i],'.',reg[k],'.',freq[l],'.',irr[j],'4gr <-
           as.matrix(read.table(\'tab/',var[i],'.',reg[k],
                                '.',freq[l],'.',irr[j],'4gr\'))')))
  }

  #read monthly trend
  eval(parse(text=
     paste0('tr.p.',var[i],'.m.',irr[j],' <-
         as.matrix(read.table(\'tab/tr.p.',var[i],'.m.',irr[j],'\'))')))
  eval(parse(text=
     paste0('tr.k.',var[i],'.m.',irr[j],' <-
         as.matrix(read.table(\'tab/tr.k.',var[i],'.m.',irr[j],'\'))')))

  eval(parse(text=
     paste0('tr.p.',var[i],'.m.',irr[j],'4gr <-
         as.matrix(read.table(\'tab/tr.p.',var[i],'.m.',irr[j],'4gr\'))')))
  eval(parse(text=
     paste0('tr.k.',var[i],'.m.',irr[j],'4gr <-
         as.matrix(read.table(\'tab/tr.k.',var[i],'.m.',irr[j],'4gr\'))')))
}

#read value from GRACE data
for (i in 1:length(var))
for (j in 1:length(dat))
{
  #read  spatial annual mean, monthly mean, and seasonal
  for (k in 1:length(reg))
  for (l in 1:length(freq))
  {
    eval(parse(text=
       paste0(var[i],'.',reg[k],'.',freq[l],'.',dat[j],' <-
           as.matrix(read.table(\'tab/',var[i],'.',reg[k],
                                '.',freq[l],'.',dat[j],'\'))')))
    eval(parse(text=
       paste0(var[i],'.',reg[k],'.',freq[l],'.',dat[j],'4oc <-
           as.matrix(read.table(\'tab/',var[i],'.',reg[k],
                                '.',freq[l],'.',dat[j],'4oc\'))')))
  }

  #read monthly trend
  eval(parse(text=
     paste0('tr.p.',var[i],'.m.',dat[j],' <-
         as.matrix(read.table(\'tab/tr.p.',var[i],'.m.',dat[j],'\'))')))
  eval(parse(text=
     paste0('tr.k.',var[i],'.m.',dat[j],' <-
         as.matrix(read.table(\'tab/tr.k.',var[i],'.m.',dat[j],'\'))')))

  eval(parse(text=
     paste0('tr.p.',var[i],'.m.',dat[j],'4oc <-
         as.matrix(read.table(\'tab/tr.p.',var[i],'.m.',dat[j],'4oc\'))')))
  eval(parse(text=
     paste0('tr.k.',var[i],'.m.',dat[j],'4oc <-
         as.matrix(read.table(\'tab/tr.k.',var[i],'.m.',dat[j],'4oc\'))')))
}

#compare
for (i in 1:length(irr))
for (j in 1:length(dat))
for (k in 1:length(ind))
{
  for (l in 1:length(var))
  {
    if (ind[k] != 'dif')
        eval(parse(text=
           paste0(ind[k],'.',var[l],'.m.',dat[j],'.',irr[i],' <-
               as.matrix(read.table(\'tab/',ind[k],'.',var[l],'.m.',dat[j],'.',irr[i],'\'))')))
  }
}

