#here we try to read dams regulation to correct simulated discharge.
#units: capacity [10^8m^3]; water level [m]; 
#we have monthly regulation and yearly capacity anomaly

source('lib/lib_dam.R')

time.a  <-  seq(as.Date('1982-01-01'),as.Date('2014-01-01'),by='years')
time.m  <-  seq(as.Date('1982-01-15'),as.Date('2014-12-15'),by='months')
len.a <-  length(time.a)
len.m <-  length(time.m)

#first read yearly difference data
#Liujiaxia: 1987--2016
#read: 1987--2014, and fill 1982-1986 by zero
#Longyangxia: 1987--2016
#read: 1987--2014, and fill 1982-1986 by zero
#Xiaolangdi: 1987--2016
#read: 1987--2014, and fill 1982-1986 by zero

#lyx
cap.a.lyx   <-  array(0,dim=len.a)
tt.tmp  <-  as.matrix(read.table("tab/dam/lyx_yr_8716"))
cap.a.lyx[6:len.a]  <-  tt.tmp[1:28]

#ljx
cap.a.ljx   <-  array(0,dim=len.a)
tt.tmp  <-  as.matrix(read.table("tab/dam/ljx_yr_8716"))
cap.a.ljx[6:len.a]  <-  tt.tmp[1:28]

#xld
cap.a.xld <-  array(0,dim=len.a)
tt.tmp    <-  as.matrix(read.table("tab/dam/xld_yr_9916"))
cap.a.xld[18:len.a] <-  tt.tmp[1:16]


#calculate water level--capacity curve for xld
#water level [m]; capacity [10^9m^3]
#we have xld water level data at border of each month
#first we calculate corresponding capacity
#then we calculate capacity change
#finally we remove the residual
#dat.tmp <-  as.matrix(read.table("tab/dam/xld_level_capacity_1999"))
dat.tmp <-  as.matrix(read.table("tab/dam/xld_level_capacity_2014"))

lvl.m.xld <-  as.matrix(read.table("tab/dam/xld_mon_level"))

#here we change the unit from 10^9m^3 to 10^8m^3
cap.tmp   <-  CapLvl(dat.tmp[,1],dat.tmp[,2],lvl.m.xld)*10

cap.m.xld <-  cap.tmp[2:13] - cap.tmp[1:12]

cap.m.xld <-  cap.m.xld - mean(cap.m.xld)


#read monthly regulation of lyx and ljx
cap.m.lyx <-  as.matrix(read.table("tab/dam/lyx_mon_8713"))

cap87.m.ljx <-  as.matrix(read.table("tab/dam/ljx_mon_8713"))
cap69.m.ljx <-  as.matrix(read.table("tab/dam/ljx_mon_6986"))

dcap.m.lyx  <-  cap.m.lyx
dcap.m.lyx[1]  <-  cap.m.lyx[1] - cap.m.lyx[12]
dcap.m.lyx[2:12]  <-  cap.m.lyx[2:12] - cap.m.lyx[1:11]
