#read some data fast from tab/
ReadTable   <-  function(filei,ncol,nrow,len){
    output  <-  array(0,dim=c(ncol,nrow,len))
    v.tmp   <-  as.matrix(read.table(filei))

    for (i in 1:len)
        output[,,i] <-  v.tmp[,(nrow*(i-1)+1):(nrow*i)]

    return(output)
}

source('read/dis/read_dis_dam.R')

dis.yz.m.hh <-  as.matrix(read.table('tab/dis.yz.m.hh'))
dis.yz.m.ni <-  as.matrix(read.table('tab/dis.yz.m.ni'))
dis.yz.m.ir <-  as.matrix(read.table('tab/dis.yz.m.ir'))

dis.yl.m.hh <-  as.matrix(read.table('tab/dis.yl.m.hh'))
dis.yl.m.ni <-  as.matrix(read.table('tab/dis.yl.m.ni'))
dis.yl.m.ir <-  as.matrix(read.table('tab/dis.yl.m.ir'))

dis.yz.a.hh <-  as.matrix(read.table('tab/dis.yz.a.hh'))
dis.yz.a.ni <-  as.matrix(read.table('tab/dis.yz.a.ni'))
dis.yz.a.ir <-  as.matrix(read.table('tab/dis.yz.a.ir'))

dis.yl.a.hh <-  as.matrix(read.table('tab/dis.yl.a.hh'))
dis.yl.a.ni <-  as.matrix(read.table('tab/dis.yl.a.ni'))
dis.yl.a.ir <-  as.matrix(read.table('tab/dis.yl.a.ir'))

lon.yz.hh   <-  as.matrix(read.table('tab/lon.yz.hh'))
lon.yl.hh   <-  as.matrix(read.table('tab/lon.yl.hh'))

lat.yz.hh   <-  as.matrix(read.table('tab/lat.yz.hh'))
lat.yl.hh   <-  as.matrix(read.table('tab/lat.yl.hh'))

ind <-  c('r2','kge','cor','beta','alp','rmse',
          'sb','sdsd','lcs','nse','d','dif')
reg <-  'yl'
irr <-  c('ni','ir','ni2','ir2','ni3','ir3','ni.a','ir.a')

for (i in 1:length(ind))
for (k in 1:length(reg))
for (l in 1:length(irr))
{
  eval(parse(text=
             paste0(ind[i],'.',reg[k],'.m.hh.',irr[l],' <- 
                    as.matrix(read.table(\'tab/',ind[i],'.',
                                         reg[k],'.m.hh.',irr[l],'\'))')))
}

#define the time series
time.m.yl   <-  seq(as.Date('1982-01-15'),as.Date('2014-12-15'),by='months')
time.a.yl   <-  seq(as.Date('1982-01-01'),as.Date('2014-12-01'),by='years')

time.m.yz   <-  seq(as.Date('1982-01-15'),as.Date('2000-12-15'),by='months')
time.a.yz   <-  seq(as.Date('1982-01-01'),as.Date('2000-12-01'),by='years')


#interpolation the hhu discharge at pingshan station
idx.st  <-  c(7,8,5,11,4)
t1.tmp  <-  dis.yz.m.hh[idx.st[1],]
t2.tmp  <-  dis.yz.m.hh[idx.st[2],]
lm.tmp  <-  lm(t1.tmp~t2.tmp)
int.tmp <-  as.numeric(lm.tmp$coefficients[1])
rat.tmp <-  as.numeric(lm.tmp$coefficients[2])
t1.tmp[is.na(t1.tmp)] <-  int.tmp+rat.tmp*t2.tmp[is.na(t1.tmp)]
dis.yz.m.hh[idx.st[1],] <-  t1.tmp

t1.tmp  <-  dis.yz.a.hh[idx.st[1],]
t2.tmp  <-  dis.yz.a.hh[idx.st[2],]
lm.tmp  <-  lm(t1.tmp~t2.tmp)
int.tmp <-  as.numeric(lm.tmp$coefficients[1])
rat.tmp <-  as.numeric(lm.tmp$coefficients[2])
t1.tmp[is.na(t1.tmp)] <-  int.tmp+rat.tmp*t2.tmp[is.na(t1.tmp)]
dis.yz.a.hh[idx.st[1],] <-  t1.tmp


#index of the five stations for YZ and YL
idx.yz  <-  c(7,8,5,11,4)
idx.yl  <-  c(23,17,21,11,13)


#use 2010 data to fill 2011
dis.yl.m.ir[,349:360] <-  dis.yl.m.ir[,337:348]
dis.yl.m.ni[,349:360] <-  dis.yl.m.ni[,337:348]

dis.yl.a.ir[,30] <-  (dis.yl.a.ir[,29]+dis.yl.a.ir[,31])/2
