source('read/area/read_area_tab.R')
source('read/subregion/read_subregion_tab.R')
#read crop fraction for each subregion
ifrac <-  as.matrix(read.table('tab/mfc.crop.t.orc'))

yz.tmp  <-  as.matrix(read.table('tab/subregion.yz.st'))
yl.tmp  <-  as.matrix(read.table('tab/subregion.yl.st'))

subregion.yz.st <-  array(NA,dim=c(132,76,5))
subregion.yl.st <-  array(NA,dim=c(132,76,5))

for (i in 1:5)
{
  subregion.yz.st[,,i]  <-  yz.tmp[,(76*(i-1)+1):(76*i)]
  subregion.yl.st[,,i]  <-  yl.tmp[,(76*(i-1)+1):(76*i)]
}
rm(yz.tmp,yl.tmp)

#calculate area of subregion [m^2]
area.sr2.yl <-  array(0,dim=5)
area.sr2.yz <-  array(0,dim=5)
ifrac.sr2.yl <-  array(0,dim=5)

for (i in 1:5)
{
  sb2.tmp <-  subregion2.yl.st[,,i]
  area.sr2.yl[i] <-  sum(area.orc*sb2.tmp,na.rm=T)
  area.sr2.yz[i] <-  sum(area.orc*sb2.tmp,na.rm=T)
  ifrac.tmp <-  ifrac*sb2.tmp
  ifrac.tmp[sb2.tmp == 0] <-  NA
  ifrac.sr2.yl[i] <-  mean(ifrac.tmp,na.rm=T)
}

pre.sr.m.yl <-  as.matrix(read.table('tab/pre.sr.m.yl'))
pre.sr.m.yz <-  as.matrix(read.table('tab/pre.sr.m.yz'))
pre.sr.a.yl <-  as.matrix(read.table('tab/pre.sr.a.yl'))
pre.sr.a.yz <-  as.matrix(read.table('tab/pre.sr.a.yz'))

pre.sr2.m.yl <-  as.matrix(read.table('tab/pre.sr2.m.yl'))
pre.sr2.m.yz <-  as.matrix(read.table('tab/pre.sr2.m.yz'))
pre.sr2.a.yl <-  as.matrix(read.table('tab/pre.sr2.a.yl'))
pre.sr2.a.yz <-  as.matrix(read.table('tab/pre.sr2.a.yz'))


var <-  c('pre','pre2')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '\'))')))

var <-  'et'
irr <-  c('ni','ir','fi','gl','ut','mp','pk')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')
for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  'etp'
irr <-  c('ni','ir','fi','gl')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')
for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  'irr'
irr <-  c('ir','fi')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  c('sm','run','dra')
irr <-  c('ni','ir')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  'tws'
irr <-  c('ni','ir','csr','jpl','gsf')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  'irr'
irr <-  c('ir','fi')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  c('sm','run','dra')
irr <-  c('ni','ir')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

var <-  'tws'
irr <-  c('ni','ir','csr','jpl','gsf')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- as.matrix(read.table(\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],
                    '.',irr[j],'\'))')))

