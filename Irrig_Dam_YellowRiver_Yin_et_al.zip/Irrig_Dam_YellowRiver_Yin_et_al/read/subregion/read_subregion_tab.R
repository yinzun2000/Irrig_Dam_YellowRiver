
yz.tmp  <-  as.matrix(read.table('tab/subregion.yz.st'))
yl.tmp  <-  as.matrix(read.table('tab/subregion.yl.st'))

subregion.yz.st <-  array(NA,dim=c(132,76,5))
subregion.yl.st <-  array(NA,dim=c(132,76,5))

for (i in 1:5)
{
  subregion.yz.st[,,i]  <-  yz.tmp[,(76*(i-1)+1):(76*i)]
  subregion.yl.st[,,i]  <-  yl.tmp[,(76*(i-1)+1):(76*i)]
}

subregion2.yz.st <-  subregion.yz.st
subregion2.yl.st <-  subregion.yl.st

for (i in 2:5)
{
  subregion2.yz.st[,,i] <-  subregion.yz.st[,,i] - subregion.yz.st[,,i-1]
  subregion2.yl.st[,,i] <-  subregion.yl.st[,,i] - subregion.yl.st[,,i-1]
}

rm(yz.tmp,yl.tmp)
