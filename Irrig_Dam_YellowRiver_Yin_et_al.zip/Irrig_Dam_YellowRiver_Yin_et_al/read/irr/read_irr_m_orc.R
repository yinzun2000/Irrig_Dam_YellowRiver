#In this script we will read monthly irrigation from ORCHIDEE 
#period 1982 to 2014
#The initial unit is mm.d-1
#will be changed to mm.mon-1 and mm.yr-1
library('RNetCDF')

path    <-  '/home/surface4/vyin/data/NewCrop/'

num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)

id.yl   <-  27
id.yz   <-  13

s2d <-  86400

nveget  <-  15

t.s <-  12
t.c <-  3

# time series
time.m  =   seq(as.Date('1982-01-15'),as.Date('2014-12-15'),by='months')
time.a  =   seq(as.Date('1982-01-01'),as.Date('2014-01-01'),by='years')

#ir: irrigation by available water
filei   =   paste(path,'NCRR_GSWP3_ir_05deg_8214Y_CN_M.nc',sep='')
nc.ir   =   open.nc(filei)

#other related variable
lons    =   var.get.nc(nc.ir,'lon')
lats    =   var.get.nc(nc.ir,'lat')

#read data from 1990-2014
irr.crop.m.ir   =   var.get.nc(nc.ir,'irrig_fin',
                               start=c(NA,NA,t.s,NA),
                               count=c(NA,NA,t.c,NA))
mfc.crop.m  =   var.get.nc(nc.ir,'maxvegetfrac',
                           start=c(NA,NA,t.s,NA),
                           count=c(NA,NA,t.c,NA))

close.nc(nc.ir)

#fi: fully irrigation
filei   =   paste(path,'NCRR_GSWP3_fi_05deg_8214Y_CN_M.nc',sep='')
nc.fi   =   open.nc(filei)

#read data from 1990-2014
irr.crop.m.fi   =   var.get.nc(nc.fi,'irrig_fin',start=c(NA,NA,t.s,NA),count=c(NA,NA,t.c,NA))
close.nc(nc.fi)

#calculate the mean of each grid cell
irr.m.fi    <-  apply(irr.crop.m.fi*mfc.crop.m,c(1,2,4),sum,na.rm=T)
irr.m.ir    <-  apply(irr.crop.m.ir*mfc.crop.m,c(1,2,4),sum,na.rm=T)

rm(irr.crop.m.ir,irr.crop.m.fi)

#change from mm.d-1 to mm.mon-1
for (yr in 1:length(time.a))
for (mon in 1:12)
{
    irr.m.fi[,,12*(yr-1)+mon]   <-  irr.m.fi[,,12*(yr-1)+mon]*num.day[mon]
    irr.m.ir[,,12*(yr-1)+mon]   <-  irr.m.ir[,,12*(yr-1)+mon]*num.day[mon]
}

#mask data to only China region
filei   <-  '/home/surface4/vyin/data/mask/msk_05deg4hydro_CN.nc'
nc  <-  open.nc(filei)
cnland  <-  var.get.nc(nc,'mask')
close.nc(nc)

# read the basinmap
filei   <-  '/home/surface4/vyin/data/mask/basin_05deg4hydro_CN.nc'
bm.nc   <-  open.nc(filei)
bmap    <-  var.get.nc(bm.nc,'basinmap')
close.nc(bm.nc)

irr.m.ir[cnland < .5]   <-  NA
irr.m.fi[cnland < .5]   <-  NA

#get annual averaged data
irr.a.fi    <-  array(0,dim=c(length(lons),length(lats),length(time.a)))
irr.a.ir    <-  array(0,dim=c(length(lons),length(lats),length(time.a)))

for (i in 1:length(time.a)) #unit also changed to mm.yr-1
{
    irr.a.fi[,,i]   <-  apply(irr.m.fi[,,(12*(i-1)+1):(12*i)],c(1,2),mean,na.rm=T)*12
    irr.a.ir[,,i]   <-  apply(irr.m.ir[,,(12*(i-1)+1):(12*i)],c(1,2),mean,na.rm=T)*12
}

#get spatial mean annual and monthly data
irr.cn.a.fi <-  array(NA,dim=length(time.a))
irr.yl.a.fi <-  array(NA,dim=length(time.a))
irr.yz.a.fi <-  array(NA,dim=length(time.a))

irr.cn.a.ir <-  array(NA,dim=length(time.a))
irr.yl.a.ir <-  array(NA,dim=length(time.a))
irr.yz.a.ir <-  array(NA,dim=length(time.a))

irr.cn.m.fi <-  array(NA,dim=length(time.m))
irr.yl.m.fi <-  array(NA,dim=length(time.m))
irr.yz.m.fi <-  array(NA,dim=length(time.m))

irr.cn.m.ir <-  array(NA,dim=length(time.m))
irr.yl.m.ir <-  array(NA,dim=length(time.m))
irr.yz.m.ir <-  array(NA,dim=length(time.m))

for (yr in 1:length(time.a))
{
    v.tmp   <-  irr.a.fi[,,yr]
    irr.cn.a.fi[yr] <-  mean(v.tmp,na.rm=T)
    irr.yl.a.fi[yr] <-  mean(v.tmp[bmap == id.yl],na.rm=T)
    irr.yz.a.fi[yr] <-  mean(v.tmp[bmap == id.yz],na.rm=T)

    v.tmp   <-  irr.a.ir[,,yr]
    irr.cn.a.ir[yr] <-  mean(v.tmp,na.rm=T)
    irr.yl.a.ir[yr] <-  mean(v.tmp[bmap == id.yl],na.rm=T)
    irr.yz.a.ir[yr] <-  mean(v.tmp[bmap == id.yz],na.rm=T)

}

for (i in 1:length(time.m))
{
    v.tmp   <-  irr.m.fi[,,i]
    irr.cn.m.fi[i]  <-  mean(v.tmp,na.rm=T)
    irr.yl.m.fi[i]  <-  mean(v.tmp[bmap == id.yl],na.rm=T)
    irr.yz.m.fi[i]  <-  mean(v.tmp[bmap == id.yz],na.rm=T)

    v.tmp   <-  irr.m.ir[,,i]
    irr.cn.m.ir[i]  <-  mean(v.tmp,na.rm=T)
    irr.yl.m.ir[i]  <-  mean(v.tmp[bmap == id.yl],na.rm=T)
    irr.yz.m.ir[i]  <-  mean(v.tmp[bmap == id.yz],na.rm=T)

}

#get total mean data
irr.t.fi    <-  apply(irr.a.fi,c(1,2),mean,na.rm=T)
irr.t.ir    <-  apply(irr.a.ir,c(1,2),mean,na.rm=T)

#get total seasonal mean data
irr.c.fi <-  array(0,dim=c(length(lons),length(lats),12))
irr.c.ir <-  array(0,dim=c(length(lons),length(lats),12))

for (i in 1:length(time.a)) #year
for (j in 1:12) #mon
{
    irr.c.fi[,,j]   <-  irr.c.fi[,,j]+irr.m.fi[,,12*(i-1)+j]
    irr.c.ir[,,j]   <-  irr.c.ir[,,j]+irr.m.ir[,,12*(i-1)+j]
}

irr.c.fi    <-  irr.c.fi/length(time.a)
irr.c.ir    <-  irr.c.ir/length(time.a)

#calculate the time series of all averaged soil moisture
irr.cn.c.fi <-  array(0,dim=12)
irr.yz.c.fi <-  array(0,dim=12)
irr.yl.c.fi <-  array(0,dim=12)

irr.cn.c.ir <-  array(0,dim=12)
irr.yz.c.ir <-  array(0,dim=12)
irr.yl.c.ir <-  array(0,dim=12)

for (yr in 1:length(time.a))
for (mon in 1:12)
{
    irr.cn.c.fi[mon]    <-  irr.cn.c.fi[mon]+irr.cn.m.fi[12*(yr-1)+mon]
    irr.yz.c.fi[mon]    <-  irr.yz.c.fi[mon]+irr.yz.m.fi[12*(yr-1)+mon]
    irr.yl.c.fi[mon]    <-  irr.yl.c.fi[mon]+irr.yl.m.fi[12*(yr-1)+mon]

    irr.cn.c.ir[mon]    <-  irr.cn.c.ir[mon]+irr.cn.m.ir[12*(yr-1)+mon]
    irr.yz.c.ir[mon]    <-  irr.yz.c.ir[mon]+irr.yz.m.ir[12*(yr-1)+mon]
    irr.yl.c.ir[mon]    <-  irr.yl.c.ir[mon]+irr.yl.m.ir[12*(yr-1)+mon]
}

irr.cn.c.fi <-  irr.cn.c.fi/length(time.a)
irr.yz.c.fi <-  irr.yz.c.fi/length(time.a)
irr.yl.c.fi <-  irr.yl.c.fi/length(time.a)

irr.cn.c.ir <-  irr.cn.c.ir/length(time.a)
irr.yz.c.ir <-  irr.yz.c.ir/length(time.a)
irr.yl.c.ir <-  irr.yl.c.ir/length(time.a)


mfc.crop.t  <-  apply(mfc.crop.m,c(1,2),sum,na.rm=T)

write.table(mfc.crop.t,'tab/mfc.crop.t',row.names=F,col.names=F,sep='\t')

write.table(irr.t.ir,'tab/irr.t.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.t.fi,'tab/irr.t.fi',row.names=F,col.names=F,sep='\t')

write.table(irr.cn.m.ir,'tab/irr.cn.m.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.yz.m.ir,'tab/irr.yz.m.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.yl.m.ir,'tab/irr.yl.m.ir',row.names=F,col.names=F,sep='\t')

write.table(irr.cn.a.ir,'tab/irr.cn.a.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.yz.a.ir,'tab/irr.yz.a.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.yl.a.ir,'tab/irr.yl.a.ir',row.names=F,col.names=F,sep='\t')

write.table(irr.cn.c.ir,'tab/irr.cn.c.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.yz.c.ir,'tab/irr.yz.c.ir',row.names=F,col.names=F,sep='\t')
write.table(irr.yl.c.ir,'tab/irr.yl.c.ir',row.names=F,col.names=F,sep='\t')

write.table(irr.cn.m.fi,'tab/irr.cn.m.fi',row.names=F,col.names=F,sep='\t')
write.table(irr.yz.m.fi,'tab/irr.yz.m.fi',row.names=F,col.names=F,sep='\t')
write.table(irr.yl.m.fi,'tab/irr.yl.m.fi',row.names=F,col.names=F,sep='\t')

write.table(irr.cn.a.fi,'tab/irr.cn.a.fi',row.names=F,col.names=F,sep='\t')
write.table(irr.yz.a.fi,'tab/irr.yz.a.fi',row.names=F,col.names=F,sep='\t')
write.table(irr.yl.a.fi,'tab/irr.yl.a.fi',row.names=F,col.names=F,sep='\t')

write.table(irr.cn.c.fi,'tab/irr.cn.c.fi',row.names=F,col.names=F,sep='\t')
write.table(irr.yz.c.fi,'tab/irr.yz.c.fi',row.names=F,col.names=F,sep='\t')
write.table(irr.yl.c.fi,'tab/irr.yl.c.fi',row.names=F,col.names=F,sep='\t')

