#read some data fast from tab/

ReadTable   <-  function(filei,ncol,nrow,len){
    output  <-  array(0,dim=c(ncol,nrow,len))
    v.tmp   <-  as.matrix(read.table(filei))

    for (i in 1:len)
        output[,,i] <-  v.tmp[,(nrow*(i-1)+1):(nrow*i)]

    return(output)
}

time.m  <-  seq(as.Date('1982-01-15'),as.Date('2014-12-15'),by='months')
time.a  <-  seq(as.Date('1982-01-01'),as.Date('2014-01-01'),by='years')

#irr crop data

n.lons  <-  132
n.lats  <-  76
ncrop   <-  3

mfc.crop.t  <-  as.matrix(read.table('tab/mfc.crop.t'))

irr.t.ir    <-  as.matrix(read.table('tab/irr.t.ir'))
irr.t.fi    <-  as.matrix(read.table('tab/irr.t.fi'))

tr.k.irr.m.ir <-  as.matrix(read.table('tab/tr.k.irr.m.ir'))
tr.p.irr.m.ir <-  as.matrix(read.table('tab/tr.p.irr.m.ir'))

tr.k.irr.m.fi <-  as.matrix(read.table('tab/tr.k.irr.m.fi'))
tr.p.irr.m.fi <-  as.matrix(read.table('tab/tr.p.irr.m.fi'))

irr.cn.m.ir <-  as.matrix(read.table('tab/irr.cn.m.ir'))
irr.yz.m.ir <-  as.matrix(read.table('tab/irr.yz.m.ir'))
irr.yl.m.ir <-  as.matrix(read.table('tab/irr.yl.m.ir'))

irr.cn.a.ir <-  as.matrix(read.table('tab/irr.cn.a.ir'))
irr.yz.a.ir <-  as.matrix(read.table('tab/irr.yz.a.ir'))
irr.yl.a.ir <-  as.matrix(read.table('tab/irr.yl.a.ir'))

irr.cn.c.ir <-  as.matrix(read.table('tab/irr.cn.c.ir'))
irr.yz.c.ir <-  as.matrix(read.table('tab/irr.yz.c.ir'))
irr.yl.c.ir <-  as.matrix(read.table('tab/irr.yl.c.ir'))

irr.cn.m.fi <-  as.matrix(read.table('tab/irr.cn.m.fi'))
irr.yz.m.fi <-  as.matrix(read.table('tab/irr.yz.m.fi'))
irr.yl.m.fi <-  as.matrix(read.table('tab/irr.yl.m.fi'))

irr.cn.a.fi <-  as.matrix(read.table('tab/irr.cn.a.fi'))
irr.yz.a.fi <-  as.matrix(read.table('tab/irr.yz.a.fi'))
irr.yl.a.fi <-  as.matrix(read.table('tab/irr.yl.a.fi'))

irr.cn.c.fi <-  as.matrix(read.table('tab/irr.cn.c.fi'))
irr.yz.c.fi <-  as.matrix(read.table('tab/irr.yz.c.fi'))
irr.yl.c.fi <-  as.matrix(read.table('tab/irr.yl.c.fi'))


#province based annual data
irr.t.pro.ir  <-  as.matrix(read.table('tab/irr.t.pro.ir'))
irr.t.pro.fi  <-  as.matrix(read.table('tab/irr.t.pro.fi'))
irre.t.pro.ir <-  as.matrix(read.table('tab/irre.t.pro.ir'))
irre.t.pro.fi <-  as.matrix(read.table('tab/irre.t.pro.fi'))

#irr.w.pro.ir  <-  as.matrix(read.table('tab/irr.w.pro.ir'))
#irr.w.pro.fi  <-  as.matrix(read.table('tab/irr.w.pro.fi'))

#irr.m.pro.ir  <-  as.matrix(read.table('tab/irr.m.pro.ir'))
#irr.m.pro.fi  <-  as.matrix(read.table('tab/irr.m.pro.fi'))

#irr.r.pro.ir  <-  as.matrix(read.table('tab/irr.r.pro.ir'))
#irr.r.pro.fi  <-  as.matrix(read.table('tab/irr.r.pro.fi'))

#from 1990 to 2013
irr.t.pro.pku <-  as.matrix(read.table("tab/irrigation_amount_PKU.txt"))

#keep the time length and province numbers are same
irr.t.pro.ir  <-  irr.t.pro.ir[1:31,9:32]
irr.t.pro.fi  <-  irr.t.pro.fi[1:31,9:32]

irre.t.pro.ir <-  irre.t.pro.ir[1:31,9:32]
irre.t.pro.fi <-  irre.t.pro.fi[1:31,9:32]

irr.t.pro.pku <-  irr.t.pro.pku

#magnitude of annual mean irrigation of each province
mag.irr.pro.ir  <-  apply(irr.t.pro.ir,1,mean,na.rm=T)
mag.irr.pro.fi  <-  apply(irr.t.pro.fi,1,mean,na.rm=T)
mag.irr.pro.pku <-  apply(irr.t.pro.pku,1,mean,na.rm=T)

mag.irre.pro.ir <-  apply(irre.t.pro.ir,1,mean,na.rm=T)
mag.irre.pro.fi <-  apply(irre.t.pro.fi,1,mean,na.rm=T)

#magnitude of annual irrigation over China
mag.irr.cn.ir  <-  apply(irr.t.pro.ir,2,sum,na.rm=T)
mag.irr.cn.fi  <-  apply(irr.t.pro.fi,2,sum,na.rm=T)
mag.irre.cn.ir  <-  apply(irre.t.pro.ir,2,sum,na.rm=T)
mag.irre.cn.fi  <-  apply(irre.t.pro.fi,2,sum,na.rm=T)
mag.irr.cn.pku <-  apply(irr.t.pro.pku,2,sum,na.rm=T)

#irrigation efficiency
ief.pro   <-  as.matrix(read.table("tab/irrigation_coefficient_pro.txt"))
ief.cn.a  <-  as.matrix(read.table("tab/irri_efficiency_cn_7815.txt"))

ief.pro   <-  ief.pro[1:31]
#modify the time to 1990-2013
ief.cn.a  <-  ief.cn.a[13:36]

#standard deviation of annual provincial irrigation
#cv.pro.a.ir  <-  apply(irr.t.pro.ir,1,sd)/apply(irr.t.pro.ir,1,mean)
#cv.pro.a.fi  <-  apply(irr.t.pro.fi,1,sd)/apply(irr.t.pro.fi,1,mean)
#cv.pro.a.pk  <-  apply(irr.t.pro.pku,1,sd)/apply(irr.t.pro.pku,1,mean)
