sys.id  <-  Sys.info()['nodename']
if (grepl('obelix',sys.id)){
    wk.dir  <-  'obelix'
    path    <-  '/home/surface4/vyin/'
} else if (grepl('lsce',sys.id)){
    wk.dir  <-  'mbp'
    path    <-  '~/'
} else{
    stop('unknown computer')
}

#read irrigation ammount of each province from PKU data
#to compare with ORCHIDEE simulation
#period: 1990--2013
#but only read 1990--2013 here
#initial unit 10^8 m3 (0.1km3). will change to km3

path    <-  paste(path,'data/irrigation/pku/',sep='')

filei   <-  paste(path,'irrigation_amount_PKU.txt',sep='')

time.a.pku  <-  seq(as.Date('1990-01-01'),as.Date('2013-01-01'),by='years')

irr.a.pku   <-  as.matrix(read.table(filei))

#only select period 1990-2013
irr.a.pku   <-  irr.a.pku[,1:24]

#change unit from 10^8 m3 to km3.yr-1
irr.a.pku   <-  irr.a.pku*.1

#total irrigation amount
irr.t.pku   <-  apply(irr.a.pku,2,sum,na.rm=T)
