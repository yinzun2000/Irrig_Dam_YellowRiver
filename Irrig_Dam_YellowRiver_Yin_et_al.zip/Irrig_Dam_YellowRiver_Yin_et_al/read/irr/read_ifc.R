#here will read irrigation fraction map from orchidee share and write it in a txt format under tab/
#the unit is 100%
library(RNetCDF)

filei <-  'tab/irri_ifc.nc'

nco <-  open.nc(filei)
ifc <-  var.get.nc(nco,'irrig')
close.nc(nco)

ifc <-  ifc/100

write.table(ifc,'tab/ifc',row.names=F,col.names=F,sep='\t')

#read fraction of equiped irrigation area

filei <-  '/home/surface4/vyin/data/irrigation/irrig_frac/GMIA/GMIA_v5_aei_pct_CN.nc'
nci <-  open.nc(filei)
ife <-  var.get.nc(nci,'IFC')/100
close.nc(nci)

write.table(ife,'tab/ife',row.names=F,col.names=F,sep='\t')
