#read subbasin
source("lib/lib_routing.R")

info.yz <-  read.table('tab/info.subbasin.yz',header=1)

for (sb in 1:length(info.yz$LAT))
  eval(parse(text=paste0("subbasin.yz.",info.yz$NAME[sb],
                         " <-  as.matrix(read.table(\'tab/subbasin.yz.",
                         info.yz$NAME[sb],"\'))")))
