lons    <-  seq(85.25,124.25,.5)
lats    <-  seq(20.25,44.25,.5)

num.lon <-  length(lons)
num.lat <-  length(lats)

nveget  <-  13
nlon    <-  length(lons)

# ET staff
et.t.gs     <-  as.matrix(read.table('tab/et.t.gs'))
evp.t.gs    <-  as.matrix(read.table('tab/evp.t.gs'))
tsp.vs.t.gs <-  as.matrix(read.table('tab/tsp.vs.t.gs'))
eti.t.gs    <-  as.matrix(read.table('tab/eti.t.gs'))

#change the unit from mm.d-1 to mm.yr-1
et.t.gs <- et.t.gs*365 
evp.t.gs<- evp.t.gs*365 
tsp.vs.t.gs<- tsp.vs.t.gs*365 
eti.t.gs<- eti.t.gs*365 

et.t.ut     <-  as.matrix(read.table('tab/et.t.ut'))
tr.et.m.ut  <-  as.matrix(read.table('tab/tr.et.m.ut'))
p.et.m.ut   <-  as.matrix(read.table('tab/p.et.m.ut'))

#change the unit from mm.m-1 to mm.yr-1
et.t.ut <-  et.t.ut*12

dat.tmp <-  as.matrix(read.table('tab/tsp.t.gs'))
tsp.t.gs    <-  array(NA,dim=c(length(lons),length(lats),nveget))

for (i in 1:nveget)
    tsp.t.gs[,,i]   <-  dat.tmp[(num.lon*(i-1)+1):(num.lon*i),]

tsp.t.gs    <-  tsp.t.gs*365

tr.et.m.gs  <-  as.matrix(read.table('tab/tr.et.m.gs'))
tr.evp.m.gs <-  as.matrix(read.table('tab/tr.evp.m.gs'))
tr.tsp.vs.m.gs  <-  as.matrix(read.table('tab/tr.tsp.vs.m.gs'))
tr.eti.m.gs  <-  as.matrix(read.table('tab/tr.eti.m.gs'))
tr.toet.m.gs  <-  as.matrix(read.table('tab/tr.toet.m.gs'))

tr.et.m.gs4gl  <-  as.matrix(read.table('tab/tr.et.m.gs4gl'))
tr.evp.m.gs4gl <-  as.matrix(read.table('tab/tr.evp.m.gs4gl'))
tr.tsp.vs.m.gs4gl  <-  as.matrix(read.table('tab/tr.tsp.vs.m.gs4gl'))
tr.toet.m.gs4gl  <-  as.matrix(read.table('tab/tr.toet.m.gs4gl'))

p.et.m.gs   <-  as.matrix(read.table('tab/p.et.m.gs'))
p.evp.m.gs  <-  as.matrix(read.table('tab/p.evp.m.gs'))
p.tsp.vs.m.gs   <-  as.matrix(read.table('tab/p.tsp.vs.m.gs'))
p.eti.m.gs  <-  as.matrix(read.table('tab/p.eti.m.gs'))
p.toet.m.gs <-  as.matrix(read.table('tab/p.toet.m.gs'))

p.et.m.gs4gl   <-  as.matrix(read.table('tab/p.et.m.gs4gl'))
p.evp.m.gs4gl  <-  as.matrix(read.table('tab/p.evp.m.gs4gl'))
p.tsp.vs.m.gs4gl   <-  as.matrix(read.table('tab/p.tsp.vs.m.gs4gl'))
p.toet.m.gs4gl  <-  as.matrix(read.table('tab/p.toet.m.gs4gl'))

cor.et.m.gl.gs  <-  as.matrix(read.table('tab/cor.et.m.gl.gs'))
cor.evp.m.gl.gs <-  as.matrix(read.table('tab/cor.evp.m.gl.gs'))
cor.tsp.m.gl.gs <-  as.matrix(read.table('tab/cor.tsp.m.gl.gs'))

p.et.m.gl.gs  <-  as.matrix(read.table('tab/p.et.m.gl.gs'))
p.evp.m.gl.gs <-  as.matrix(read.table('tab/p.evp.m.gl.gs'))
p.tsp.m.gl.gs <-  as.matrix(read.table('tab/p.tsp.m.gl.gs'))

rmse.et.m.gl.gs <-  as.matrix(read.table('tab/rmse.et.m.gl.gs'))
rdif.et.m.gl.gs <-  as.matrix(read.table('tab/rdif.et.m.gl.gs'))
sb.et.m.gl.gs   <-  as.matrix(read.table('tab/sb.et.m.gl.gs'))
sdsd.et.m.gl.gs <-  as.matrix(read.table('tab/sdsd.et.m.gl.gs'))
lcs.et.m.gl.gs  <-  as.matrix(read.table('tab/lcs.et.m.gl.gs'))

rmse.evp.m.gl.gs <-  as.matrix(read.table('tab/rmse.evp.m.gl.gs'))
rdif.evp.m.gl.gs <-  as.matrix(read.table('tab/rdif.evp.m.gl.gs'))
sb.evp.m.gl.gs   <-  as.matrix(read.table('tab/sb.evp.m.gl.gs'))
sdsd.evp.m.gl.gs <-  as.matrix(read.table('tab/sdsd.evp.m.gl.gs'))
lcs.evp.m.gl.gs  <-  as.matrix(read.table('tab/lcs.evp.m.gl.gs'))

rmse.tsp.m.gl.gs <-  as.matrix(read.table('tab/rmse.tsp.m.gl.gs'))
rdif.tsp.m.gl.gs <-  as.matrix(read.table('tab/rdif.tsp.m.gl.gs'))
sb.tsp.m.gl.gs   <-  as.matrix(read.table('tab/sb.tsp.m.gl.gs'))
sdsd.tsp.m.gl.gs <-  as.matrix(read.table('tab/sdsd.tsp.m.gl.gs'))
lcs.tsp.m.gl.gs  <-  as.matrix(read.table('tab/lcs.tsp.m.gl.gs'))


tr.tmp  <-  as.matrix(read.table('tab/tr.tsp.m.gs'))
p.tmp   <-  as.matrix(read.table('tab/p.tsp.m.gs'))

cor.et.m.ut.gs  <-  as.matrix(read.table('tab/cor.et.m.ut.gs'))
p.et.m.ut.gs    <-  as.matrix(read.table('tab/p.et.m.ut.gs'))

rmse.et.m.ut.gs <-  as.matrix(read.table('tab/rmse.et.m.ut.gs'))
rdif.et.m.ut.gs <-  as.matrix(read.table('tab/rdif.et.m.ut.gs'))
sb.et.m.ut.gs   <-  as.matrix(read.table('tab/sb.et.m.ut.gs'))
sdsd.et.m.ut.gs <-  as.matrix(read.table('tab/sdsd.et.m.ut.gs'))
lcs.et.m.ut.gs  <-  as.matrix(read.table('tab/lcs.et.m.ut.gs'))

tr.tsp.m.gs <-  array(NA,dim=c(length(lons),length(lats),nveget))
p.tsp.m.gs  <-  array(NA,dim=c(length(lons),length(lats),nveget))

for (i in 1:nveget)
{
    tr.tsp.m.gs[,,i]    <-  tr.tmp[(num.lon*(i-1)+1):(num.lon*i),]
    p.tsp.m.gs[,,i]     <-  p.tmp[(num.lon*(i-1)+1):(num.lon*i),]
}

rm(dat.tmp,tr.tmp,p.tmp)

et.t.gl     <-  as.matrix(read.table('tab/et.t.gl'))
evp.t.gl    <-  as.matrix(read.table('tab/evp.t.gl'))
tsp.t.gl    <-  as.matrix(read.table('tab/tsp.t.gl'))
eti.t.gl    <-  as.matrix(read.table('tab/eti.t.gl'))

et.t.gl     <-  et.t.gl*365
evp.t.gl    <-  evp.t.gl*365
tsp.t.gl    <-  tsp.t.gl*365
eti.t.gl    <-  eti.t.gl*365

tr.et.m.gl     <-  as.matrix(read.table('tab/tr.et.m.gl'))
tr.evp.m.gl    <-  as.matrix(read.table('tab/tr.evp.m.gl'))
tr.tsp.m.gl    <-  as.matrix(read.table('tab/tr.tsp.m.gl'))

tr.et.m.gl4gs     <-  as.matrix(read.table('tab/tr.et.m.gl4gs'))
tr.evp.m.gl4gs    <-  as.matrix(read.table('tab/tr.evp.m.gl4gs'))
tr.tsp.m.gl4gs    <-  as.matrix(read.table('tab/tr.tsp.m.gl4gs'))

p.et.m.gl     <-  as.matrix(read.table('tab/p.et.m.gl'))
p.evp.m.gl    <-  as.matrix(read.table('tab/p.evp.m.gl'))
p.tsp.m.gl    <-  as.matrix(read.table('tab/p.tsp.m.gl'))

p.et.m.gl4gs     <-  as.matrix(read.table('tab/p.et.m.gl4gs'))
p.evp.m.gl4gs    <-  as.matrix(read.table('tab/p.evp.m.gl4gs'))
p.tsp.m.gl4gs    <-  as.matrix(read.table('tab/p.tsp.m.gl4gs'))

#read regional time series data
et.cn.m.gs <-  as.vector(as.matrix(read.table('tab/et.cn.m.gs')))*365
et.cn.a.gs <-  as.vector(as.matrix(read.table('tab/et.cn.a.gs')))*365
et.yz.m.gs <-  as.vector(as.matrix(read.table('tab/et.yz.m.gs')))*365
et.yz.a.gs <-  as.vector(as.matrix(read.table('tab/et.yz.a.gs')))*365
et.yl.m.gs <-  as.vector(as.matrix(read.table('tab/et.yl.m.gs')))*365
et.yl.a.gs <-  as.vector(as.matrix(read.table('tab/et.yl.a.gs')))*365

evp.cn.m.gs <-  as.vector(as.matrix(read.table('tab/evp.cn.m.gs')))*365
evp.cn.a.gs <-  as.vector(as.matrix(read.table('tab/evp.cn.a.gs')))*365
evp.yz.m.gs <-  as.vector(as.matrix(read.table('tab/evp.yz.m.gs')))*365
evp.yz.a.gs <-  as.vector(as.matrix(read.table('tab/evp.yz.a.gs')))*365
evp.yl.m.gs <-  as.vector(as.matrix(read.table('tab/evp.yl.m.gs')))*365
evp.yl.a.gs <-  as.vector(as.matrix(read.table('tab/evp.yl.a.gs')))*365

etp.cn.m.gs <-  as.vector(as.matrix(read.table('tab/etp.cn.m.gs')))*365
etp.cn.a.gs <-  as.vector(as.matrix(read.table('tab/etp.cn.a.gs')))*365
etp.yz.m.gs <-  as.vector(as.matrix(read.table('tab/etp.yz.m.gs')))*365
etp.yz.a.gs <-  as.vector(as.matrix(read.table('tab/etp.yz.a.gs')))*365
etp.yl.m.gs <-  as.vector(as.matrix(read.table('tab/etp.yl.m.gs')))*365
etp.yl.a.gs <-  as.vector(as.matrix(read.table('tab/etp.yl.a.gs')))*365

tsp.cn.m.gs <-  as.vector(as.matrix(read.table('tab/tsp.cn.m.gs')))*365
tsp.cn.a.gs <-  as.vector(as.matrix(read.table('tab/tsp.cn.a.gs')))*365
tsp.yz.m.gs <-  as.vector(as.matrix(read.table('tab/tsp.yz.m.gs')))*365
tsp.yz.a.gs <-  as.vector(as.matrix(read.table('tab/tsp.yz.a.gs')))*365
tsp.yl.m.gs <-  as.vector(as.matrix(read.table('tab/tsp.yl.m.gs')))*365
tsp.yl.a.gs <-  as.vector(as.matrix(read.table('tab/tsp.yl.a.gs')))*365

tsp.vs.cn.m.gs <-  as.vector(as.matrix(read.table('tab/tsp.vs.cn.m.gs')))*365
tsp.vs.cn.a.gs <-  as.vector(as.matrix(read.table('tab/tsp.vs.cn.a.gs')))*365
tsp.vs.yz.m.gs <-  as.vector(as.matrix(read.table('tab/tsp.vs.yz.m.gs')))*365
tsp.vs.yz.a.gs <-  as.vector(as.matrix(read.table('tab/tsp.vs.yz.a.gs')))*365
tsp.vs.yl.m.gs <-  as.vector(as.matrix(read.table('tab/tsp.vs.yl.m.gs')))*365
tsp.vs.yl.a.gs <-  as.vector(as.matrix(read.table('tab/tsp.vs.yl.a.gs')))*365

et.cn.a.ut <-  as.vector(as.matrix(read.table('tab/et.cn.a.ut')))*12
et.cn.m.ut <-  as.vector(as.matrix(read.table('tab/et.cn.m.ut')))*12
et.yz.a.ut <-  as.vector(as.matrix(read.table('tab/et.yz.a.ut')))*12
et.yz.m.ut <-  as.vector(as.matrix(read.table('tab/et.yz.m.ut')))*12
et.yl.a.ut <-  as.vector(as.matrix(read.table('tab/et.yl.a.ut')))*12
et.yl.m.ut <-  as.vector(as.matrix(read.table('tab/et.yl.m.ut')))*12

et.cn.a.gl  <-  as.vector(as.matrix(read.table('tab/et.cn.a.gl')))*365
evp.cn.a.gl <-  as.vector(as.matrix(read.table('tab/evp.cn.a.gl')))*365
etp.cn.a.gl <-  as.vector(as.matrix(read.table('tab/etp.cn.a.gl')))*365
tsp.cn.a.gl <-  as.vector(as.matrix(read.table('tab/tsp.cn.a.gl')))*365

et.yz.a.gl  <-  as.vector(as.matrix(read.table('tab/et.yz.a.gl')))*365
evp.yz.a.gl <-  as.vector(as.matrix(read.table('tab/evp.yz.a.gl')))*365
etp.yz.a.gl <-  as.vector(as.matrix(read.table('tab/etp.yz.a.gl')))*365
tsp.yz.a.gl <-  as.vector(as.matrix(read.table('tab/tsp.yz.a.gl')))*365

et.yl.a.gl  <-  as.vector(as.matrix(read.table('tab/et.yl.a.gl')))*365
evp.yl.a.gl <-  as.vector(as.matrix(read.table('tab/evp.yl.a.gl')))*365
etp.yl.a.gl <-  as.vector(as.matrix(read.table('tab/etp.yl.a.gl')))*365
tsp.yl.a.gl <-  as.vector(as.matrix(read.table('tab/tsp.yl.a.gl')))*365

et.cn.m.gl  <-  as.vector(as.matrix(read.table('tab/et.cn.m.gl')))*365
evp.cn.m.gl <-  as.vector(as.matrix(read.table('tab/evp.cn.m.gl')))*365
etp.cn.m.gl <-  as.vector(as.matrix(read.table('tab/etp.cn.m.gl')))*365
tsp.cn.m.gl <-  as.vector(as.matrix(read.table('tab/tsp.cn.m.gl')))*365

et.yz.m.gl  <-  as.vector(as.matrix(read.table('tab/et.yz.m.gl')))*365
evp.yz.m.gl <-  as.vector(as.matrix(read.table('tab/evp.yz.m.gl')))*365
etp.yz.m.gl <-  as.vector(as.matrix(read.table('tab/etp.yz.m.gl')))*365
tsp.yz.m.gl <-  as.vector(as.matrix(read.table('tab/tsp.yz.m.gl')))*365

et.yl.m.gl  <-  as.vector(as.matrix(read.table('tab/et.yl.m.gl')))*365
evp.yl.m.gl <-  as.vector(as.matrix(read.table('tab/evp.yl.m.gl')))*365
etp.yl.m.gl <-  as.vector(as.matrix(read.table('tab/etp.yl.m.gl')))*365
tsp.yl.m.gl <-  as.vector(as.matrix(read.table('tab/tsp.yl.m.gl')))*365

#et.cn.d.gl  <-  as.vector(as.matrix(read.table('tab/et.cn.d.gl')))
#evp.cn.d.gl <-  as.vector(as.matrix(read.table('tab/evp.cn.d.gl')))
#tsp.cn.d.gl <-  as.vector(as.matrix(read.table('tab/tsp.cn.d.gl')))
#
#et.yz.d.gl  <-  as.vector(as.matrix(read.table('tab/et.yz.d.gl')))
#evp.yz.d.gl <-  as.vector(as.matrix(read.table('tab/evp.yz.d.gl')))
#tsp.yz.d.gl <-  as.vector(as.matrix(read.table('tab/tsp.yz.d.gl')))

#et.yl.d.gl  <-  as.vector(as.matrix(read.table('tab/et.yl.d.gl')))
#evp.yl.d.gl <-  as.vector(as.matrix(read.table('tab/evp.yl.d.gl')))
#tsp.yl.d.gl <-  as.vector(as.matrix(read.table('tab/tsp.yl.d.gl')))

time.a.gs   <-  seq(as.Date('1971-01-01'),as.Date('2010-12-01'),by='years')
time.m.gs   <-  seq(as.Date('1971-01-15'),as.Date('2010-12-15'),by='months')
time.d.gs   <-  seq(as.Date('1971-01-01'),as.Date('2010-12-31'),by='days')

# remove leap days
time.d.gs   <-  time.d.gs[format(time.d.gs, '%m %d') != '02 29']

time.a.ut   <-  seq(as.Date('2001-01-01'),as.Date('2015-12-01'),by='years')
time.m.ut   <-  seq(as.Date('2001-01-15'),as.Date('2015-12-15'),by='months')

time.a.gl   <-  seq(as.Date('1980-01-01'),as.Date('2015-12-01'),by='years')
time.m.gl   <-  seq(as.Date('1980-01-15'),as.Date('2015-12-15'),by='months')

#Runoff, precipitation staff
pre.t.gs    <-  as.matrix(read.table('tab/pre.t.gs'))
run.t.gs    <-  as.matrix(read.table('tab/run.t.gs'))
dra.t.gs    <-  as.matrix(read.table('tab/dra.t.gs'))

pre.t.gl    <-  as.matrix(read.table('tab/pre.t.gl'))


tr.pre.m.gs <-  as.matrix(read.table('tab/tr.pre.m.gs'))
tr.run.m.gs <-  as.matrix(read.table('tab/tr.run.m.gs'))
tr.dra.m.gs <-  as.matrix(read.table('tab/tr.dra.m.gs'))
tr.pre.m.gl <-  as.matrix(read.table('tab/tr.pre.m.gl'))

p.pre.m.gs <-  as.matrix(read.table('tab/p.pre.m.gs'))
p.run.m.gs <-  as.matrix(read.table('tab/p.run.m.gs'))
p.dra.m.gs <-  as.matrix(read.table('tab/p.dra.m.gs'))
p.pre.m.gl <-  as.matrix(read.table('tab/p.pre.m.gl'))

#regional runoff data
pre.cn.m.gs <-  as.vector(as.matrix(read.table('tab/pre.cn.m.gs')))
pre.cn.a.gs <-  as.vector(as.matrix(read.table('tab/pre.cn.a.gs')))
run.cn.m.gs <-  as.vector(as.matrix(read.table('tab/run.cn.m.gs')))
run.cn.a.gs <-  as.vector(as.matrix(read.table('tab/run.cn.a.gs')))
dra.cn.m.gs <-  as.vector(as.matrix(read.table('tab/dra.cn.m.gs')))
dra.cn.a.gs <-  as.vector(as.matrix(read.table('tab/dra.cn.a.gs')))
pre.cn.m.gl <-  as.vector(as.matrix(read.table('tab/pre.cn.m.gl')))
pre.cn.a.gl <-  as.vector(as.matrix(read.table('tab/pre.cn.a.gl')))

pre.yz.m.gs <-  as.vector(as.matrix(read.table('tab/pre.yz.m.gs')))
pre.yz.a.gs <-  as.vector(as.matrix(read.table('tab/pre.yz.a.gs')))
run.yz.m.gs <-  as.vector(as.matrix(read.table('tab/run.yz.m.gs')))
run.yz.a.gs <-  as.vector(as.matrix(read.table('tab/run.yz.a.gs')))
dra.yz.m.gs <-  as.vector(as.matrix(read.table('tab/dra.yz.m.gs')))
dra.yz.a.gs <-  as.vector(as.matrix(read.table('tab/dra.yz.a.gs')))
pre.yz.m.gl <-  as.vector(as.matrix(read.table('tab/pre.yz.m.gl')))
pre.yz.a.gl <-  as.vector(as.matrix(read.table('tab/pre.yz.a.gl')))

pre.yl.m.gs <-  as.vector(as.matrix(read.table('tab/pre.yl.m.gs')))
pre.yl.a.gs <-  as.vector(as.matrix(read.table('tab/pre.yl.a.gs')))
run.yl.m.gs <-  as.vector(as.matrix(read.table('tab/run.yl.m.gs')))
run.yl.a.gs <-  as.vector(as.matrix(read.table('tab/run.yl.a.gs')))
dra.yl.m.gs <-  as.vector(as.matrix(read.table('tab/dra.yl.m.gs')))
dra.yl.a.gs <-  as.vector(as.matrix(read.table('tab/dra.yl.a.gs')))
pre.yl.m.gl <-  as.vector(as.matrix(read.table('tab/pre.yl.m.gl')))
pre.yl.a.gl <-  as.vector(as.matrix(read.table('tab/pre.yl.a.gl')))

#runoff over precipitation staff
qop.t.gs    <-  as.matrix(read.table('tab/qop.t.gs'))
tr.qop.m.gs <-  as.matrix(read.table('tab/tr.qop.m.gs'))
p.qop.m.gs  <-  as.matrix(read.table('tab/p.qop.m.gs'))

#regional data
qop.cn.m.gs <-  as.vector(as.matrix(read.table('tab/qop.cn.m.gs')))
qop.cn.a.gs <-  as.vector(as.matrix(read.table('tab/qop.cn.a.gs')))
qop.yz.m.gs <-  as.vector(as.matrix(read.table('tab/qop.yz.m.gs')))
qop.yz.a.gs <-  as.vector(as.matrix(read.table('tab/qop.yz.a.gs')))
qop.yl.m.gs <-  as.vector(as.matrix(read.table('tab/qop.yl.m.gs')))
qop.yl.a.gs <-  as.vector(as.matrix(read.table('tab/qop.yl.a.gs')))

#w from budyco curve
w.cn.a.gs   <-  as.vector(as.matrix(read.table('tab/w.cn.a.gs')))
w.yz.a.gs   <-  as.vector(as.matrix(read.table('tab/w.yz.a.gs')))
w.yl.a.gs   <-  as.vector(as.matrix(read.table('tab/w.yl.a.gs')))

w.cn.a.gl   <-  as.vector(as.matrix(read.table('tab/w.cn.a.gl')))
w.yz.a.gl   <-  as.vector(as.matrix(read.table('tab/w.yz.a.gl')))
w.yl.a.gl   <-  as.vector(as.matrix(read.table('tab/w.yl.a.gl')))

#lai of GIMMS
time.m.gi   =   seq(as.Date('1982-01-15'),as.Date('2011-12-15'),by='months')
time.a.gi   =   seq(as.Date('1982-01-01'),as.Date('2011-01-01'),by='years')
lai.t.gi    <-  as.matrix(read.table('tab/lai.t.gi'))
tr.lai.m.gi <-  as.matrix(read.table('tab/tr.lai.m.gi'))
p.lai.m.gi  <-  as.matrix(read.table('tab/p.lai.m.gi'))

tr.lai.m.gi4gs <-  as.matrix(read.table('tab/tr.lai.m.gi4gs'))
p.lai.m.gi4gs  <-  as.matrix(read.table('tab/p.lai.m.gi4gs'))

lai.cn.m.gi <-  as.vector(as.matrix(read.table('tab/lai.cn.m.gi')))
lai.yl.m.gi <-  as.vector(as.matrix(read.table('tab/lai.yl.m.gi')))
lai.yz.m.gi <-  as.vector(as.matrix(read.table('tab/lai.yz.m.gi')))

lai.cn.a.gi <-  as.vector(as.matrix(read.table('tab/lai.cn.a.gi')))
lai.yl.a.gi <-  as.vector(as.matrix(read.table('tab/lai.yl.a.gi')))
lai.yz.a.gi <-  as.vector(as.matrix(read.table('tab/lai.yz.a.gi')))

#LAI from orchidee
lai.vm.t.gs <-  as.matrix(read.table('tab/lai.vm.t.gs'))
lai.sm.t.gs <-  as.matrix(read.table('tab/lai.sm.t.gs'))

tr.lai.vm.m.gs  <-  as.matrix(read.table('tab/tr.lai.vm.m.gs'))
p.lai.vm.m.gs   <-  as.matrix(read.table('tab/p.lai.vm.m.gs'))

tr.lai.vm.m.gs4gi  <-  as.matrix(read.table('tab/tr.lai.vm.m.gs4gi'))
p.lai.vm.m.gs4gi   <-  as.matrix(read.table('tab/p.lai.vm.m.gs4gi'))

tr.lai.sm.m.gs  <-  as.matrix(read.table('tab/tr.lai.sm.m.gs'))
p.lai.sm.m.gs   <-  as.matrix(read.table('tab/p.lai.sm.m.gs'))

tr.lai.m.gs <-  array(NA,dim=c(dim(tr.lai.vm.m.gs),nveget))
p.lai.m.gs  <-  array(NA,dim=c(dim(tr.lai.vm.m.gs),nveget))

t.tmp   <-  as.matrix(read.table('tab/tr.lai.m.gs'))
p.tmp   <-  as.matrix(read.table('tab/p.lai.m.gs'))
for (i in 1:nveget)
{
    tr.lai.m.gs[,,i]    <-  t.tmp[(nlon*(i-1)+1):(nlon*i),]
    p.lai.m.gs[,,i]     <-  p.tmp[(nlon*(i-1)+1):(nlon*i),]
}

lai.vm.cn.m.gs  <-  as.vector(as.matrix(read.table('tab/lai.vm.cn.m.gs')))
lai.vm.yl.m.gs  <-  as.vector(as.matrix(read.table('tab/lai.vm.yl.m.gs')))
lai.vm.yz.m.gs  <-  as.vector(as.matrix(read.table('tab/lai.vm.yz.m.gs')))

lai.vm.cn.a.gs  <-  as.vector(as.matrix(read.table('tab/lai.vm.cn.a.gs')))
lai.vm.yl.a.gs  <-  as.vector(as.matrix(read.table('tab/lai.vm.yl.a.gs')))
lai.vm.yz.a.gs  <-  as.vector(as.matrix(read.table('tab/lai.vm.yz.a.gs')))

#cor LAI between ORC and GIMMS
cor.lai.gi.gs   <-  as.matrix(read.table('tab/cor.lai.gi.gs'))
p.lai.gi.gs     <-  as.matrix(read.table('tab/p.lai.gi.gs'))

rdif.lai.gi.gs  <-  as.matrix(read.table('tab/rdif.lai.gi.gs'))
rmse.lai.gi.gs  <-  as.matrix(read.table('tab/rmse.lai.gi.gs'))
sb.lai.gi.gs    <-  as.matrix(read.table('tab/sb.lai.gi.gs'))
sdsd.lai.gi.gs  <-  as.matrix(read.table('tab/sdsd.lai.gi.gs'))
lcs.lai.gi.gs   <-  as.matrix(read.table('tab/lcs.lai.gi.gs'))

#TWS
tws.cn.m.gs <-  as.vector(as.matrix(read.table('tab/tws.cn.m.gs')))
tws.yl.m.gs <-  as.vector(as.matrix(read.table('tab/tws.yl.m.gs')))
tws.yz.m.gs <-  as.vector(as.matrix(read.table('tab/tws.yz.m.gs')))

tws.cn.a.gs <-  as.vector(as.matrix(read.table('tab/tws.cn.a.gs')))
tws.yl.a.gs <-  as.vector(as.matrix(read.table('tab/tws.yl.a.gs')))
tws.yz.a.gs <-  as.vector(as.matrix(read.table('tab/tws.yz.a.gs')))

tws.cn.m.csr <-  as.vector(as.matrix(read.table('tab/tws.cn.m.csr')))*10
tws.yl.m.csr <-  as.vector(as.matrix(read.table('tab/tws.yl.m.csr')))*10
tws.yz.m.csr <-  as.vector(as.matrix(read.table('tab/tws.yz.m.csr')))*10

tws.cn.a.csr <-  as.vector(as.matrix(read.table('tab/tws.cn.a.csr')))*10
tws.yl.a.csr <-  as.vector(as.matrix(read.table('tab/tws.yl.a.csr')))*10
tws.yz.a.csr <-  as.vector(as.matrix(read.table('tab/tws.yz.a.csr')))*10


cor.tws.m.gs.csr    <-  as.matrix(read.table('tab/cor.tws.m.gs.csr'))
p.tws.m.gs.csr      <-  as.matrix(read.table('tab/p.tws.m.gs.csr'))

tr.tws.m.gs4cs  <-  as.matrix(read.table('tab/tr.tws.m.gs4cs'))
p.tws.m.gs4cs   <-  as.matrix(read.table('tab/p.tws.m.gs4cs'))

tr.tws.m.csr4gs  <-  as.matrix(read.table('tab/tr.tws.m.csr4gs'))
p.tws.m.csr4gs   <-  as.matrix(read.table('tab/p.tws.m.csr4gs'))
