#read province fraction data

library(RNetCDF)

filei   <-  'tab/pro_frac.nc'
nc  <-  open.nc(filei)

frac    <-  var.get.nc(nc,'frac')

close.nc(nc)
