#try to analysis water balance in each subbasin of Yangtze River
#subbasin including: JINSHA, MIN, JIALING, WU, HAN, XIANG, GAN, YZ
library(RNetCDF)

#water balance include: preciptation, et, dischargeo
#the unit of pre and et is mm.yr-1 will be changed to km^3.yr-1
#the unit of dis is m3/s

#m^3.yr-1 to kilo km^3.yr-1
m2kkm <-  1e-12

if (!exists("subbasin.yz.MIN"))
{
  source("lib/lib_parameters.R")
  source("read/area/read_area_tab.R")
  source("read/pre/read_pre_tab.R")
  source("read/et/read_et_tab.R")
  source("read/dis/read_dis_tab.R")
  source("read/routing/read_subbasin_tab.R")
}

#get the discharge of each subbassin
dis.yz.t.hh <-  apply(dis.yz.a.hh,1,mean,na.rm=T)
dis.yz.t.ni <-  apply(dis.yz.a.ni,1,mean,na.rm=T)
dis.yz.t.ir <-  apply(dis.yz.a.ir,1,mean,na.rm=T)

dis.yl.t.hh <-  apply(dis.yl.a.hh,1,mean,na.rm=T)
dis.yl.t.ni <-  apply(dis.yl.a.ni,1,mean,na.rm=T)
dis.yl.t.ir <-  apply(dis.yl.a.ir,1,mean,na.rm=T)

#JINSHA:  PINGSHAN 7
#MIN:     GAOCHANG 15
#JIALING: BEIBEI   2
#WU:      WULONG   10
#HAN:     HUANGZHUANG 14
#XIANG:   CHENGLINGJI 3
#GAN:     HUKOU 13
#YZ:      DATONG  4

dis.sb.yz.hh  <-  c(dis.yz.t.hh[7],
                    dis.yz.t.hh[15],
                    dis.yz.t.hh[2],
                    dis.yz.t.hh[10],
                    dis.yz.t.hh[14],
                    dis.yz.t.hh[3],
                    dis.yz.t.hh[13],
                    dis.yz.t.hh[4])

dis.sb.yz.ni  <-  c(dis.yz.t.ni[7],
                    dis.yz.t.ni[15],
                    dis.yz.t.ni[2],
                    dis.yz.t.ni[10],
                    dis.yz.t.ni[14],
                    dis.yz.t.ni[3],
                    dis.yz.t.ni[13],
                    dis.yz.t.ni[4])

dis.sb.yz.ir  <-  c(dis.yz.t.ir[7],
                    dis.yz.t.ir[15],
                    dis.yz.t.ir[2],
                    dis.yz.t.ir[10],
                    dis.yz.t.ir[14],
                    dis.yz.t.ir[3],
                    dis.yz.t.ir[13],
                    dis.yz.t.ir[4])

#get the region of subbasin rest
subbasin.yz.REST  <-  subbasin.yz.OUT -
                      subbasin.yz.JINSHA -
                      subbasin.yz.MIN -
                      subbasin.yz.JIALING -
                      subbasin.yz.WU -
                      subbasin.yz.HAN -
                      subbasin.yz.XIANG -
                      subbasin.yz.GAN

#calculate pre of each subbasin
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.JINSHA,na.rm=T)
pre.sb.yz <-  v.tmp
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.MIN,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.JIALING,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.WU,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.HAN,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.XIANG,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.GAN,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)
v.tmp <-  sum(pre.t.orc*area.orc*subbasin.yz.OUT,na.rm=T)
pre.sb.yz <-  c(pre.sb.yz,v.tmp)

pre.sb.yz <-  pre.sb.yz*m2kkm

#calculate pre of each subbasin
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.JINSHA,na.rm=T)
pre.sb.yz.ms <-  v.tmp
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.MIN,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.JIALING,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.WU,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.HAN,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.XIANG,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.GAN,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)
v.tmp <-  sum(pre.t.ms*area.orc*subbasin.yz.OUT,na.rm=T)
pre.sb.yz.ms <-  c(pre.sb.yz.ms,v.tmp)

pre.sb.yz.ms <-  pre.sb.yz.ms*m2kkm
#calculate et of each subbasin
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.JINSHA,na.rm=T)
et.sb.yz.ni <-  v.tmp
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.MIN,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.JIALING,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.WU,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.HAN,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.XIANG,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.GAN,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)
v.tmp <-  sum(et.t.ni*area.orc*subbasin.yz.OUT,na.rm=T)
et.sb.yz.ni <-  c(et.sb.yz.ni,v.tmp)

et.sb.yz.ni <-  et.sb.yz.ni*m2kkm

#calculate et of each subbasin
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.JINSHA,na.rm=T)
et.sb.yz.mp <-  v.tmp
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.MIN,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.JIALING,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.WU,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.HAN,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.XIANG,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.GAN,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)
v.tmp <-  sum(et.t.mp*area.orc*subbasin.yz.OUT,na.rm=T)
et.sb.yz.mp <-  c(et.sb.yz.mp,v.tmp)


et.sb.yz.mp <-  et.sb.yz.mp*m2kkm

#calculate et of each subbasin
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.JINSHA,na.rm=T)
et.sb.yz.gl <-  v.tmp
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.MIN,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.JIALING,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.WU,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.HAN,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.XIANG,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.GAN,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)
v.tmp <-  sum(et.t.gl*area.orc*subbasin.yz.OUT,na.rm=T)
et.sb.yz.gl <-  c(et.sb.yz.gl,v.tmp)

et.sb.yz.gl <-  et.sb.yz.gl*m2kkm

#calculate et of each subbasin
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.JINSHA,na.rm=T)
et.sb.yz.ut <-  v.tmp
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.MIN,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.JIALING,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.WU,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.HAN,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.XIANG,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.GAN,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)
v.tmp <-  sum(et.t.ut*area.orc*subbasin.yz.OUT,na.rm=T)
et.sb.yz.ut <-  c(et.sb.yz.ut,v.tmp)

et.sb.yz.ut <-  et.sb.yz.ut*m2kkm

#make a matrix include all basinmap
#WHOLE BASIN = 1
basin.all <-  subbasin.yz.OUT
#JINSHA = 2
basin.all <-  basin.all+subbasin.yz.JINSHA
#MIN  = 3
basin.all <-  basin.all+subbasin.yz.MIN*2
#JIALING  = 4
basin.all <-  basin.all+subbasin.yz.JIALING*3
#WU = 5
basin.all <-  basin.all+subbasin.yz.WU*4
#HAN  = 6
basin.all <-  basin.all+subbasin.yz.HAN*5
#XIANG  = 7
basin.all <-  basin.all+subbasin.yz.XIANG*6
#GAN = 8
basin.all <-  basin.all+subbasin.yz.GAN*7
