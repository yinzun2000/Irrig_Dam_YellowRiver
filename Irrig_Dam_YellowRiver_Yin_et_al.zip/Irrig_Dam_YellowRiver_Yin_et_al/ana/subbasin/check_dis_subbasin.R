#follow Philippe's idea:
# chose several sites on the Yangtze river and compare the bias of discharge
# check if the bias at upper station is the main reason of the bias at the down station
# also check the evaporation of the difference of the two basin

#7 stations are chosen
#1: Pingshan 7;
#2: Zhutuo 8;
#3: Yichang 5;
#4: Hankou 11;
#5: Datong 4;

#Cuntan 6; delete, hard to find it

#for Yellow river we chose
#1: Tangnaihai 23;
#2: LanZhou 17;
#3: Toudaoguai 21;
#4: Huayuankou 11;
#5: Lijin 13;

idx.st  <-  c(7,8,5,11,4)

if (!exists("dis.yz.m.hh"))
{
  source("read/dis/read_dis_tab.R")
  source("read/pre/read_pre_tab.R")
  source("read/area/read_area_tab.R")
  source("read/et/read_et_tab.R")
  source("read/run/read_run_tab.R")
  source("read/dra/read_dra_tab.R")
  source("read/tws/read_tws_tab.R")
  source("read/subregion/read_subregion_tab.R")
  #interpolation the hhu discharge at pingshan station

  t1.tmp  <-  dis.yz.m.hh[idx.st[1],]
  t2.tmp  <-  dis.yz.m.hh[idx.st[2],]
  lm.tmp  <-  lm(t1.tmp~t2.tmp)
  int.tmp <-  as.numeric(lm.tmp$coefficients[1])
  rat.tmp <-  as.numeric(lm.tmp$coefficients[2])
  t1.tmp[is.na(t1.tmp)] <-  int.tmp+rat.tmp*t2.tmp[is.na(t1.tmp)]
  dis.yz.m.hh[idx.st[1],] <-  t1.tmp

  t1.tmp  <-  dis.yz.a.hh[idx.st[1],]
  t2.tmp  <-  dis.yz.a.hh[idx.st[2],]
  lm.tmp  <-  lm(t1.tmp~t2.tmp)
  int.tmp <-  as.numeric(lm.tmp$coefficients[1])
  rat.tmp <-  as.numeric(lm.tmp$coefficients[2])
  t1.tmp[is.na(t1.tmp)] <-  int.tmp+rat.tmp*t2.tmp[is.na(t1.tmp)]
  dis.yz.a.hh[idx.st[1],] <-  t1.tmp

  #take the discharge data from 1982-2000
  dis.yz.m.oc <-  dis.yz.m.oc[,1:228]
  dis.yz.m.ni <-  dis.yz.m.ni[,1:228]
  dis.yz.m.ir <-  dis.yz.m.ir[,1:228]

  #read tws data
  tws.subbasin.yz.m.oc  <-  as.matrix(read.table("tab/tws.subbasin.yz.m.oc"))
  tws.subbasin.yz.a.oc  <-  as.matrix(read.table("tab/tws.subbasin.yz.a.oc"))
  tws.subbasin.yz.m.csr  <-  as.matrix(read.table("tab/tws.subbasin.yz.m.csr"))
  tws.subbasin.yz.a.csr  <-  as.matrix(read.table("tab/tws.subbasin.yz.a.csr"))

  tws.subbasin.yz.m.jpl  <-  as.matrix(read.table("tab/tws.subbasin.yz.m.jpl"))
  tws.subbasin.yz.a.jpl  <-  as.matrix(read.table("tab/tws.subbasin.yz.a.jpl"))
}

source("lib/lib_routing.R")

#read location of each station
lon.yz.orc  <-  as.matrix(read.table('tab/longitude.yz.orc'))
lat.yz.orc  <-  as.matrix(read.table('tab/latitude.yz.orc'))

lon.yz.orc  <-  lon.yz.orc[,1]
lat.yz.orc  <-  lat.yz.orc[,1]

if (!exists('subbasin.yz.st'))
{
  subbasin.yz.st  <-  array(0,dim=c(length(lon.r),length(lat.r),length(idx.st)))  #lon*lat*num.station

  for (i in 1:length(idx.st))
    subbasin.yz.st[,,i] <- FindBasin(lon.yz.orc[idx.st[i]],lat.yz.orc[idx.st[i]],fd,lons,lats,lon.r,lat.r)

  #for Pingshan, We should add another point for basin
  sub.tmp <- FindBasin(103.75,28.25,fd,lons,lats,lon.r,lat.r)
  subbasin.yz.st[,,1] <-  BasinCombine(subbasin.yz.st[,,1],sub.tmp)

  rm('sub.tmp')
}

#calculate the magnitude of observed and simulated discharge [m3/s]
mag.tmp <-  apply(dis.yz.a.hh,1,mean,na.rm=T)
mag.dis.yz.hh <-  mag.tmp[idx.st]
mag.tmp <-  apply(dis.yz.a.ni,1,mean,na.rm=T)
mag.dis.yz.ni <-  mag.tmp[idx.st]
mag.tmp <-  apply(dis.yz.a.ir,1,mean,na.rm=T)
mag.dis.yz.ir <-  mag.tmp[idx.st]

#calculate the sum of runoff and drainage
#change the unit of runoff and drainage from mm*m^2/yr to m3/s
mm2ms <-  1e-3/(3600*24*365)
pre.subbasin.yz.st.orc<-  array(0,length(idx.st))
et.subbasin.yz.st.ni  <-  array(0,length(idx.st))
run.subbasin.yz.st.ni <-  array(0,length(idx.st))
dra.subbasin.yz.st.ni <-  array(0,length(idx.st))

et.subbasin.yz.st.ir  <-  array(0,length(idx.st))
run.subbasin.yz.st.ir <-  array(0,length(idx.st))
dra.subbasin.yz.st.ir <-  array(0,length(idx.st))

for (i in 1:length(idx.st))
{
  pre.subbasin.yz.st.orc[i]   <-  sum(area.orc*pre.t.orc*
                                      subbasin.yz.st[,,i],
                                      na.rm=T)*mm2ms
  et.subbasin.yz.st.ni[i] <-  sum(area.orc*et.t.ni*subbasin.yz.st[,,i],
                                na.rm=T)*mm2ms
  run.subbasin.yz.st.ni[i]<-  sum(area.orc*run.t.ni*subbasin.yz.st[,,i],
                                na.rm=T)*mm2ms
  dra.subbasin.yz.st.ni[i]<-  sum(area.orc*dra.t.ni*subbasin.yz.st[,,i],
                                na.rm=T)*mm2ms
  et.subbasin.yz.st.ir[i] <-  sum(area.orc*et.t.ir*subbasin.yz.st[,,i],
                                na.rm=T)*mm2ms
  run.subbasin.yz.st.ir[i]<-  sum(area.orc*run.t.ir*subbasin.yz.st[,,i],
                                na.rm=T)*mm2ms
  dra.subbasin.yz.st.ir[i]<-  sum(area.orc*dra.t.ir*subbasin.yz.st[,,i],
                                na.rm=T)*mm2ms
}

#pseudo discharge
#pdis.subbasin.yz.st <-  run.subbasin.yz.st + dra.subbasin.yz.st

#difference between simulated and observed discharge
dif.dis.yz.st.ni <-  mag.dis.yz.ni - mag.dis.yz.hh
dif.dis.yz.st.ir <-  mag.dis.yz.ir - mag.dis.yz.hh

#calculate the accumulate difference
acu.dis.dif.yz.ni <-  array(0,dim=length(mag.dis.yz.ni))
acu.dis.dif.yz.ir <-  array(0,dim=length(mag.dis.yz.ir))
acu.dis.dif.yz.ni[1]  <-  mag.dis.yz.ni[1] - mag.dis.yz.hh[1]
acu.dis.dif.yz.ir[1]  <-  mag.dis.yz.ir[1] - mag.dis.yz.hh[1]

for (i in 2:length(mag.dis.yz.ni))
{
  acu.dis.dif.yz.ni[i]<-  mag.dis.yz.ni[i] -
    mag.dis.yz.hh[i] - sum(acu.dis.dif.yz.ni[1:(i-1)])
  acu.dis.dif.yz.ir[i]<-  mag.dis.yz.ir[i] -
    mag.dis.yz.hh[i] - sum(acu.dis.dif.yz.ir[1:(i-1)])
}

#calculate the accumualte difference annually
acu.dis.dif.a.yz.ni <-  array(0,dim=c(length(mag.dis.yz.ni),
                                      dim(dis.yz.a.hh)[2]))
acu.dis.dif.a.yz.ir <-  array(0,dim=c(length(mag.dis.yz.ir),
                                      dim(dis.yz.a.hh)[2]))
acu.dis.dif.a.yz.ni[1,]  <-  dis.yz.a.ni[idx.st[1],] -
                             dis.yz.a.hh[idx.st[1],]
acu.dis.dif.a.yz.ir[1,]  <-  dis.yz.a.ir[idx.st[1],] -
                             dis.yz.a.hh[idx.st[1],]

for (i in 2:length(mag.dis.yz.ni))
{
  if (i == 2)
  {
    acu.dis.dif.a.yz.ni[i,] <-  dis.yz.a.ni[idx.st[i],] -
                                dis.yz.a.hh[idx.st[i],] -
                                acu.dis.dif.a.yz.ni[1,]
    acu.dis.dif.a.yz.ir[i,] <-  dis.yz.a.ir[idx.st[i],] -
                                dis.yz.a.hh[idx.st[i],] -
                                acu.dis.dif.a.yz.ir[1,]
  } else
  {
    acu.dis.dif.a.yz.ni[i,] <-  dis.yz.a.ni[idx.st[i],] -
                                dis.yz.a.hh[idx.st[i],] -
                                apply(acu.dis.dif.a.yz.ni[1:(i-1),],
                                      2,sum,na.rm=T)
    acu.dis.dif.a.yz.ir[i,] <-  dis.yz.a.ir[idx.st[i],] -
                                dis.yz.a.hh[idx.st[i],] -
                                apply(acu.dis.dif.a.yz.ir[1:(i-1),],
                                      2,sum,na.rm=T)
  }
}

#calculate the discharge from each subbasin
dis.subbasin.a.yz.hh <-  array(0,dim=c(length(mag.dis.yz.hh),
                                  dim(dis.yz.a.hh)[2]))
dis.subbasin.a.yz.ni <-  array(0,dim=c(length(mag.dis.yz.ni),
                                  dim(dis.yz.a.hh)[2]))
dis.subbasin.a.yz.ir <-  array(0,dim=c(length(mag.dis.yz.ir),
                                  dim(dis.yz.a.hh)[2]))

dis.subbasin.a.yz.hh[1,] <-  dis.yz.a.hh[idx.st[1],]
dis.subbasin.a.yz.ni[1,] <-  dis.yz.a.ni[idx.st[1],]
dis.subbasin.a.yz.ir[1,] <-  dis.yz.a.ir[idx.st[1],]

for (i in 2:length(mag.dis.yz.ni))
{
  dis.subbasin.a.yz.hh[i,] <-  dis.yz.a.hh[idx.st[i],] - dis.yz.a.hh[idx.st[i-1],]
  dis.subbasin.a.yz.ni[i,] <-  dis.yz.a.ni[idx.st[i],] - dis.yz.a.ni[idx.st[i-1],]
  dis.subbasin.a.yz.ir[i,] <-  dis.yz.a.ir[idx.st[i],] - dis.yz.a.ir[idx.st[i-1],]
}

#calculate the discharge from each subbasin
dis.subbasin.m.yz.hh <-  array(0,dim=c(length(mag.dis.yz.hh),
                                  dim(dis.yz.m.hh)[2]))
dis.subbasin.m.yz.ni <-  array(0,dim=c(length(mag.dis.yz.ni),
                                  dim(dis.yz.m.hh)[2]))
dis.subbasin.m.yz.ir <-  array(0,dim=c(length(mag.dis.yz.ir),
                                  dim(dis.yz.m.hh)[2]))

dis.subbasin.m.yz.hh[1,] <-  dis.yz.m.hh[idx.st[1],]
dis.subbasin.m.yz.ni[1,] <-  dis.yz.m.ni[idx.st[1],]
dis.subbasin.m.yz.ir[1,] <-  dis.yz.m.ir[idx.st[1],]

for (i in 2:length(mag.dis.yz.ni))
{
  dis.subbasin.m.yz.hh[i,] <-  dis.yz.m.hh[idx.st[i],] - dis.yz.m.hh[idx.st[i-1],]
  dis.subbasin.m.yz.ni[i,] <-  dis.yz.m.ni[idx.st[i],] - dis.yz.m.ni[idx.st[i-1],]
  dis.subbasin.m.yz.ir[i,] <-  dis.yz.m.ir[idx.st[i],] - dis.yz.m.ir[idx.st[i-1],]
}


#calculate the discharge from each subbasin
dis.subbasin.spr.yz.hh <-  array(0,dim=c(length(mag.dis.yz.hh),
                                 dim(dis.yz.a.hh)[2]))
dis.subbasin.spr.yz.ni <-  array(0,dim=c(length(mag.dis.yz.ni),
                                 dim(dis.yz.a.hh)[2]))
dis.subbasin.spr.yz.ir <-  array(0,dim=c(length(mag.dis.yz.ir),
                                  dim(dis.yz.a.hh)[2]))

dis.subbasin.spr.yz.hh[1,] <-  dis.yz.a.hh[idx.st[1],]
dis.subbasin.spr.yz.ni[1,] <-  dis.yz.a.ni[idx.st[1],]
dis.subbasin.spr.yz.ir[1,] <-  dis.yz.a.ir[idx.st[1],]

for (i in 2:length(mag.dis.yz.ni))
{
  dis.subbasin.a.yz.hh[i,] <-  dis.yz.a.hh[idx.st[i],] - dis.yz.a.hh[idx.st[i-1],]
  dis.subbasin.a.yz.ni[i,] <-  dis.yz.a.ni[idx.st[i],] - dis.yz.a.ni[idx.st[i-1],]
  dis.subbasin.a.yz.ir[i,] <-  dis.yz.a.ir[idx.st[i],] - dis.yz.a.ir[idx.st[i-1],]
}
