#here we try to estimate the dam regulation

library(hydroGOF)
source('lib/lib_dis.R')

UpDateMag <-  function(dis,cap.max,t=1,num.yr){
  #dis: monthly average discharge [m3/s]
  #cap.max: maximum capacity of dams [1e8m3]
  #num.yr: number of years [-]
  #Here we read historical simulated discharge
  #data and maximum capacity to assess the ability
  #of reservoir to regulate discharge
  #we have 10 year memory and the recent give higher
  #weight to affect the operation

  #output:
  #sea: multi-year averaged seasonal discharge [m3/s]
  #dcap: proposed change of water store in reservoir [10^8m3]
  #exp: expected water storage at the end of this month [10^8m3]
  #rel/rec: start of release/recharge month
  #urg: if this month is at beginning or end of
  #release/recharge season; value will be like 6,5,4,3,2,1
  #when use, need calculate 1/urg

  #t [> 0.1 < 1.5] : decide whether flood reduction is more important or increase baseflow

  #unit convert
  d2c <-  3600*24*30.42*1e-8

  #w.yr  <-  c(1,1,1,1,1,2,3,4,5,6)
  #if (num.yr < 10)
  #{
  #  w.yr  <-  w.yr[(10-num.yr+1):10]/
  #            sum(w.yr[(10-num.yr+1):10])
  #} else
  #  w.yr  <-  w.yr/sum(w.yr)

  #calculate the seasonal mean
  c.dis <-  SeasonalAverage1D(dis,num.y=num.yr)

  tt.tmp  <-  c.dis - t*mean(c.dis)

  sum.tmp <-  abs(sum(tt.tmp[tt.tmp < 0]))

  k.tmp <-  min(cap.max/(sum.tmp*d2c),.8)

  dcap.tmp  <-  tt.tmp*k.tmp*d2c

  exp.tmp   <-  array(NA,dim=12)

  #find the maximum length of positive chain
  len.max <-  0
  len.tmp <- 0
  for (mon in 1:12)
  {
    if (dcap.tmp[mon] < 0) #releasing
    {
      len.tmp <- 0
    } else #recharging
    {
      len.tmp <- len.tmp + 1

      if (len.tmp >= len.max)
      {
        #xx.tmp record the start of release
        #yy.tmp record the start of recharge
        xx.tmp  <-  mon+1
        yy.tmp  <-  mon-len.tmp+1
        len.max <-  len.tmp
      }
    }
  }

  idx.tmp <-  c(seq(xx.tmp,12),seq(1,xx.tmp-1))

  #if this month is urgent
  urg.tmp <-  rep(0,12)
  urg.tmp[yy.tmp:(xx.tmp-1)]  <-  seq(len.max,1)
  urg.tmp[idx.tmp[1:(12-len.max)]]  <-  seq((12-len.max),1)

  exp.tmp <-  array(1,dim=12)
  exp.tmp[idx.tmp[1]] <-  sum.tmp*k.tmp*d2c #+ dcap.tmp[idx.tmp[1]]
  for (mon in 2:12)
  {
    exp.tmp[idx.tmp[mon]] <-  exp.tmp[idx.tmp[mon-1]] + 
                              dcap.tmp[idx.tmp[mon-1]]
  }

  #remove some tiny negative values
  exp.tmp[exp.tmp < 0]  <-  0

  out <-  list(sea=c.dis,dcap=dcap.tmp,
               exp=exp.tmp,rel=xx.tmp,
               #urg=urg.tmp,rec=yy.tmp)
               urg=rep(1,length(urg.tmp)),rec=yy.tmp)

  return(out)
}

DamMag <-  function(dis,cap.max,etp,
                    pre,a,area,ifrac,num.yr){
  #dis: discharge [m3/s]
  #cap.max: maximum capacity of dams [1e8m3]
  #peak: maximum peak [m3/s]
  #base: base flow [m3/s]
  #etp: potential ET [mm]
  #pre: precipitation [mm]
  #a: irrigation demand ratio [-]
  #area: area of the subregion [-]
  #ifrac: fraction of irrigated crops [-]
  #num.yr: number of years [-]

  #unit convert
  d2c <-  3600*24*30.42*1e-8
  c2d <-  1e8/(3600*24*30.42)

  #ratio to calculate rel rate: mon 4: 1/3; mon 5: 1/2; mon 6: 1
  #rat.rel <-  c(1/3,1/2,1)
  rat.rel <-  c(1/6,2/5,1)

  cap.o   <-  array(0,dim=length(dis)+1)
  dcap.o  <-  array(0,dim=length(dis))
  gap.o   <-  array(0,dim=length(dis))


  #initial cap.lyx is half cap.max
  cap.o[1] <-  cap.max/2
  t.tmp <-  1 #trace the time series


  for (yr in 1:num.yr)  #1982---2014
  {
    #experienced discharge
    if (yr <= 10)
    {
      exp <-  UpDateMag(dis[1:(12*yr)],cap.max,
                        ,num.yr=yr)
    } else
      exp <-  UpDateMag(dis[(12*(yr-10)+1):(12*yr)],
                        cap.max,num.yr=10)

    for (mon in 1:12)
    {

      #exp$dcap: a^: expected storage change
      #exp$exp: b^: expected storage
      #cap.o: b~: current storage
      #dcap.tmp: a: current expected storage change
      #exp$urg: imp factor

      #release season
      if (exp$dcap[mon] < 0)
      {
        #calculate current expected release amount
        #a
        dcap.tmp  <-  max((exp$sea[mon] - 
                           exp$dcap[mon]*c2d -
                           dis[t.tmp])*d2c,0)
      
        # storage is not enough
        if (cap.o[t.tmp] <= exp$exp[mon])
        {
          dcap.o[t.tmp] <- -cap.o[t.tmp]*(-exp$dcap[mon])^(1/exp$urg[mon])/
                           exp$exp[mon]
        } else #storage is more than enough b~>b^
        {
          #a < a^
          if (dcap.tmp < -exp$dcap[mon]) #
          {
            dcap.o[t.tmp] <- -dcap.tmp - ((cap.o[t.tmp] - dcap.tmp) -
                                        (exp$exp[mon] + exp$dcap[mon]))^
                                        (1/exp$urg[mon])

          } else #a >= a^
          {
            dcap.o[t.tmp] <- exp$dcap[mon] - (cap.o[t.tmp] - exp$exp[mon])^
                             (1/exp$urg[mon])
          }
        }

      } else #recharge season
      {
        dcap.tmp  <-  (dis[t.tmp] - 
                           exp$sea[mon] +
                           exp$dcap[mon]*c2d)*d2c
        if (cap.o[t.tmp] > exp$exp[mon])
        {
          dcap.o[t.tmp] <-  max(min(exp$dcap[mon]+exp$exp[mon]-
                                cap.o[t.tmp],d2c*dis[t.tmp]*(1-1e-3)),0)
        } else #current storage is smaller than expected
        {
          dcap.o[t.tmp] <-  min(exp$dcap[mon] +
                          (exp$exp[mon] - cap.o[t.tmp])^
                          (1/exp$urg[mon]),d2c*dis[t.tmp]*(1-1e-3))
        }
      }

      cap.o[t.tmp+1]  <-  cap.o[t.tmp] + dcap.o[t.tmp]
      t.tmp <-  t.tmp + 1

    }
  }

  out <-  list('cap'=cap.o,'dcap'=dcap.o)
  return(out)
}

if (!exists('cap.m.lyx'))
{
  source('read/dis/read_dis_dam.R')
  source('read/dis/read_dis_tab.R')
  source('read/subregion/read_subregion_var_tab.R')
  
  #select needed station data
  dis.m.hh <-  dis.yl.m.hh[idx.yl,]
  dis.m.ir <-  dis.yl.m.ir[idx.yl,]
  dis.m.ni <-  dis.yl.m.ni[idx.yl,]
}

#number of year
num.yr  <-  33

#unit convert
d2c <-  3600*24*30.42*1e-8
c2d <-  1e8/(3600*24*30.42)

#maximum regulation capacity
cap.max <-  c(0,235,.6,91.5,0)*.5

cap.lyx <-  array(0,dim=dim(dis.m.hh)[2]+1)
dcap.lyx <-  array(0,dim=dim(dis.m.hh)[2])

#calculate the case for LYX and LJX based on IR simulation
st  <-  2
cap.lyx1 <-  DamMag(dis.m.ir[st,],41.5,
                    etp.sr2.m.yl.ir[st+1,],pre.sr2.m.yl[st+1,],a,
                    area.sr2.yl[st+1],ifrac.sr2.yl[st+1],num.yr)

cap.lyx2 <-  DamMag(dis.m.ir[st,],cap.max[st],
                    etp.sr2.m.yl.ir[st+1,],pre.sr2.m.yl[st+1,],a,
                    area.sr2.yl[st+1],ifrac.sr2.yl[st+1],num.yr)

st  <-  3
cap.lyx3 <-  DamMag(dis.m.ir[st,],sum(cap.max[1:st]),
                    etp.sr2.m.yl.ir[st+1,],
                    pre.sr2.m.yl[st+1,],a,area.sr2.yl[st+1],
                    ifrac.sr2.yl[st+1],num.yr)

st  <-  4
cap.lyx4 <-  DamMag(dis.m.ir[st,],sum(cap.max[1:st]),
                    etp.sr2.m.yl.ir[st+1,],
                    pre.sr2.m.yl[st+1,],a,area.sr2.yl[st+1],
                    ifrac.sr2.yl[st+1],num.yr)
