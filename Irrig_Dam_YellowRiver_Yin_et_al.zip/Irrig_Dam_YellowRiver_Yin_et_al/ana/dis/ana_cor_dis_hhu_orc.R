#This will calculate the correlation coefficients RMSE
#between ORCHIDEE and HHU discharge product

source('ana/dam/ana_dam.R')

if (!exists('dis.yl.m.ni'))
{
  #source('read/dis/read_dis4hhu_m_orc.R')
  source('read/dis/read_dis_tab.R')
  source('read/dis/read_dis_dam.R')
}

library('hydroGOF')

#read the function to calculate the RMSE decompostion
source('lib/lib_dis.R')
source('../../lib_vyin/rlib_vyin.R')

#-------function-------
#calculate the correlation, p, rmse, sb, sdsd, lcs, nse and write the result
#in a table
CorHHUDis   <-  function(val.hh,val.orc,rv,irr)
{
#val.hh: input of hhu
#val.orc: input of orc
#rv: river name
#irr: irrigation scheme
  r2.o  <-  array(NA,dim=dim(val.hh)[1])
  kge.o <-  array(NA,dim=dim(val.hh)[1])
  cor.o <-  array(NA,dim=dim(val.hh)[1])
  beta.o<-  array(NA,dim=dim(val.hh)[1])
  alp.o <-  array(NA,dim=dim(val.hh)[1])
  rmse.o<-  array(NA,dim=dim(val.hh)[1])
  sb.o  <-  array(NA,dim=dim(val.hh)[1])
  sdsd.o<-  array(NA,dim=dim(val.hh)[1])
  lcs.o <-  array(NA,dim=dim(val.hh)[1])
  nse.o <-  array(NA,dim=dim(val.hh)[1])
  d.o   <-  array(NA,dim=dim(val.hh)[1])
  dif.o <-  array(NA,dim=dim(val.hh)[1])

  for (st in 1:dim(val.hh)[1])
  {
      hh.tmp  <-  val.hh[st,]
      orc.tmp <-  val.orc[st,]
      if (length(hh.tmp[!is.na(hh.tmp)]) < 50 | length(orc.tmp[!is.na(orc.tmp)]) < 50)
          next

      r2.o[st]    <-  br2(sim=orc.tmp,obs=hh.tmp)
      kge.tmp     <-  KGE(sim=orc.tmp,obs=hh.tmp,
                          method='2012',out.type='full')
      kge.o[st]   <-  kge.tmp$KGE.value
      cor.o[st]   <-  kge.tmp$KGE.elements[1]
      beta.o[st]  <-  kge.tmp$KGE.elements[2]
      alp.o[st]   <-  kge.tmp$KGE.elements[3]

      rmse.o[st]  <-  rmse(hh.tmp,orc.tmp,na.rm=T)
      sb.o[st]    <-  SB(hh.tmp,orc.tmp)
      sdsd.o[st]  <-  SDSD(hh.tmp,orc.tmp)
      lcs.o[st]   <-  LCS(hh.tmp,orc.tmp)
      nse.o[st]   <-  NSE(sim=orc.tmp,obs=hh.tmp)
      d.o[st]     <-  d(orc.tmp,hh.tmp)
      dif.o[st]   <-  mean(hh.tmp,na.rm=T) - mean(orc.tmp,na.rm=T)
  }

  write.table(r2.o,paste('tab/r2.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(kge.o,paste('tab/kge.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(cor.o,paste('tab/cor.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(beta.o,paste('tab/beta.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(alp.o,paste('tab/alp.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(rmse.o,paste('tab/rmse.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(sb.o,paste('tab/sb.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(sdsd.o,paste('tab/sdsd.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(lcs.o,paste('tab/lcs.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(nse.o,paste('tab/nse.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(d.o,paste('tab/d.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
  write.table(dif.o,paste('tab/dif.',rv,'.m.hh.',irr,sep=''),row.names=F,col.names=F,sep='\t')
}

#-------function-------

CorHHUDis(dis.yl.a.hh,dis.yl.a.ni,'yl','ni.a')
CorHHUDis(dis.yl.a.hh,dis.yl.a.ir,'yl','ir.a')

CorHHUDis(dis.yl.m.hh,dis.yl.m.ni,'yl','ni')
CorHHUDis(dis.yl.m.hh,dis.yl.m.ir,'yl','ir')

#second try: reproduce natural flow
dis.yl.m.ir2  <-  dis.yl.m.ir

#1: LanZhou
i <-  2
idx.tmp <-  idx.yl[i]
dcap.2.tmp  <-  cap.lyx1$dcap
dcap.2.tmp[73:396]  <-  cap.lyx2$dcap[73:396]
dis.yl.m.ir2[idx.tmp,]  <-  dis.yl.m.ir[idx.tmp,] -
                            cap.lyx2$dcap*c2d

#2: TouDaoGuai
i <-  3
idx.tmp <-  idx.yl[i]
dcap.3.tmp  <-  dcap.2.tmp
dis.tmp     <-  dis.yl.m.ir[idx.tmp,] -
                cap.lyx2$dcap*c2d

dcap.cor  <-  dis.tmp*d2c
dcap.cor[dis.tmp >= 0]  <-  0
dis.tmp[dis.tmp < 0]  <-  0
dis.yl.m.ir2[idx.tmp,]  <-  dis.tmp

#3: HuaYuanKou
i <-  4
idx.tmp <-  idx.yl[i]
dcap.4.tmp  <-  dcap.2.tmp
dcap.4.tmp[217:396]  <-  cap.lyx4$dcap[217:396]
dis.yl.m.ir2[idx.tmp,]  <-  dis.yl.m.ir[idx.tmp,] -
                            cap.lyx4$dcap*c2d - dcap.cor*c2d

#4: LiJin
i <-  5
idx.tmp <-  idx.yl[i]
dis.tmp     <-  dis.yl.m.ir[idx.tmp,] -
                cap.lyx4$dcap*c2d - dcap.cor*c2d
dis.tmp[dis.tmp < 0]  <-  0
dis.yl.m.ir2[idx.tmp,]  <-  dis.tmp

CorHHUDis(dis.yl.m.hh,dis.yl.m.ni,'yl','ni2')
CorHHUDis(dis.yl.m.hh,dis.yl.m.ir2,'yl','ir2')

source('read/dis/read_dis_tab.R')
