#here we prepare the monthly and annual variable at subregion scale
source("lib/lib_routing.R")
source('read/subregion/read_subregion_tab.R')

len.m <-  396
len.a <-  33

#for each sub-region
#see pre/subbasin/pre_subregion.R
#sr: subregion, subregion downstream includes the subregion upstream
#sr2: subregion, subregion downstream independent the subregion upstream

if (!exists('pre.m.orc'))
{
  source('read/pre/read_pre_m_orc.R')
  source('read/irr/read_irr_m_orc.R')
  source('read/et/read_et_m_orc.R')
  source('read/et/read_et_m_gleam.R')
  source('read/et/read_et_m_mpi.R')
  source('read/et/read_et_m_ut.R')
  source('read/et/read_et_m_pku.R')
  source('read/tws/read_tws_m_orc.R')
  source('read/tws/read_tws_m_gr.R')
  source('read/run/read_run_m_orc.R')
  source('read/dra/read_dra_m_orc.R')
  source('read/sm/read_sm_m_orc.R')
}

pre.sr.m.yl <-  ExtractSub(pre.m.orc,subregion.yl.st)
pre.sr.m.yz <-  ExtractSub(pre.m.orc,subregion.yz.st)

pre.sr.a.yl <-  ExtractSub(pre.a.orc,subregion.yl.st)
pre.sr.a.yz <-  ExtractSub(pre.a.orc,subregion.yz.st)

write.table(pre.sr.m.yl,'tab/pre.sr.m.yl',row.names=F,col.names=F,sep='\t')
write.table(pre.sr.m.yz,'tab/pre.sr.m.yz',row.names=F,col.names=F,sep='\t')

write.table(pre.sr.a.yl,'tab/pre.sr.a.yl',row.names=F,col.names=F,sep='\t')
write.table(pre.sr.a.yz,'tab/pre.sr.a.yz',row.names=F,col.names=F,sep='\t')

pre.sr2.m.yl <-  ExtractSub2(pre.m.orc,subregion.yl.st)
pre.sr2.m.yz <-  ExtractSub2(pre.m.orc,subregion.yz.st)

pre.sr2.a.yl <-  ExtractSub2(pre.a.orc,subregion.yl.st)
pre.sr2.a.yz <-  ExtractSub2(pre.a.orc,subregion.yz.st)

write.table(pre.sr2.m.yl,'tab/pre.sr2.m.yl',row.names=F,col.names=F,sep='\t')
write.table(pre.sr2.m.yz,'tab/pre.sr2.m.yz',row.names=F,col.names=F,sep='\t')

write.table(pre.sr2.a.yl,'tab/pre.sr2.a.yl',row.names=F,col.names=F,sep='\t')
write.table(pre.sr2.a.yz,'tab/pre.sr2.a.yz',row.names=F,col.names=F,sep='\t')

var <-  'irr'
irr <-  c('ir','fi')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
{
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- ExtractSub',sch[k],'(',var[i],'.',freq[m],'.',irr[j],
                    ',subregion.',riv[l],'.st)')))
  eval(parse(text=
             paste0('write.table(',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ',\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    '\',row.names=F,col.names=F,sep=\'\t\')')))
}

var <-  c('run','dra')
irr <-  c('ni','ir')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
{
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- ExtractSub',sch[k],'(',var[i],'.',freq[m],'.',irr[j],
                    ',subregion.',riv[l],'.st)')))
  eval(parse(text=
             paste0('write.table(',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ',\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    '\',row.names=F,col.names=F,sep=\'\t\')')))
}

var <-  c('sm')
irr <-  c('ni','ir')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
{
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- ExtractSub',sch[k],'(',var[i],'.',freq[m],'.',irr[j],
                    ',subregion.',riv[l],'.st)')))
  eval(parse(text=
             paste0('write.table(',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ',\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    '\',row.names=F,col.names=F,sep=\'\t\')')))
}

var <-  'et'
irr <-  c('ni','ir','gl','ut','mp','pk')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
{
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- ExtractSub',sch[k],'(',var[i],'.',freq[m],'.',irr[j],
                    ',subregion.',riv[l],'.st)')))
  eval(parse(text=
             paste0('write.table(',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ',\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    '\',row.names=F,col.names=F,sep=\'\t\')')))
}

var <-  'etp'
irr <-  c('ni','ir','fi','gl')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
{
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- ExtractSub',sch[k],'(',var[i],'.',freq[m],'.',irr[j],
                    ',subregion.',riv[l],'.st)')))
  eval(parse(text=
             paste0('write.table(',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ',\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    '\',row.names=F,col.names=F,sep=\'\t\')')))
}

var <-  'tws'
irr <-  c('ni','ir','csr','jpl','gsf')
sch <-  c('','2')
riv <-  c('yl','yz')
freq <-  c('a','m')

for (i in 1:length(var))
for (j in 1:length(irr))
for (k in 1:length(sch))
for (l in 1:length(riv))
for (m in 1:length(freq))
{
  eval(parse(text=
             paste0(var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ' <- ExtractSub',sch[k],'(',var[i],'.',freq[m],'.',irr[j],
                    ',subregion.',riv[l],'.st)')))
  eval(parse(text=
             paste0('write.table(',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    ',\'tab/',var[i],'.sr',sch[k],'.',freq[m],'.',riv[l],'.',irr[j],
                    '\',row.names=F,col.names=F,sep=\'\t\')')))
}
