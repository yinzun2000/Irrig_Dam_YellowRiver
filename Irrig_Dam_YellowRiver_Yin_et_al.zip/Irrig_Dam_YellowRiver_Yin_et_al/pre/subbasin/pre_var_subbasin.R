#here we prepare the monthly and annual variable at subbasin scale
idx.st  <-  c(7,8,5,11,4)

if (!exists("pre.m.ni"))
{
  source("read/area/read_area_tab.R")
  source("read/pre/read_pre_m_orc.R")
  source("read/ta/read_ta_m_orc.R")
  source("read/et/read_et_m_orc.R")
}

source("lib/lib_routing.R")
#read location of each station
lon.yz.orc  <-  as.matrix(read.table('tab/longitude.yz.orc'))
lat.yz.orc  <-  as.matrix(read.table('tab/latitude.yz.orc'))

lon.yz.orc  <-  lon.yz.orc[,1]
lat.yz.orc  <-  lat.yz.orc[,1]

if (!exists('dif.subbasin.yz.st'))
{
  subbasin.yz.st  <-  array(0,dim=c(length(lon.r),length(lat.r),length(idx.st)))  #lon*lat*num.station

  for (i in 1:length(idx.st))
    subbasin.yz.st[,,i] <- FindBasin(lon.yz.orc[idx.st[i]],lat.yz.orc[idx.st[i]],fd,lons,lats,lon.r,lat.r)

  #for Pingshan, We should add another point for basin
  sub.tmp <- FindBasin(103.75,28.25,fd,lons,lats,lon.r,lat.r)
  subbasin.yz.st[,,1] <-  BasinCombine(subbasin.yz.st[,,1],sub.tmp)

  rm('sub.tmp')

  dif.subbasin.yz.st  <-  subbasin.yz.st
  for (i in 2:length(idx.st))
    dif.subbasin.yz.st[,,i] <-  subbasin.yz.st[,,i] - subbasin.yz.st[,,i-1]
}

pre.subbasin.yz.m.orc  <-  array(0,dim=c(length(idx.st),dim(pre.m.orc)[3]))
pre.subbasin.yz.a.orc  <-  array(0,dim=c(length(idx.st),dim(pre.a.orc)[3]))

ta.subbasin.yz.m.orc   <-  array(0,dim=c(length(idx.st),dim(pre.m.orc)[3]))
ta.subbasin.yz.a.orc   <-  array(0,dim=c(length(idx.st),dim(pre.a.orc)[3]))
#only calculate averaged tair in spring
presp.subbasin.yz.a.orc<-  array(0,dim=c(length(idx.st),dim(pre.a.orc)[3]))
tasp.subbasin.yz.a.orc <-  array(0,dim=c(length(idx.st),dim(pre.a.orc)[3]))

et.subbasin.yz.m.ni  <-  array(0,dim=c(length(idx.st),dim(pre.m.orc)[3]))
et.subbasin.yz.a.ni  <-  array(0,dim=c(length(idx.st),dim(pre.a.orc)[3]))

et.subbasin.yz.m.ir  <-  array(0,dim=c(length(idx.st),dim(pre.m.orc)[3]))
et.subbasin.yz.a.ir  <-  array(0,dim=c(length(idx.st),dim(pre.a.orc)[3]))

#unit issue from mm*m^2 to km^3
mm2km2  <-  1e-12

for (i in 1:length(idx.st))
for (j in 1:dim(pre.m.orc)[3])
{
  pre.subbasin.yz.m.orc[i,j] <-  sum(area.orc*pre.m.orc[,,j]*dif.subbasin.yz.st[,,i],
                                     na.rm=T)*mm2km2
  ta.subbasin.yz.m.orc[i,j]  <-  sum(area.orc*ta.m.orc[,,j]*dif.subbasin.yz.st[,,i],
                                     na.rm=T)/sum(area.orc*dif.subbasin.yz.st[,,i],
                                     na.rm=T)
  et.subbasin.yz.m.ni[i,j]   <-  sum(area.orc*et.m.ni[,,j]*dif.subbasin.yz.st[,,i],
                                     na.rm=T)*mm2km2
  et.subbasin.yz.m.ir[i,j]   <-  sum(area.orc*et.m.ir[,,j]*dif.subbasin.yz.st[,,i],
                                     na.rm=T)*mm2km2
}

for (i in 1:length(idx.st))
for (j in 1:dim(pre.a.orc)[3])
{
  pre.subbasin.yz.a.orc[i,j] <-  sum(area.orc*pre.a.orc[,,j]*dif.subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
  ta.subbasin.yz.a.orc[i,j] <-   sum(area.orc*ta.a.orc[,,j]*dif.subbasin.yz.st[,,i],
                                    na.rm=T)/sum(area.orc*dif.subbasin.yz.st[,,i],
                                    na.rm=T)
  v.tmp <-  apply(ta.m.orc[,,(12*(j-1)+4):(12*(j-1)+7)],c(1,2),mean,na.rm=T)
  tasp.subbasin.yz.a.orc[i,j]<-  sum(area.orc*v.tmp*dif.subbasin.yz.st[,,i],
                                    na.rm=T)/sum(area.orc*dif.subbasin.yz.st[,,i],
                                    na.rm=T)
  v.tmp <-  apply(pre.m.orc[,,(12*(j-1)+4):(12*(j-1)+7)],c(1,2),mean,na.rm=T)
  presp.subbasin.yz.a.orc[i,j]<-  sum(area.orc*v.tmp*dif.subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
  et.subbasin.yz.a.ni[i,j]    <-  sum(area.orc*et.a.ni[,,j]*dif.subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
  et.subbasin.yz.a.ir[i,j]    <-  sum(area.orc*et.a.ir[,,j]*dif.subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
}


#seasonal
pre.subbasin.yz.c.orc <-  array(0,dim=c(length(idx.st),12))
ta.subbasin.yz.c.orc  <-  array(0,dim=c(length(idx.st),12))

for (i in 1:length(idx.st))
for (j in 1:dim(pre.a.orc)[3])
for (k in 1:12)
{
  pre.subbasin.yz.c.orc[i,k]  <-  pre.subbasin.yz.c.orc[i,k] + 
                                  sum(area.orc*pre.m.orc[,,12*(j-1)+k]*dif.subbasin.yz.st[,,i],
                                  na.rm=T)*mm2km2
  ta.subbasin.yz.c.orc[i,k]   <-  ta.subbasin.yz.c.orc[i,k] + 
                                  sum(area.orc*ta.m.orc[,,12*(j-1)+k]*dif.subbasin.yz.st[,,i],
                                  na.rm=T)/sum(area.orc*dif.subbasin.yz.st[,,i],na.rm=T)
}

pre.subbasin.yz.c.orc <-  pre.subbasin.yz.c.orc/length(pre.a.orc)
ta.subbasin.yz.c.orc  <-  ta.subbasin.yz.c.orc/length(ta.a.orc)

write.table(pre.subbasin.yz.m.orc,'tab/pre.subbasin.yz.m.orc',col.name=F,row.name=F,sep='\t')
write.table(pre.subbasin.yz.a.orc,'tab/pre.subbasin.yz.a.orc',col.name=F,row.name=F,sep='\t')
write.table(pre.subbasin.yz.c.orc,'tab/pre.subbasin.yz.c.orc',col.name=F,row.name=F,sep='\t')

write.table(ta.subbasin.yz.m.orc,'tab/ta.subbasin.yz.m.orc',col.name=F,row.name=F,sep='\t')
write.table(ta.subbasin.yz.a.orc,'tab/ta.subbasin.yz.a.orc',col.name=F,row.name=F,sep='\t')
write.table(ta.subbasin.yz.c.orc,'tab/ta.subbasin.yz.c.orc',col.name=F,row.name=F,sep='\t')
write.table(tasp.subbasin.yz.a.orc,'tab/tasp.subbasin.yz.a.orc',col.name=F,row.name=F,sep='\t')

write.table(et.subbasin.yz.m.ni,'tab/et.subbasin.yz.m.ni',col.name=F,row.name=F,sep='\t')
write.table(et.subbasin.yz.a.ni,'tab/et.subbasin.yz.a.ni',col.name=F,row.name=F,sep='\t')

write.table(et.subbasin.yz.m.ir,'tab/et.subbasin.yz.m.ir',col.name=F,row.name=F,sep='\t')
write.table(et.subbasin.yz.a.ir,'tab/et.subbasin.yz.a.ir',col.name=F,row.name=F,sep='\t')
