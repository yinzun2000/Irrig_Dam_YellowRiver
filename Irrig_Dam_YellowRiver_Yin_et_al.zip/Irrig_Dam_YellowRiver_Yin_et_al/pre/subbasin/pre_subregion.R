#follow Philippe's idea:
# chose several sites on the Yangtze river and compare the bias of discharge
# check if the bias at upper station is the main reason of the bias at the down station
# also check the evaporation of the difference of the two basin

#7 stations are chosen
#1: Pingshan 7;
#2: Zhutuo 8;
#3: Yichang 5;
#4: Hankou 11;
#5: Datong 4;

#Cuntan 6; delete, hard to find it

#for Yellow river we chose
#1: Tangnaihai 23;
#2: LanZhou 17;
#3: Toudaoguai 21;
#4: Huayuankou 11;
#5: Lijin 13;

source("lib/lib_routing.R")

if (!exists("dis.yz.m.hh"))
{
  source("read/area/read_area_tab.R")
  source("read/subbasin/read_subbasin_tab.R")
  #interpolation the hhu discharge at pingshan station
}

#YZ river------
idx.st  <-  c(7,8,5,11,4)

#read location of each station
lon.yz.orc  <-  as.matrix(read.table('tab/longitude.yz.orc'))
lat.yz.orc  <-  as.matrix(read.table('tab/latitude.yz.orc'))

lon.yz.orc  <-  lon.yz.orc[,1]
lat.yz.orc  <-  lat.yz.orc[,1]

subregion.yz.st  <-  array(0,dim=c(length(lon.r),length(lat.r),length(idx.st)))  #lon*lat*num.station

for (i in 1:length(idx.st))
  subregion.yz.st[,,i] <- FindBasin(lon.yz.orc[idx.st[i]],lat.yz.orc[idx.st[i]],fd,lons,lats,lon.r,lat.r)

#for Pingshan, We should add another point for basin
sub.tmp <- FindBasin(103.75,28.25,fd,lons,lats,lon.r,lat.r)
subregion.yz.st[,,1] <-  BasinCombine(subregion.yz.st[,,1],sub.tmp)

#YL river------
idx.st  <-  c(23,17,21,11,13)

#read location of each station
lon.yl.orc  <-  as.matrix(read.table('tab/longitude.yl.orc'))
lat.yl.orc  <-  as.matrix(read.table('tab/latitude.yl.orc'))

lon.yl.orc  <-  lon.yl.orc[,1]
lat.yl.orc  <-  lat.yl.orc[,1]

subregion.yl.st  <-  array(0,dim=c(length(lon.r),length(lat.r),length(idx.st)))  #lon*lat*num.station

for (i in 1:length(idx.st))
  subregion.yl.st[,,i] <- FindBasin(lon.yl.orc[idx.st[i]],lat.yl.orc[idx.st[i]],fd,lons,lats,lon.r,lat.r)

#for Tangnaihai, We should add another point for basin
subregion.yl.st[,,1]  <-  FindBasin(100.75,35.75,fd,lons,lats,lon.r,lat.r)

write.table(subregion.yz.st,'tab/subregion.yz.st',row.names=F,col.names=F,sep='\t')
write.table(subregion.yl.st,'tab/subregion.yl.st',row.names=F,col.names=F,sep='\t')
