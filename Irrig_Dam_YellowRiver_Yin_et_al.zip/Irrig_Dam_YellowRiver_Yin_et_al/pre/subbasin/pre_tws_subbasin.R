#here we prepare the monthly and annual tws at subbasin scale

if (!exists("tws.m.ni"))
{
  source("read/area/read_area_tab.R")
  source("read/tws/read_tws_m_gr.R")
  #source("read/tws/read_tws_m_gr_new.R")
  source("read/tws/read_tws_m_orc_ni.R")
}

idx.st  <-  c(7,8,5,11,4)

#read location of each station
lon.yz.orc  <-  as.matrix(read.table('tab/longitude.yz.orc'))
lat.yz.orc  <-  as.matrix(read.table('tab/latitude.yz.orc'))

lon.yz.orc  <-  lon.yz.orc[,1]
lat.yz.orc  <-  lat.yz.orc[,1]

source("lib/lib_routing.R")

if (!exists('subbasin.yz.st'))
{
  subbasin.yz.st  <-  array(0,dim=c(length(lon.r),length(lat.r),length(idx.st)))  #lon*lat*num.station

  for (i in 1:length(idx.st))
    subbasin.yz.st[,,i] <- FindBasin(lon.yz.orc[idx.st[i]],lat.yz.orc[idx.st[i]],fd,lons,lats,lon.r,lat.r)

  #for Pingshan, We should add another point for basin
  sub.tmp <- FindBasin(103.75,28.25,fd,lons,lats,lon.r,lat.r)
  subbasin.yz.st[,,1] <-  BasinCombine(subbasin.yz.st[,,1],sub.tmp)

  rm('sub.tmp')
}

tws.subbasin.yz.m.ni  <-  array(0,dim=c(length(idx.st),dim(tws.m.ni)[3]))
tws.subbasin.yz.a.ni  <-  array(0,dim=c(length(idx.st),dim(tws.a.ni)[3]))

tws.subbasin.yz.m.csr <-  array(0,dim=c(length(idx.st),dim(tws.m.csr)[3]))
tws.subbasin.yz.a.csr <-  array(0,dim=c(length(idx.st),dim(tws.a.csr)[3]))

tws.subbasin.yz.m.jpl <-  array(0,dim=c(length(idx.st),dim(tws.m.jpl)[3]))
tws.subbasin.yz.a.jpl <-  array(0,dim=c(length(idx.st),dim(tws.a.jpl)[3]))

#unit issue from mm*m^2 to km^3
mm2km2  <-  1e-12

for (i in 1:length(idx.st))
for (j in 1:dim(tws.m.ni)[3])
  tws.subbasin.yz.m.ni[i,j] <-  sum(area.orc*tws.m.ni[,,j]*subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2

for (i in 1:length(idx.st))
for (j in 1:dim(tws.a.ni)[3])
  tws.subbasin.yz.a.ni[i,j] <-  sum(area.orc*tws.a.ni[,,j]*subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2

for (i in 1:length(idx.st))
for (j in 1:dim(tws.m.csr)[3])
{
  tws.subbasin.yz.m.csr[i,j]<-  sum(area.orc*tws.m.csr[,,j]*subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
  tws.subbasin.yz.m.jpl[i,j]<-  sum(area.orc*tws.m.jpl[,,j]*subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
}

for (i in 1:length(idx.st))
for (j in 1:dim(tws.a.csr)[3])
{
  tws.subbasin.yz.a.csr[i,j]<-  sum(area.orc*tws.a.csr[,,j]*subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
  tws.subbasin.yz.a.jpl[i,j]<-  sum(area.orc*tws.a.jpl[,,j]*subbasin.yz.st[,,i],
                                    na.rm=T)*mm2km2
}

write.table(tws.subbasin.yz.m.ni,'tab/tws.subbasin.yz.m.oc',col.name=F,row.name=F,sep='\t')
write.table(tws.subbasin.yz.a.ni,'tab/tws.subbasin.yz.a.oc',col.name=F,row.name=F,sep='\t')

write.table(tws.subbasin.yz.m.csr,'tab/tws.subbasin.yz.m.csr',col.name=F,row.name=F,sep='\t')
write.table(tws.subbasin.yz.a.csr,'tab/tws.subbasin.yz.a.csr',col.name=F,row.name=F,sep='\t')

write.table(tws.subbasin.yz.m.jpl,'tab/tws.subbasin.yz.m.jpl',col.name=F,row.name=F,sep='\t')
write.table(tws.subbasin.yz.a.jpl,'tab/tws.subbasin.yz.a.jpl',col.name=F,row.name=F,sep='\t')

