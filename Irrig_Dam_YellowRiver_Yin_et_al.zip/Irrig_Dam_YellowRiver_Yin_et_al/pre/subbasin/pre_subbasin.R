#here we will prepare the subbasin map of Yangtze River and Yellow River
library("RNetCDF")
source("lib/lib_routing.R")

info.yz <-  read.table('tab/info.subbasin.yz',header=1)

for (sb in 1:length(info.yz$LAT))
{
  if(info.yz$LON2[sb] !=0)
  {
    b1.tmp  <-  FindBasin(info.yz$LON[sb],info.yz$LAT[sb],fd,lons,lats,lon.r,lat.r)
    b2.tmp  <-  FindBasin(info.yz$LON2[sb],info.yz$LAT2[sb],fd,lons,lats,lon.r,lat.r)
    basin   <-  BasinCombine(b1.tmp,b2.tmp)
  } else
    basin <-  FindBasin(info.yz$LON[sb],info.yz$LAT[sb],fd,lons,lats,lon.r,lat.r)

  write.table(basin,paste0("tab/subbasin.yz.",info.yz$NAME[sb]),
                           row.names=F,col.names=F,sep="\t")
}
