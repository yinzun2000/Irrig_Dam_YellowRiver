#this script will create a CN mask
#the function is from rlib_vyin

library('RNetCDF')
source('../../lib_vyin/rlib_vyin.R')

path    =   '/home/surface4/vyin/data/NewCrop/'

filei   =   paste(path,'MTr3952NC_GS_noirri_NewPFT_05deg_CN_8207Y_M.nc',sep='')
nc.tmp  =   open.nc(filei)
#other related variable
lons    =   var.get.nc(nc.tmp,'lon')
lats    =   var.get.nc(nc.tmp,'lat')
close.nc(nc.tmp)

fileo   <-  'tab/05deg_CN.msk'

CreateChinaRegion(lons=lons,lats=lats,fileo=fileo)
