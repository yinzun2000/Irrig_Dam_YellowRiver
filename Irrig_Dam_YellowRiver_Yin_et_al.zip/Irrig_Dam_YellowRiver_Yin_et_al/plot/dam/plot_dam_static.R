#Here we try to plot some information for dams
library('RColorBrewer')
source('lib/lib_dis.R')
source('lib/lib_plot.R')
library('Kendall')

if (!exists('nse.yl.m.hh.ni'))
{
  source('read/dis/read_dis_tab.R')
  source('read/subregion/read_subregion_tab.R')
  source('read/subregion/read_subregion_var_tab.R')
  source('read/area/read_area_tab.R')

  area.sr.yz  <-  array(NA,dim=dim(subregion.yz.st)[3])
  area.sr.yl  <-  array(NA,dim=dim(subregion.yl.st)[3])
  for (i in 1:dim(subregion.yz.st)[3])
  {
    area.sr.yz[i] <-  sum(area.orc[subregion.yz.st[,,i] > .5],na.rm=T)
    area.sr.yl[i] <-  sum(area.orc[subregion.yl.st[,,i] > .5],na.rm=T)
  }

  area.sr2.yz  <-  area.sr.yz
  area.sr2.yl  <-  area.sr.yl
  for (i in 2:dim(subregion.yz.st)[3])
  {
    area.sr2.yz[i] <-  area.sr.yz[i]-area.sr.yz[i-1]
    area.sr2.yl[i] <-  area.sr.yl[i]-area.sr.yl[i-1]
  }
}

len.yl.a    <-  length(time.a.yl)
len.yz.a    <-  length(time.a.yz)

lab.m   <-  c('J','F','M','A','M','J','J','A','S','O','N','D')


pdf('fig/lag_dis_stations.pdf',width=8,height=9)
  par(mfrow=c(5,1),oma=c(4,5,.5,.5)+.1,mar=c(2.5,0,.5,0),cex.axis=1.5,
      cex.lab=1.8)
  #layout(matrix(seq(1,10),5,2,byrow=F),
  #       widths=c(8,2),heights=rep(2,5))
  idx <-  c(23,17,21,11,13)
  st.lab  <-  c(expression('(a) S'[1]*'~S'[2]),
                expression('(b) S'[2]*'~S'[3]),
                expression('(c) S'[3]*'~S'[4]),
                expression('(d) S'[4]*'~S'[5]),
                expression('(e) S'[1]*'~S'[5]))

  for (i in 2:5)
  {
    tt  <-  ccf(dis.yl.m.hh[idx[i],],dis.yl.m.hh[idx[i-1],])
    text(-21,max(tt$acf)*.93,labels=st.lab[i-1],cex=1.5)
  }

  tt  <-  ccf(dis.yl.m.hh[idx[5],],dis.yl.m.hh[idx[1],])
  text(-21,max(tt$acf)*.93,labels=st.lab[5],cex=1.5)
  mtext(side=2,cex=1.2,line=3.5,outer=T,
        text="Cross-correlation between two gauging stations")
  mtext(side=1,cex=1.2,line=3.5,
        text="Time lag (mon)")

dev.off()
