#histgram plot of compare indicators: cor
library('RColorBrewer')
source('lib/lib_dis.R')
source('lib/lib_plot.R')
source('lib/barplot_sg.R')
library('Kendall')

AnaCol  <-  function(col.i,alpha){
  c.tmp <-  col2rgb(col.i)/255
  r.tmp <-  c.tmp[1]
  g.tmp <-  c.tmp[2]
  b.tmp <-  c.tmp[3]
  col.o <-  rgb(r.tmp,g.tmp,b.tmp,alpha)

  return(col.o)
}

if (!exists('nse.yl.m.hh.ni'))
{
  source('ana/dis/ana_cor_dis_hhu_orc.R')
  source('read/dis/read_dis_tab.R')
  source('read/subregion/read_subregion_tab.R')
  source('read/subregion/read_subregion_var_tab.R')
  source('read/area/read_area_tab.R')

  area.sr.yz  <-  array(NA,dim=dim(subregion.yz.st)[3])
  area.sr.yl  <-  array(NA,dim=dim(subregion.yl.st)[3])
  for (i in 1:dim(subregion.yz.st)[3])
  {
    area.sr.yz[i] <-  sum(area.orc[subregion.yz.st[,,i] > .5],na.rm=T)
    area.sr.yl[i] <-  sum(area.orc[subregion.yl.st[,,i] > .5],na.rm=T)
  }

  area.sr2.yz  <-  area.sr.yz
  area.sr2.yl  <-  area.sr.yl
  for (i in 2:dim(subregion.yz.st)[3])
  {
    area.sr2.yz[i] <-  area.sr.yz[i]-area.sr.yz[i-1]
    area.sr2.yl[i] <-  area.sr.yl[i]-area.sr.yl[i-1]
  }
}

len.yl.a    <-  length(time.a.yl)
len.yz.a    <-  length(time.a.yz)

lab.m   <-  c('J','F','M','A','M','J','J','A','S','O','N','D')
col.r   <-  c(AnaCol(col.ind(12)[4],1),
              AnaCol(col.ind(12)[4],2/3),
              AnaCol(col.ind(12)[4],1/3))
col.g   <-  c(AnaCol(col.ind(12)[7],1),
              AnaCol(col.ind(12)[7],2/3),
              AnaCol(col.ind(12)[7],1/3))
col.b   <-  c(AnaCol(col.ind(12)[5],1),
              AnaCol(col.ind(12)[5],2/3),
              AnaCol(col.ind(12)[5],1/3))
col.o   <-  c(AnaCol(col.ind(12)[10],1),
              AnaCol(col.ind(12)[10],2/3),
              AnaCol(col.ind(12)[10],1/3))

col.sr  <-  col.ind(12)[c(4,7,5)]

x.at    <-  c(5,9.5,14,18.5,23)
x.lab   <-  c(expression(R[1]),
              expression(R[2]),
              expression(R[3]),
              expression(R[4]),
              expression(R[5]))

pdf('fig/dis_comp_dam_ind.pdf',width=12,height=4)
  par(oma=c(1,3,2,1)+.1,mar=c(2,2,0,0)+1.5,cex.axis=2,
      cex.lab=1.8,mfrow=c(1,3))#,mfrow=c(2,3))

  idx   <-  c(23,17,21,11,13)
  x.at  <-  c(5,9.5,14,18.5,23)
  #indicators: RMSE=SB+SDSD+LCS; COR; D; NSE
  #bar plot
  #station*[sb,sdsd,lcs]*[sb,sdsd,lcs]*[ni~hh,ni~hhc,ir~hh,ir~hhc]
  bar.tmp <-  array(NA,dim=c(5,3,3))
  cont  <-  c('ni','ir','ir2')
  indc  <-  c('sb','sdsd','lcs')

  for (i in 1:length(cont))
  for (k in 1:length(indc))
  for (l in 1:length(idx))
  {
    eval(parse(text=paste0('bar.tmp[l,k,i] <- ',
                           indc[k],'.yl.m.hh.',
                           cont[i],'[',idx[l],']')))
  }

  bar.tmp <-  bar.tmp/1e6

  barplot.sg(t(bar.tmp[,,1]),space.before=0,space=3.5,
             col=col.r,xlim=c(3.5,24.5),ylim=c(0,7))
  barplot.sg(t(bar.tmp[,,2]),space.before=1,space=2.5,
             col=col.g,add=T,axes=F)
  barplot.sg(t(bar.tmp[,,3]),space.before=2,space=1.5,
             col=col.b,add=T,axes=F)
  #barplot.sg(t(bar.tmp[,,4]),space.before=3,space=0.5,
  #           col=col.o,add=T,axes=F)
  axis(1,at=x.at,labels=x.lab,tick=F)
  text(3,6.8,'(a)',cex=2,pos=4)
  mtext(2,text=expression('MSE (10'^6*'m'^6*'.s'^{-2}*')'),
        cex=1.5,line=3)
  legend('top',fill=col.sr,legend=c(expression(italic(Q)[NI] %~% italic(Q)[obs]),
                                    expression(italic(Q)[IR] %~% italic(Q)[obs]),
                                    expression(hat(italic(Q))[IR] %~% italic(Q)[obs])),
         bty='n',cex=1.5)

  polygon(c(5.5,5.5,6.5,6.5),c(3,3+2/3,3+2/3,3),col=col.r[1])
  polygon(c(5.5,5.5,6.5,6.5),c(3+2/3,3+4/3,3+4/3,3+2/3),col=col.r[2])
  polygon(c(5.5,5.5,6.5,6.5),c(3+4/3,5,5,3+4/3),col=col.r[3])

  segments(5,3,5,5)
  segments(5,3,5.2,3)
  segments(5,5,5.2,5)
  segments(5,4,4.8,4)
  text(4.2,4,'MSE',srt=90,cex=1.2)

  segments(7,3,7,5)
  segments(7,3,6.8,3)
  segments(7,3+2/3,6.8,3+2/3)
  segments(7,3+4/3,6.8,3+4/3)
  segments(7,5,6.8,5)
  segments(7,4,7.2,4)
  segments(7,3+1/3,7.2,3+1/3)
  segments(7,3+5/3,7.2,3+5/3)
  text(7,3+1/3,'SB',pos=4,cex=1.2)
  text(7,4,'SDSD',pos=4,cex=1.2)
  text(7,3+5/3,'LCS',pos=4,cex=1.2)

  #D
  #5 subregion*[ni~hh, ir~hh, ir~hh2]
  bar.tmp <-  array(NA,dim=c(5,3))
  bar.tmp[,1] <-  d.yl.m.hh.ni[idx]
  bar.tmp[,2] <-  d.yl.m.hh.ir[idx]
  bar.tmp[,3] <-  d.yl.m.hh.ir2[idx]

  barplot(t(bar.tmp),beside=T,col=col.sr,
          ylim=c(0,1))
  x.at    <-  c(2.5,6.5,10.5,14.5,18.5)
  axis(1,at=x.at,labels=x.lab,tick=F)
  text(.5,.95,'(b)',cex=2,pos=4)
  mtext(2,text=expression('Index of Agreement (-)'),
        cex=1.5,line=3)

  #KGE
  #5 subregion*[ni~hh, ir~hh, ir~hh2]
  bar.tmp <-  array(NA,dim=c(5,3))
  bar.tmp[,1] <-  kge.yl.m.hh.ni[idx]
  bar.tmp[,2] <-  kge.yl.m.hh.ir[idx]
  bar.tmp[,3] <-  kge.yl.m.hh.ir2[idx]

  bar.tmp[bar.tmp < 0]  <-  bar.tmp[bar.tmp<0]/5
  barplot(t(bar.tmp),beside=T,ylim=c(-.6,.9),
          axes=F,col=col.sr)
  axis(2,at=c(-.6,-.4,-.2,0,.3,.6,.9),
       labels=c(-6,-4,-2,0,0.3,0.6,0.9))
  x.at    <-  c(2.5,6.5,10.5,14.5,18.5)
  axis(1,at=x.at,labels=x.lab,tick=F)
  text(.5,.83,'(c)',cex=2,pos=4)
  mtext(2,text=expression('Modified Kling-Gupta Efficiency (-)'),
        cex=1.5,line=3)

dev.off()
