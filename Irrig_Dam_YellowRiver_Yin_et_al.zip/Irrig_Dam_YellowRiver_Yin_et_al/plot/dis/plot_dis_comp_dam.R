#histgram plot of compare indicators: cor
library('RColorBrewer')
source('lib/lib_dis.R')
source('lib/lib_plot.R')
source('lib/barplot_sg.R')
library('Kendall')

if (!exists('nse.yl.m.hh.ni'))
{
  source('ana/dis/ana_cor_dis_hhu_orc.R')
  source('read/dis/read_dis_tab.R')
  source('read/subregion/read_subregion_tab.R')
  source('read/subregion/read_subregion_var_tab.R')
  source('read/area/read_area_tab.R')

  area.sr.yz  <-  array(NA,dim=dim(subregion.yz.st)[3])
  area.sr.yl  <-  array(NA,dim=dim(subregion.yl.st)[3])
  for (i in 1:dim(subregion.yz.st)[3])
  {
    area.sr.yz[i] <-  sum(area.orc[subregion.yz.st[,,i] > .5],na.rm=T)
    area.sr.yl[i] <-  sum(area.orc[subregion.yl.st[,,i] > .5],na.rm=T)
  }

  area.sr2.yz  <-  area.sr.yz
  area.sr2.yl  <-  area.sr.yl
  for (i in 2:dim(subregion.yz.st)[3])
  {
    area.sr2.yz[i] <-  area.sr.yz[i]-area.sr.yz[i-1]
    area.sr2.yl[i] <-  area.sr.yl[i]-area.sr.yl[i-1]
  }
}

len.yl.a    <-  length(time.a.yl)
len.yz.a    <-  length(time.a.yz)

lab.m   <-  c('J','F','M','A','M','J','J','A','S','O','N','D')


pdf('fig/dw_season_comp.pdf',width=10,height=5)
  par(oma=c(3,2,.5,.5)+.1,mar=c(2,2.5,0,0),cex.axis=1.5,
      cex.lab=1.8,mfrow=c(1,2))

  sim.tmp <-  SeasonalAverage1D(cap.lyx2$dcap,33)
  obs.tmp <-  cap.m.lyx+cap87.m.ljx
  sd.tmp  <-  apply(matrix(cap.lyx2$dcap,12,len.a),1,sd,na.rm=T)
  y.ra  <-  range(obs.tmp,sim.tmp+sd.tmp,sim.tmp-sd.tmp,na.rm=T)
  plot(seq(1,12),obs.tmp,ylim=y.ra,
       pch=16,xlab='',ylab='')
  lines(seq(1,12),obs.tmp)
  wid.tmp <-  .1
  for (i in 1:12)
  {
    segments(i,sim.tmp[i]-sd.tmp[i],i,sim.tmp[i]+sd.tmp[i],col=2)
    segments(i-wid.tmp,sim.tmp[i]-sd.tmp[i],i+wid.tmp,
             sim.tmp[i]-sd.tmp[i],col=2)
    segments(i-wid.tmp,sim.tmp[i]+sd.tmp[i],i+wid.tmp,
             sim.tmp[i]+sd.tmp[i],col=2)
  }
  points(seq(1,12),sim.tmp,pch=16,col=2)
  lines(seq(1,12),sim.tmp,col=2)
  mtext(side=1,'Month',cex=1.5,line=3)
  mtext(side=2,expression(Delta*W*' (10'^8*'m'^3*')'),
        cex=1.5,line=2.5)

  legend('topleft',pch=16,lty=1,col=c(1,2),
         legend=c('LYX+LJX','Sim'),cex=1.5,
         bty='n')

  sim.tmp <-  SeasonalAverage1D(cap.lyx4$dcap-cap.lyx2$dcap,33)
  obs.tmp <-  cap.m.xld
  sd.tmp  <-  apply(matrix(cap.lyx4$dcap,12,len.a),1,sd,na.rm=T)
  y.ra  <-  range(obs.tmp,sim.tmp+sd.tmp,sim.tmp-sd.tmp,na.rm=T)
  plot(seq(1,12),obs.tmp,ylim=y.ra,
       pch=16,xlab='',ylab='')
  lines(seq(1,12),obs.tmp)
  for (i in 1:12)
  {
    segments(i,sim.tmp[i]-sd.tmp[i],i,sim.tmp[i]+sd.tmp[i],col=2)
    segments(i-wid.tmp,sim.tmp[i]-sd.tmp[i],i+wid.tmp,
             sim.tmp[i]-sd.tmp[i],col=2)
    segments(i-wid.tmp,sim.tmp[i]+sd.tmp[i],i+wid.tmp,
             sim.tmp[i]+sd.tmp[i],col=2)
  }
  points(seq(1,12),sim.tmp,pch=16,col=2)
  lines(seq(1,12),sim.tmp,col=2)
  mtext(side=1,'Month',cex=1.5,line=3)
  legend('topleft',pch=16,lty=1,col=c(1,2),
         legend=c('XLD','Sim'),cex=1.5,
         bty='n')

dev.off()

pdf('fig/concept.pdf',width=10,height=10)
  par(oma=c(3,3,.5,.5)+.1,mar=c(2,2.5,0,0),cex.axis=1.5,
      cex.lab=1.8)
  q.s <-  SeasonalAverage1D(dis.yl.m.ir[idx.yl[2],],33)
  plot(q.s,type='l',lwd=2,axes=F)
  axis(2)
  axis(1,at=seq(1,12),labels=seq(1,12))
  box()
  mtext(side=1,text='Month',cex=2,line=3.3)
  mtext(side=2,text=expression('Monthly discharge (m'^3*'.s'^{-1}*')'),
        cex=2,line=3.3)
  abline(h=mean(q.s),lty=2)
  q.r <-  .5*(q.s-mean(q.s))+mean(q.s)
  lines(q.r,lty=4,lwd=2)
  ext.y = mean(q.s)
  ext.x = 6+(mean(q.s)-q.s[6])/(q.s[7]-q.s[6])

  eyt.y = mean(q.s)
  eyt.x = 10+(q.s[10]-mean(q.s))/(q.s[10]-q.s[11])

  polygon(c(seq(1,6),ext.x,seq(6,1)),
          c(q.r[1:6],ext.y,rev(q.s[1:6])),
          col=rgb(1,0,0,.5),border=NA)

  polygon(c(eyt.x,11,12,12,11,eyt.x),
          c(eyt.y,q.r[11:12],rev(q.s[11:12]),eyt.y),
          col=rgb(1,0,0,.5),border=NA)

  polygon(c(ext.x,seq(7,10),eyt.x,eyt.x,seq(10,7),ext.x),
          c(ext.y,q.s[7:10],eyt.y,eyt.y,rev(q.r[7:10]),ext.y),
          col=rgb(0,0,1,.5),border=NA)

  legend('topleft',lty=c(1,4,2),
         lwd=c(2,2,1),cex=1.5,
         legend=c(expression(italic(Q)[s]),expression(italic(Q)[t]),
                  expression(bar(italic(Q))[s])),
         bty='n')

  legend(0.85,1850,cex=1.5,
         fill=c(rgb(1,0,0,.5),rgb(0,0,1,.5)),
         legend=c('Release','Recharge'),
         bty='n')

dev.off()

pdf('fig/dis_comp_dam.pdf',width=11,height=8)
  par(oma=c(6,7,.5,7)+.1,mar=c(0,0,0,0),cex.axis=1.5,
      cex.lab=1.8)
  layout(matrix(seq(1,8),4,2,byrow=F),
         widths=c(8,2),heights=rep(2,5))
  idx <-  c(23,17,21,11,13)
  st.lab  <-  c('(a) TangNaiHai','(a) LanZhou',
                '(b) TouDaoGuai','(c) HuaYuanKou',
                '(d) LiJin')

  for (i in 2:5)
  {
    y.ra  <-  range(dis.yl.m.hh[idx[i],],
                    dis.yl.m.ir2[idx[i],],
                    dis.yl.m.ir[idx[i],],
                    na.rm=T)
    y.ra[2] <-  1.3*y.ra[2]
    if (i == 5)
    {
      plot(time.m.yl,dis.yl.m.hh[idx[i],],
           type='l',ylim=y.ra,axes=F)
      box()
      axis(2)
      axis(1,at=time.a.yl,labels=seq(1982,2014))
      mtext(side=1,text='Year',cex=1.5,line=3.5)
      mtext(side=2,text=expression('Monthly '*italic(Q)*
                                   ' (m'^3*'.s'^{-1}*')'),
            cex=1.5,line=4,outer=T)
    } else
    {
      plot(time.m.yl,dis.yl.m.hh[idx[i],],
           type='l',ylim=y.ra,axes=F)
      box()
      axis(2)
    }

    lines(time.m.yl,dis.yl.m.ir2[idx[i],],col=2)
    lines(time.m.yl,dis.yl.m.ir[idx[i],],col=3)
    text(as.Date('1981-01-01'),y.ra[2]*.95,labels=st.lab[i],
         pos=4,cex=2)

    if (i == 2)
      legend('topright',lty=1,col=c(1,3,2),
             legend=c(expression(italic(Q)[obs]),
                      expression(italic(Q)[IR]),
                      expression(hat(italic(Q))[IR])),
             cex=1.5,bty='n')
  }

  st.lab  <-  c('(e)','(f)','(g)','(h)')
  for (i in 2:5)
  {
    hh.tmp  <-  SeasonalAverage1D(dis.yl.m.hh[idx[i],],33)
    ir2.tmp  <-  SeasonalAverage1D(dis.yl.m.ir2[idx[i],],33)
    ir.tmp  <-  SeasonalAverage1D(dis.yl.m.ir[idx[i],],33)

    y.ra=range(hh.tmp,ir.tmp,ir2.tmp,
               na.rm=T)
    plot(seq(1,12),hh.tmp,pch=16,
         axes=F,xlab='',ylab='',ylim=y.ra)
    lines(seq(1,12),hh.tmp)

    points(seq(1,12),ir2.tmp,pch=16,col=2)
    lines(seq(1,12),ir2.tmp,col=2)

    points(seq(1,12),ir.tmp,pch=16,col=3)
    lines(seq(1,12),ir.tmp,col=3)
    box()

    text(.75,y.ra[2]*.95,labels=st.lab[i-1],
         pos=4,cex=2)

    if (i == 5)
    {
      axis(1,at=seq(1,12),labels=lab.m)
      mtext(side=1,text='Month',cex=1.5,
            line=3.5)
    }

    axis(4)
    mtext(text=expression(italic(Q)*
                          ' Seasonality (m'^3*'.s'^{-1}*')'),
          outer=T,side=4,cex=1.5,line=5)
  }
dev.off()
