#histgram plot of compare indicators: cor
library('RColorBrewer')
source('lib/lib_dis.R')
source('lib/lib_plot.R')
library('Kendall')

if (!exists('nse.yl.m.hh.ni'))
{
  source('read/dis/read_dis_tab.R')
  source('read/subregion/read_subregion_tab.R')
  source('read/subregion/read_subregion_var_tab.R')
  source('read/area/read_area_tab.R')

  area.sr.yz  <-  array(NA,dim=dim(subregion.yz.st)[3])
  area.sr.yl  <-  array(NA,dim=dim(subregion.yl.st)[3])
  for (i in 1:dim(subregion.yz.st)[3])
  {
    area.sr.yz[i] <-  sum(area.orc[subregion.yz.st[,,i] > .5],na.rm=T)
    area.sr.yl[i] <-  sum(area.orc[subregion.yl.st[,,i] > .5],na.rm=T)
  }

  area.sr2.yz  <-  area.sr.yz
  area.sr2.yl  <-  area.sr.yl
  for (i in 2:dim(subregion.yz.st)[3])
  {
    area.sr2.yz[i] <-  area.sr.yz[i]-area.sr.yz[i-1]
    area.sr2.yl[i] <-  area.sr.yl[i]-area.sr.yl[i-1]
  }
}

len.yl.a    <-  length(time.a.yl)
len.yz.a    <-  length(time.a.yz)

lab.m   <-  c('J','F','M','A','M','J','J','A','S','O','N','D')

pdf('fig/comp_dis_yl_monthly.pdf',width=10,height=9)
  par(mfrow=c(3,1),oma=c(.5,.5,.5,.5)+.1,mar=c(5,5,1,.5)+.1,cex.axis=1.5,cex.lab=1.8)

  #Tangnaihai
  i=23
  plot(time.m.yl,dis.yl.m.hh[i,],pch=16,#ylim=c(0,2e3),
       ylab=expression('Discharge (m'^3*'.s'^{-1}*')'),
       xlab='Year',type='l',axes=F,ylim=c(0,3e3))
  lines(time.m.yl,dis.yl.m.ni[i,],col=2)
  legend('topright',legend=c(expression(italic(Q)[obs]),expression(italic(Q)[NI])),
         lty=1,col=c(1,2),cex=1.8,bty='n')
  box()
  axis(1,at=time.a.yl[seq(4,35,5)],labels=seq(1985,2015,5))
  axis(2)
  text(as.Date('1981-01-01'),2.9e3,labels='(a) TangNaiHai',
       cex=1.7,pos=4)

  #LanZhou
  i=17
  plot(time.m.yl,dis.yl.m.hh[i,],pch=16,#ylim=c(0,2e3),
       ylab=expression('Discharge (m'^3*'.s'^{-1}*')'),
       xlab='Year',type='l',axes=F,ylim=c(250,4e3))
  lines(time.m.yl,dis.yl.m.ni[i,],col=2)
  abline(v=as.Date('1986-10-15'),col=rgb(0,1,0,.2),lwd=5)
  text(as.Date('1986-10-15'),3500,'LongYangXia',
       family='Times',cex=1.8)
  box()
  axis(1,at=time.a.yl[seq(4,35,5)],labels=seq(1985,2015,5))
  axis(2)
  text(as.Date('1981-01-01'),3.85e3,labels='(b) LanZhou',
       cex=1.7,pos=4)

  #Tongguan
  i=20
  plot(time.a.yl,dis.yl.a.hh[i,],pch=16,#ylim=c(0,2e3),
       ylab=expression('Observed discharge (m'^3*'.s'^{-1}*')'),
       xlab='Year',type='l',ylim=c(400,1800))
  text(as.Date('1981-01-01'),1.75e3,labels='(c)',
       cex=1.7,pos=4)
  #Xiaolangdi
  i=28
  lines(time.a.yl,dis.yl.a.hh[i,],lty=2)
  abline(v=as.Date('1999-06-30'),col=rgb(0,0,1,.2),lwd=5)
  text(as.Date('1999-06-30'),1600,'XiaoLangDi',
       family='Times',cex=1.8)
  legend('topright',legend=c('TongGuan','XiaoLangDi'),
         lty=c(1,2),cex=1.8,bty='n')
dev.off()

pdf('fig/dis_yl_cli_tr.pdf',width=10,height=4)
  par(mfrow=c(2,5),oma=c(4,5,1,.5)+.1,mar=c(0,0,0,0),cex.axis=1.2,cex.lab=1.5)

  #Tangnaihai
  i=23
  #calcualte the start and the end of trend
  dis.cli.s <-  array(NA,dim=12)
  dis.cli.e <-  array(NA,dim=12)
  p.dis.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  dis.yl.m.hh[i,seq(k,dim(dis.yl.m.hh)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.dis.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    dis.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    dis.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  y.ra  <-  c(0,3000)

  plot(seq(1,12),dis.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Discharge (m'^3*'.s'^{-1}*')'),
       col=2,axes=F)
  lines(seq(1,12),dis.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.dis.cli[k] < .05)
      segments(k,dis.cli.s[k],k,dis.cli.e[k],col=gray(.8),lwd=2)
  }
  box()
  axis(2)
  mtext(side=2,text=expression(italic(Q)*' (m'^3*'.s'^{-1}*')'),line=2.5)
  legend('topleft',bty='n',lty=1,lwd=c(1,1,2),col=c(2,3,gray(.8)),
         legend=c(expression(italic(Q)[s]),
                  expression(italic(Q)[e]),
                  expression(italic(p)<0.05)))

  #LanZhou
  i=17
  #calcualte the start and the end of trend
  dis.cli.s <-  array(NA,dim=12)
  dis.cli.e <-  array(NA,dim=12)
  p.dis.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  dis.yl.m.hh[i,seq(k,dim(dis.yl.m.hh)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.dis.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    dis.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    dis.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  plot(seq(1,12),dis.cli.s,pch=16,ylim=y.ra,type='l',
       col=2,axes=F)
  lines(seq(1,12),dis.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.dis.cli[k] < .05)
      segments(k,dis.cli.s[k],k,dis.cli.e[k],col=gray(.8),lwd=2)
  }
  box()

  #Toudaoguai
  i=21
  #calcualte the start and the end of trend
  dis.cli.s <-  array(NA,dim=12)
  dis.cli.e <-  array(NA,dim=12)
  p.dis.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  dis.yl.m.hh[i,seq(k,dim(dis.yl.m.hh)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.dis.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    dis.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    dis.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  #y.ra  <-  range(dis.cli.s,dis.cli.e)

  plot(seq(1,12),dis.cli.s,pch=16,ylim=y.ra,type='l',
       col=2,axes=F)
  lines(seq(1,12),dis.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.dis.cli[k] < .05)
      segments(k,dis.cli.s[k],k,dis.cli.e[k],col=gray(.8),lwd=2)
  }
  box()

  #HuaYuanKou
  i=11
  #calcualte the start and the end of trend
  dis.cli.s <-  array(NA,dim=12)
  dis.cli.e <-  array(NA,dim=12)
  p.dis.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  dis.yl.m.hh[i,seq(k,dim(dis.yl.m.hh)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.dis.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    dis.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    dis.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  #y.ra  <-  range(dis.cli.s,dis.cli.e)

  plot(seq(1,12),dis.cli.s,pch=16,ylim=y.ra,type='l',
       col=2,axes=F)
  lines(seq(1,12),dis.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.dis.cli[k] < .05)
      segments(k,dis.cli.s[k],k,dis.cli.e[k],col=gray(.8),lwd=2)
  }
  box()

  #Lijin
  i=13
  #calcualte the start and the end of trend
  dis.cli.s <-  array(NA,dim=12)
  dis.cli.e <-  array(NA,dim=12)
  p.dis.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  dis.yl.m.hh[i,seq(k,dim(dis.yl.m.hh)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.dis.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    dis.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    dis.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }
  box()

  plot(seq(1,12),dis.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Discharge (m'^3*'.s'^{-1}*')'),
       col=2,axes=F)
  lines(seq(1,12),dis.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.dis.cli[k] < .05)
      segments(k,dis.cli.s[k],k,dis.cli.e[k],col=gray(.8),lwd=2)
  }
  box()

  #Tangnaihai
  i=1
  #calcualte the start and the end of trend
  pre.cli.s <-  array(NA,dim=12)
  pre.cli.e <-  array(NA,dim=12)
  p.pre.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  pre.sr.m.yl[i,seq(k,dim(pre.sr.m.yl)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.pre.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    pre.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    pre.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  y.ra  <-  range(pre.cli.s,pre.cli.e)
  #y.ra  <-  c(0,3000)

  plot(seq(1,12),pre.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Precipitation (mm.mon'^{-1}*')'),
       col=2,axes=F,xlab='')
  lines(seq(1,12),pre.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.pre.cli[k] < .05)
      segments(k,pre.cli.s[k],k,pre.cli.e[k],col=gray(.8),lwd=2)
  }
  box()
  axis(1,at=seq(1,12),labels=lab.m,cex.axis=.9)
  axis(2)
  mtext(side=1,text=expression(R[1]),line=3)
  mtext(side=2,text=expression(italic(P)*' (mm.mon'^{-1}*')'),line=2.5)
  legend('topleft',bty='n',lty=1,lwd=c(1,1,2),col=c(2,3,gray(.8)),
         legend=c(expression(italic(P)[s]),
                  expression(italic(P)[e]),
                  expression(italic(p)<0.05)))

  #LanZhou
  i=2
  #calcualte the start and the end of trend
  pre.cli.s <-  array(NA,dim=12)
  pre.cli.e <-  array(NA,dim=12)
  p.pre.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  pre.sr.m.yl[i,seq(k,dim(pre.sr.m.yl)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.pre.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    pre.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    pre.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  y.ra  <-  range(pre.cli.s,pre.cli.e)

  plot(seq(1,12),pre.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Precipitation (mm.mon'^{-1}*')'), col=2,axes=F)
  lines(seq(1,12),pre.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.pre.cli[k] < .05)
      segments(k,pre.cli.s[k],k,pre.cli.e[k],col=gray(.8),lwd=2)
  }
  box()
  axis(1,at=seq(1,12),labels=lab.m,cex.axis=.9)
  mtext(side=1,text=expression(R[2]),line=3)

  #TouDaoGuai
  i=3
  #calcualte the start and the end of trend
  pre.cli.s <-  array(NA,dim=12)
  pre.cli.e <-  array(NA,dim=12)
  p.pre.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  pre.sr.m.yl[i,seq(k,dim(pre.sr.m.yl)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.pre.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    pre.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    pre.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  y.ra  <-  range(pre.cli.s,pre.cli.e)
  #y.ra  <-  c(0,3000)

  plot(seq(1,12),pre.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Precipitation (mm.mon'^{-1}*')'),
       col=2,axes=F)
  lines(seq(1,12),pre.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.pre.cli[k] < .05)
      segments(k,pre.cli.s[k],k,pre.cli.e[k],col=gray(.8),lwd=2)
  }
  box()
  axis(1,at=seq(1,12),labels=lab.m,cex.axis=.9)
  mtext(side=1,text=expression(R[3]),line=3)

  #HuaYuanKou
  i=4
  #calcualte the start and the end of trend
  pre.cli.s <-  array(NA,dim=12)
  pre.cli.e <-  array(NA,dim=12)
  p.pre.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  pre.sr.m.yl[i,seq(k,dim(pre.sr.m.yl)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.pre.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    pre.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    pre.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  y.ra  <-  range(pre.cli.s,pre.cli.e)
  #y.ra  <-  c(0,3000)

  plot(seq(1,12),pre.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Precipitation (mm.mon'^{-1}*')'),
       col=2,axes=F)
  lines(seq(1,12),pre.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.pre.cli[k] < .05)
      segments(k,pre.cli.s[k],k,pre.cli.e[k],col=gray(.8),lwd=2)
  }
  box()
  axis(1,at=seq(1,12),labels=lab.m,cex.axis=.9)
  mtext(side=1,text=expression(R[4]),line=3)

  #Lijin
  i=5
  #calcualte the start and the end of trend
  pre.cli.s <-  array(NA,dim=12)
  pre.cli.e <-  array(NA,dim=12)
  p.pre.cli <-  array(NA,dim=12)

  for (k in 1:12)
  {
    v.tmp <-  pre.sr.m.yl[i,seq(k,dim(pre.sr.m.yl)[2],12)]
    tr.tmp  <-  MannKendall(v.tmp)
    p.pre.cli[k]  <-  as.numeric(tr.tmp$sl)
    tt.tmp  <-  lm(v.tmp~seq(1,length(v.tmp)))
    co.tmp  <-  as.numeric(tt.tmp$coefficients)
    pre.cli.s[k]  <-  co.tmp[1]+co.tmp[2]
    pre.cli.e[k]  <-  co.tmp[1]+length(v.tmp)*co.tmp[2]
  }

  y.ra  <-  range(pre.cli.s,pre.cli.e)
  #y.ra  <-  c(0,3000)

  plot(seq(1,12),pre.cli.s,pch=16,ylim=y.ra,type='l',
       ylab=expression('Precipitation (mm.mon'^{-1}*')'),
       col=2,axes=F)
  lines(seq(1,12),pre.cli.e,col=3)
  for (k in 1:12)
  {
    if (p.pre.cli[k] < .05)
      segments(k,pre.cli.s[k],k,pre.cli.e[k],col=gray(.8),lwd=2)
  }
  box()
  axis(1,at=seq(1,12),labels=lab.m,cex.axis=.9)
  mtext(side=1,text=expression(R[5]),line=3)

dev.off()

pdf('fig/wb_subregion_yl_tr.pdf',width=10,height=6)
  par(mfrow=c(2,5),oma=c(1.5,4,2,0)+.1,mar=c(5,1,2,2)+.1,cex.axis=1.2,cex.lab=1.5)

  #density for barplot, distinguish obs and sim
  den.tmp <-  c(10,10,NA,NA,10,10,10,NA,NA,10)*2

  #convert unit from m/s to mm.yr
  u.cov <- 1e3*3600*24*365
  lab.tmp <-  c(expression(italic(P)[GSWP3]),
                expression(italic(P)[MSWEP]),
                expression(ET[NI]),
                expression(ET[IR]),
                expression(ET[GLEAM]),
                expression(ET[FLUXCOM]),
                expression(ET[PKU]),
                expression(italic(q)[NI]),
                expression(italic(q)[IR]),
                expression(italic(q)[obs]))
  st.lab  <-  c(expression(R[1]),
                expression(R[2]),
                expression(R[3]),
                expression(R[4]),
                expression(R[5]))
  #plot value of precipitation, et, TWS, of several subregions
  y.ra  <-  c(-200,600)
  idx   <-  c(23,17,21,11,13)

  #plot the mean value
  for (i in 1:5)
  {
    if (i == 1)
    {
      val.tmp <-  c(mean(pre.sr2.a.yl[i,]),
                    mean(pre2.sr2.a.yl[i,]),
                    mean(et.sr2.a.yl.ni[i,]),
                    mean(et.sr2.a.yl.ir[i,-30]),
                    mean(et.sr2.a.yl.gl[i,]),
                    mean(et.sr2.a.yl.mp[i,]),
                    mean(et.sr2.a.yl.pk[i,]),
                    mean(dis.yl.a.ni[idx[i],])*u.cov/area.sr2.yl[i],
                    mean(dis.yl.a.ir[idx[i],])*u.cov/area.sr2.yl[i],
                    mean(dis.yl.a.hh[idx[i],])*u.cov/area.sr2.yl[i])
                    #tws.sr2.a.yl.ir[i,26]-tws.sr2.a.yl.ir[i,1])
      sd.tmp  <-  c(sd(pre.sr2.a.yl[i,]),
                    sd(pre2.sr2.a.yl[i,]),
                    sd(et.sr2.a.yl.ni[i,]),
                    sd(et.sr2.a.yl.ni[i,]),
                    #sd(et.sr2.a.yl.ir[i,]),
                    sd(et.sr2.a.yl.gl[i,]),
                    sd(et.sr2.a.yl.mp[i,]),
                    sd(et.sr2.a.yl.pk[i,]),
                    sd(dis.yl.a.ni[idx[i],])*u.cov/area.sr2.yl[i],
                    sd(dis.yl.a.ir[idx[i],])*u.cov/area.sr2.yl[i],
                    sd(dis.yl.a.hh[idx[i],])*u.cov/area.sr2.yl[i])
    } else
    {
      val.tmp <-  c(mean(pre.sr2.a.yl[i,]),
                    mean(pre2.sr2.a.yl[i,]),
                    mean(et.sr2.a.yl.ni[i,]),
                    mean(et.sr2.a.yl.ir[i,-30]),
                    mean(et.sr2.a.yl.gl[i,]),
                    mean(et.sr2.a.yl.mp[i,]),
                    mean(et.sr2.a.yl.pk[i,]),
                    mean(dis.yl.a.ni[idx[i],]-dis.yl.a.ni[idx[i-1],])*u.cov/area.sr2.yl[i],
                    mean(dis.yl.a.ir[idx[i],]-dis.yl.a.ir[idx[i-1],])*u.cov/area.sr2.yl[i],
                    mean(dis.yl.a.hh[idx[i],]-dis.yl.a.hh[idx[i-1],])*u.cov/area.sr2.yl[i])
                    #tws.sr2.a.yl.ir[i,26]-tws.sr2.a.yl.ir[i,1])

      sd.tmp  <-  c(sd(pre.sr2.a.yl[i,]),
                    sd(pre2.sr2.a.yl[i,]),
                    sd(et.sr2.a.yl.ni[i,]),
                    sd(et.sr2.a.yl.ni[i,]),
                    #sd(et.sr2.a.yl.ir[i,]),
                    sd(et.sr2.a.yl.gl[i,]),
                    sd(et.sr2.a.yl.mp[i,]),
                    sd(et.sr2.a.yl.pk[i,]),
                    sd(dis.yl.a.ni[idx[i],]-dis.yl.a.ni[idx[i-1],])*u.cov/area.sr2.yl[i],
                    sd(dis.yl.a.ir[idx[i],]-dis.yl.a.ir[idx[i-1],])*u.cov/area.sr2.yl[i],
                    sd(dis.yl.a.hh[idx[i],]-dis.yl.a.hh[idx[i-1],])*u.cov/area.sr2.yl[i])
    }
    idx.tmp <-  c(1,1,2,2,2,2,2,3,3,3)
    col.tmp <-  c(rep(gray(0.5),2),rep(col.ind(10)[2],2),
                  rep(gray(.5),3),rep(col.ind(10)[3],2),
                  gray(0.5))
    barplot(val.tmp,space=0,col=col.ind(10)[idx.tmp],
            ylim=c(-300,800))
    barplot(val.tmp,space=0,add=T,col=col.tmp,
            ylim=c(-300,800),density=den.tmp)
    ErrBar(at=seq(.5,9.5),mean=val.tmp,sd=sd.tmp,
           wd=1,frac=.1)
    axis(1,at=seq(.5,9.5),labels=lab.tmp,las=2)

    mtext(3,text=st.lab[i],line=1)
    if (i == 1)
    {
      mtext(2,text=expression('Annual mean (mm.yr'^{-1}*')'),line=2.5)
      legend('top',fill=c('white',gray(.5)),density=c(NA,20),
             legend=c('Sim','Obs'),bty='n',cex=1.1)
      legend('topright',fill=col.ind(10)[seq(1,3)],
             legend=c(expression(italic(P)),'ET',
                      expression(italic(q))),
             bty='n',cex=1.1)
    }
  }

  #plot the trend
  lab.tmp <-  c(expression(italic(P)[GSWP3]),
                expression(italic(P)[MSWEP]),
                expression(ET[NI]),
                expression(ET[IR]),
                expression(ET[GLEAM]),
                expression(ET[FLUXCOM]),
                expression(ET[PKU]),
                expression(italic(q)[NI]),
                expression(italic(q)[IR]),
                expression(italic(q)[obs]))
  for (i in 1:5)
  {
    pre.tmp   <-  sens.slope(ts(pre.sr2.a.yl[i,]))$estimates
    pre2.tmp  <-  sens.slope(ts(pre2.sr2.a.yl[i,]))$estimates
    et.ni.tmp <-  sens.slope(ts(et.sr2.a.yl.ni[i,]))$estimates
    et.ir.tmp <-  sens.slope(ts(et.sr2.a.yl.ir[i,]))$estimates
    et.gl.tmp <-  sens.slope(ts(et.sr2.a.yl.gl[i,]))$estimates
    et.mp.tmp <-  sens.slope(ts(et.sr2.a.yl.mp[i,]))$estimates
    et.pk.tmp <-  sens.slope(ts(et.sr2.a.yl.pk[i,]))$estimates
    #tws.tmp   <-  sens.slope(ts(tws.sr2.a.yl.ir[i,]))$estimates

    pre.p.tmp   <-  as.numeric(MannKendall(pre.sr2.a.yl[i,])$tau)
    pre2.p.tmp  <-  as.numeric(MannKendall(pre2.sr2.a.yl[i,])$tau)
    et.ni.p.tmp <-  as.numeric(MannKendall(et.sr2.a.yl.ni[i,])$tau)
    et.ir.p.tmp <-  as.numeric(MannKendall(et.sr2.a.yl.ir[i,])$tau)
    et.gl.p.tmp <-  as.numeric(MannKendall(et.sr2.a.yl.gl[i,])$tau)
    et.mp.p.tmp <-  as.numeric(MannKendall(et.sr2.a.yl.mp[i,])$tau)
    et.pk.p.tmp <-  as.numeric(MannKendall(et.sr2.a.yl.pk[i,])$tau)
    #tws.p.tmp   <-  as.numeric(MannKendall(tws.sr2.a.yl.ir[i,])$tau)

    if (i == 1)
    {
      dis.ni.tmp<-  sens.slope(ts(dis.yl.a.ni[idx[i],]*u.cov/area.sr2.yl[i]))$estimates
      dis.ir.tmp<-  sens.slope(ts(dis.yl.a.ir[idx[i],]*u.cov/area.sr2.yl[i]))$estimates
      dis.hh.tmp<-  sens.slope(ts(dis.yl.a.hh[idx[i],]*u.cov/area.sr2.yl[i]))$estimates

      dis.ni.p.tmp<-  as.numeric(MannKendall(dis.yl.a.ni[idx[i],]*u.cov/area.sr2.yl[i])$tau)
      dis.ir.p.tmp<-  as.numeric(MannKendall(dis.yl.a.ir[idx[i],]*u.cov/area.sr2.yl[i])$tau)
      dis.hh.p.tmp<-  as.numeric(MannKendall(dis.yl.a.hh[idx[i],]*u.cov/area.sr2.yl[i])$tau)
    } else
    {
      dis.ni.tmp<-  sens.slope(ts((dis.yl.a.ni[idx[i],]-dis.yl.a.ni[idx[i-1],])*u.cov/area.sr2.yl[i]))$estimates
      dis.ir.tmp<-  sens.slope(ts((dis.yl.a.ir[idx[i],]-dis.yl.a.ir[idx[i-1],])*u.cov/area.sr2.yl[i]))$estimates
      dis.hh.tmp<-  sens.slope(ts((dis.yl.a.hh[idx[i],]-dis.yl.a.hh[idx[i-1],])*u.cov/area.sr2.yl[i]))$estimates

      dis.ni.p.tmp<-  as.numeric(MannKendall((dis.yl.a.ni[idx[i],]-dis.yl.a.ni[idx[i-1],])*u.cov/area.sr2.yl[i])$tau)
      dis.ir.p.tmp<-  as.numeric(MannKendall((dis.yl.a.ir[idx[i],]-dis.yl.a.ir[idx[i-1],])*u.cov/area.sr2.yl[i])$tau)
      dis.hh.p.tmp<-  as.numeric(MannKendall((dis.yl.a.hh[idx[i],]-dis.yl.a.hh[idx[i-1],])*u.cov/area.sr2.yl[i])$tau)
    }

    val.tmp <-  c(pre.tmp,
                  pre2.tmp,
                  et.ni.tmp,
                  et.ir.tmp,
                  et.gl.tmp,
                  et.mp.tmp,
                  et.pk.tmp,
                  dis.ni.tmp,
                  dis.ir.tmp,
                  dis.hh.tmp)
                  #tws.tmp)

    val.tmp <-  as.numeric(val.tmp)
    
    val.p.tmp <-  c(pre.p.tmp,
                    pre2.p.tmp,
                    et.ni.p.tmp,
                    et.ir.p.tmp,
                    et.gl.p.tmp,
                    et.mp.p.tmp,
                    et.pk.p.tmp,
                    dis.ni.p.tmp,
                    dis.ir.p.tmp,
                    dis.hh.p.tmp)
                    #tws.p.tmp)
    
    idx.tmp <-  c(1,1,2,2,2,2,2,3,3,3)
    barplot(val.tmp,space=0,col=col.ind(10)[idx.tmp],
            ylim=c(-1,3),xlab='',
            border=ifelse(val.p.tmp < .05,1,NA))
    barplot(val.tmp,space=0,col=col.tmp,add=T,
            ylim=c(-1,3),xlab='',density=den.tmp,
            border=ifelse(val.p.tmp < .05,1,NA))
    axis(1,at=seq(.5,9.5),labels=lab.tmp,las=2)

    if (i == 1)
    {
      mtext(2,text=expression('Trend (mm.yr'^{-2}*')'),line=2.5)
    }
  }
dev.off()

pdf('fig/dis_station_ts_yl_comp.pdf',width=11,height=10)
  par(oma=c(6,7,.5,7)+.1,mar=c(0,0,0,0),cex.axis=1.5,
      cex.lab=1.8)
  layout(matrix(seq(1,10),5,2,byrow=F),
         widths=c(8,2),heights=rep(2,5))
  idx <-  c(23,17,21,11,13)
  st.lab  <-  c('(a) TangNaiHai','(b) LanZhou',
                '(c) TouDaoGuai','(d) HuaYuanKou',
                '(e) LiJin')

  for (i in 1:5)
  {
    y.ra  <-  range(dis.yl.a.hh[idx[i],],
                    dis.yl.a.ni[idx[i],],
                    dis.yl.a.ir[idx[i],],
                    na.rm=T)
    y.ra[2] <-  1.3*y.ra[2]
    if (i == 5)
    {
      plot(time.a.yl,dis.yl.a.hh[idx[i],],
           pch=16,ylim=y.ra)
      mtext(side=1,text='Year',cex=1.5,line=3.5)
      mtext(side=2,text=expression('Annual '*italic(Q)*
                                   ' (m'^3*'.s'^{-1}*')'),
            cex=1.5,line=4,outer=T)
    } else
    {
      plot(time.a.yl,dis.yl.a.hh[idx[i],],
           pch=16,ylim=y.ra,axes=F)
      box()
      axis(2)
    }
    lines(time.a.yl,dis.yl.a.hh[idx[i],],type='l')

    points(time.a.yl,dis.yl.a.ni[idx[i],],pch=16,col=col.ind(12)[4])
    lines(time.a.yl,dis.yl.a.ni[idx[i],],col=col.ind(12)[4])

    points(time.a.yl,dis.yl.a.ir[idx[i],],pch=16,col=col.ind(12)[5])
    lines(time.a.yl,dis.yl.a.ir[idx[i],],col=col.ind(12)[5])
    text(as.Date('1981-01-01'),y.ra[2]*.95,labels=st.lab[i],
         pos=4,cex=2)

    if (i == 1)
      legend('topright',lty=1,pch=16,col=c(1,col.ind(12)[4],col.ind(12)[5]),
             legend=c(expression(italic(Q)[obs]),
                      expression(italic(Q)[NI]),
                      expression(italic(Q)[IR])),
             cex=2,bty='n')
  }

  dis.yl.c.hh <-  SeasonalAverage2D(dis.yl.m.hh,len.yl.a)
  dis.yl.c.ni <-  SeasonalAverage2D(dis.yl.m.ni,len.yl.a)
  dis.yl.c.ir <-  SeasonalAverage2D(dis.yl.m.ir,len.yl.a)

  st.lab  <-  c('(f)','(g)','(h)','(i)','(j)')

  for (i in 1:5)
  {
     y.ra=range(dis.yl.c.hh[idx[i],],
                dis.yl.c.ni[idx[i],],
                dis.yl.c.ir[idx[i],],
                na.rm=T)
    plot(seq(1,12),dis.yl.c.hh[idx[i],],pch=16,
         axes=F,xlab='',ylab='',ylim=range(dis.yl.c.hh[idx[i],],
                                           dis.yl.c.ni[idx[i],],
                                           dis.yl.c.ir[idx[i],],
                                           na.rm=T))
    lines(seq(1,12),dis.yl.c.hh[idx[i],])

    points(seq(1,12),dis.yl.c.ni[idx[i],],pch=16,col=col.ind(12)[4])
    lines(seq(1,12),dis.yl.c.ni[idx[i],],col=col.ind(12)[4])

    points(seq(1,12),dis.yl.c.ir[idx[i],],pch=16,col=col.ind(12)[5])
    lines(seq(1,12),dis.yl.c.ir[idx[i],],col=col.ind(12)[5])
    box()

    text(.75,y.ra[2]*.95,labels=st.lab[i],
         pos=4,cex=2)

    if (i == 5)
    {
      axis(1,at=seq(1,12),labels=lab.m)
      mtext(side=1,text='Month',cex=1.5,
            line=3.5)
    }

    axis(4)
    mtext(text=expression('Monthly '*italic(Q)*
                          ' (m'^3*'.s'^{-1}*')'),
          outer=T,side=4,cex=1.5,line=5)

  }
dev.off()
