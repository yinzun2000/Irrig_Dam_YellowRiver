library('fields')
library('mapdata')
library('RColorBrewer')
library('magick')

source('../../lib_vyin/rlib_vyin.R')
source('lib/lib_gis.R')
source('lib/lib_plot.R')

if (!exists('dis.yz.m.hh'))
    source('read/dis/read_dis_tab.R')

if (!exists('mfc.crop.t'))
{
  source('read/irr/read_irr_tab.R')
  mfc.crop.t  <-  mfc.crop.t/312
  source('read/mfc/read_mfc_tab.R')
  source('read/subregion/read_subregion_tab.R')

  yl.tmp  <-  apply(subregion.yl.st,c(1,2),sum,na.rm=T)
  yz.tmp  <-  apply(subregion.yz.st,c(1,2),sum,na.rm=T)
  yz.tmp  <-  yz.tmp+5
  yz.tmp[yz.tmp < 5.5]  <-  NA
  yl.tmp[is.na(yl.tmp)] <-  0
  yz.tmp[is.na(yz.tmp)] <-  0
  area.sr <-  yz.tmp+yl.tmp
  #load png figure
  #heigtht=386;width=625
  sub.rhow  <-  386/625
  sub.png <-  image_read('fig/subregion.png')
  net.png <-  image_read('fig/network.png')
}


#size of lab and title
sz.lb   <-  1.2
sz.mn   <-  1.7

#levels of colors
num.col <-  10

x.t     <-  87
y.t     <-  42.5

x.p <-  85
y.p <-  42.5

lons    <-  seq(89.25,123.75,.5)
lats    <-  seq(23.25,42.75,.5)

lons.yl    <-  seq(95.25,119.75,.5)
lats.yl    <-  seq(32.25,41.75,.5)

#create subregion of crop fraction
fc.crop <-  mfc.crop.t[39:108,15:54]
area.sr.tmp <-  area.sr[39:108,15:54]

fc.crop.yl <-  mfc.crop.t[51:100,33:52]
area.sr.tmp.yl <-  area.sr[51:100,33:52]

img.blk <-  array(NA,dim=c(length(lons),length(lats)))

#calculate the difference
dis.yz.t.hh <-  apply(dis.yz.a.hh,1,mean,na.rm=T)
dis.yz.t.ni <-  apply(dis.yz.a.ni,1,mean,na.rm=T)
dis.yz.t.ir <-  apply(dis.yz.a.ir,1,mean,na.rm=T)

time.a.yz.hh    <-  seq(as.Date('1982-01-01'),as.Date('2000-01-01'),by='years')
time.a.yl.hh    <-  seq(as.Date('1982-01-01'),as.Date('2007-01-01'),by='years')

time.m.yz.hh    <-  seq(as.Date('1982-01-15'),as.Date('2000-12-15'),by='months')
time.m.yl.hh    <-  seq(as.Date('1982-01-15'),as.Date('2007-12-15'),by='months')

pdf('fig/river_station_subregion_yellow.pdf',width=10,height=10)
  par(oma=c(1,1,0,0)+.1,mar=c(2,2,.5,.5)+.1,cex.axis=1.5,cex.lab=1.2,
      mfrow=c(2,1))
  image(lons.yl,lats.yl,area.sr.tmp.yl,col=col.ind(12)[1:5],xlab='',ylab='',main='',zlim=c(1,5))
  plot(cn.gis,add=T)#,border=gray(.3))
  plot(rbsin.gis[rbsin.gis$RCODE == RCODE.yl,],add=T,border='gray',bg=3)
  for (i in 1:4)
      plot(rnet.gis[rnet.gis$REGION == 'Yellow River' & rnet.gis$LEVEL_RIVE == i,],add=T,col=4,lwd=3-.5*i)
  #add the subregion figure
  rasterImage(sub.png,95.25,38.5,103,41.75)
  t.cex <-  1
  p.cex <-  1.2
  #plotstations
  i=17
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=2)
  shadowtext(lon.yl.hh[i],lat.yl.hh[i],labels='LanZhou',cex=t.cex,pos=4,col=1,bg='white')
  i=11
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=2)
  shadowtext(lon.yl.hh[i],lat.yl.hh[i],labels='HuaYuanKou',cex=t.cex,pos=4,col=1,bg='white')
  i=13
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=2)
  shadowtext(lon.yl.hh[i],lat.yl.hh[i],labels='LiJin',cex=t.cex,pos=4,col=1,bg='white')
  i=21
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=2)
  shadowtext(lon.yl.hh[i],lat.yl.hh[i],labels='TouDaoGuai',cex=t.cex,pos=4,col=1,bg='white')
  i=22
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=5)
  shadowtext(lon.yl.hh[i]-.5,lat.yl.hh[i],labels='TongGuan',cex=t.cex,pos=2,col=1,bg='white')
  i=23
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=2)
  shadowtext(lon.yl.hh[i],lat.yl.hh[i],labels='TangNaiHai',cex=t.cex,pos=2,col=1,bg='white')
  i=28
  points(lon.yl.hh[i],lat.yl.hh[i],col=1,cex=p.cex,pch=25,bg=5)

  #dams
  points(101,36.05,cex=2.5,lwd=2)
  shadowtext(101,36.2,labels='LongYangXia',cex=t.cex,pos=3,col=gray(.5),bg='white',family='Times')
  points(103.2,35.78,cex=2.5,lwd=2)
  shadowtext(103.25,35.74,labels='LiuJiaXia',cex=t.cex,pos=1,col=gray(.5),bg='white',family='Times')
  points(106,37.9,cex=2.5,lwd=2)
  shadowtext(107,37,labels='QingTongXia',cex=t.cex,pos=3,col=gray(.5),bg='white',family='Times')
  points(112.38,34.92,cex=2.5,lwd=2)
  shadowtext(lon.yl.hh[i],lat.yl.hh[i],labels='XiaoLangDi',cex=t.cex,pos=3,col=gray(.5),
             bg='white',family='Times')

  plot(1,1,xlim=c(0,1),ylim=c(0,1),type='n',axes=F,xlab='',ylab='')
  rasterImage(net.png,0,0.05,1,.95)

dev.off()
