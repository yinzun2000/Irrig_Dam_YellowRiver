#plot discharge yield, it is equal to runoff+draiage
source('lib/lib_et.R')
source('lib/lib_plot.R')
source('lib/lib_gis.R')
library('Kendall')

if (!exists('run.t.ni'))
{
  source('read/dis/read_dis_tab.R')
  source('read/run/read_run_tab.R')
  source('read/dra/read_dra_tab.R')
  source('read/pre/read_pre_tab.R')
  source('read/irr/read_irr_tab.R')
  source('read/subregion/read_subregion_var_tab.R')

  #discharge yield; unit is mm.yr-1
  dy.t.ni <-  run.t.ni + dra.t.ni
  dy.t.ir <-  run.t.ir + dra.t.ir - irr.t.ir

  dy.cn.c.ni  <-  run.cn.c.ni + dra.cn.c.ni
  dy.cn.c.ir  <-  run.cn.c.ir + dra.cn.c.ir - irr.cn.c.ir

  dy.yl.c.ni  <-  run.yl.c.ni + dra.yl.c.ni
  dy.yl.c.ir  <-  run.yl.c.ir + dra.yl.c.ir - irr.yl.c.ir

  dy.yz.c.ni  <-  run.yz.c.ni + dra.yz.c.ni
  dy.yz.c.ir  <-  run.yz.c.ir + dra.yz.c.ir - irr.yz.c.ir
}

lab.st.yl <-  c('TangNaiHai','LanZhou','TouDaoGuai','HuaYuanKou','LiJin')
lab.st.yz <-  c('PingShan','ZhuTuo','YiChang','HanKou','DaTong')

lab2.st.yl <-  c(expression('(a) R'[1]),
                 expression('(b) R'[2]),
                 expression('(c) R'[3]),
                 expression('(d) R'[4]),
                 expression('(e) R'[5]))
lab2.st.yz <-  c('(f) PingShan','(g) ZhuTuo','(h) YiChang',
                 '(i) HanKou','(j) DaTong')


pdf('fig/dis_yield_subregion_yl.pdf',width=9,height=6)
  par(mfrow=c(2,3),oma=c(2,4.5,0,5)+.5,
      mar=c(2,0,1,0),cex.axis=1.2,cex.lab=1.5)

#top: Yellow River; buttom: Yangtze River

  for (i in 1:5)
  {
    ni.tmp <-  run.sr2.m.yl.ni[i,]+dra.sr2.m.yl.ni[i,]
    ir.tmp <-  run.sr2.m.yl.ir[i,]+dra.sr2.m.yl.ir[i,]-irr.sr2.m.yl.ir[i,]
    v.tmp <-  SeasonalAverage1D(ni.tmp-ir.tmp,length(time.a))
    plot(seq(.5,11.5),v.tmp,ylim=c(-5,40),axes=F,
         xlim=c(0,12),
         xlab='',ylab='',pch=16,col=ifelse(v.tmp>=0,4,2))
    lines(seq(.5,11.5),v.tmp,col=4)
    points(seq(.5,11.5),v.tmp,pch=16,col=ifelse(v.tmp>=0,4,2))
    box()
    axis(1,at=seq(.5,11.5),labels=lab.m,cex.axis=1)
    if (i == 1 | i == 4)
    {
      axis(2,col.ticks=4,col.axis=4)
      if (i == 1)
        mtext(side=2,expression('Discharge yield (mm.mon'^{-1}*')'),
              line=3,cex=1,outer=T,col=4)
    }

    #plot diff sm seasonality
    par(new=T)
    ni.tmp <-  sm.sr2.m.yl.ni[i,]
    ir.tmp <-  sm.sr2.m.yl.ir[i,]
    v.tmp <-  SeasonalAverage1D(ni.tmp-ir.tmp,length(time.a))
    plot(seq(.5,11.5),v.tmp,ylab='',xlab='',
         xlim=c(0,12),
         axes=F,pch=17,ylim=c(-.03,.01),col=col.ind(12)[5])
    lines(seq(.5,11.5),v.tmp,col=col.ind(12)[5])
    if (i == 3 | i == 5)
      axis(4,col.ticks=col.ind(12)[5],col.axis=col.ind(12)[5])

    par(new=T)
    ir.tmp <-  irr.sr2.m.yl.ir[i,]
    v.tmp <-  SeasonalAverage1D(ir.tmp,length(time.a))
    barplot(v.tmp,axes=F,col=rgb(1,1,1,.1),xlim=c(0,12),
            space=0,
            border=col.ind(12)[10],ylim=c(0,40))
    text(-.5,38,labels=lab2.st.yl[i],pos=4,cex=1.5)

    if (i == 3)
    {
      legend(5.8,39,lty=1,pch=c(16,17),col=c(4,col.ind(12)[5]),
             legend=c(expression(italic(Y)['Q,NI']-italic(Y)['Q,IR'],
                                 SM[NI]-SM[IR])),
             cex=1.3,bty='n')

      legend(5.8,33.2,fill=NULL,border=col.ind(12)[10],
             legend=expression('         '*italic(I)[IR]),
             cex=1.3,bty='n')
    }

    if (i == 3)
      axis(4,col.ticks=col.ind(12)[10],col.axis=col.ind(12)[10],
           col=col.ind(12)[10],line=3)

    if (i == 5)
    {
      mtext(side=4,expression('Soil moisture (m'^3*'.m'^{-3}*')'),
            col=col.ind(12)[5],line=3)
      axis(4,col.ticks=col.ind(12)[10],col.axis=col.ind(12)[10],
           col=col.ind(12)[10],line=4.5)
      mtext(side=4,expression('Irrigation (mm.mon'^{-1}*')'),
            col=col.ind(12)[10],line=7.5)
    }
  }


dev.off()
