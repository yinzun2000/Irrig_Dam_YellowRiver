#here are functions and parameters used for ET analysis
library('RNetCDF')
library('hydroGOF')
library('zoo')

ReadTWS <-  function(irr,t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_'
    t1      <-  '_05deg_8214Y_CN_M.nc'

    nc      <-  open.nc(paste0(path,irr,t1))
    if (is.na(t.s))
    {
      sm      <-  var.get.nc(nc,'humtot')
      snow    <-  var.get.nc(nc,'snow')
      qs.tmp  <-  var.get.nc(nc,'qsintveg')
      fast    <-  var.get.nc(nc,'fastr')
      slow    <-  var.get.nc(nc,'slowr')
      stre    <-  var.get.nc(nc,'streamr')
      lake    <-  var.get.nc(nc,'lakevol')
      pond    <-  var.get.nc(nc,'pondr')
    } else
    {
      sm      <-  var.get.nc(nc,'humtot',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      snow    <-  var.get.nc(nc,'snow',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      qs.tmp  <-  var.get.nc(nc,'qsintveg',
                             start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      fast    <-  var.get.nc(nc,'fastr',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      slow    <-  var.get.nc(nc,'slowr',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      stre    <-  var.get.nc(nc,'streamr',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      lake    <-  var.get.nc(nc,'lakevol',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      pond    <-  var.get.nc(nc,'pondr',
                             start=c(NA,NA,t.s),count=c(NA,NA,t.c))
    }

    close.nc(nc)

    #qsintveg is already powered by maxvegetfrac, so just need to sum up
    qs  <-  apply(qs.tmp,c(1,2,4),sum,na.rm=T)

    val <-  sm+snow+qs+fast+slow+stre+lake+pond 
    return(val)
}

ReadGRACE   <-  function(id,dat,dim=3){
#id is the name of variable
#dat is data base name
  #g.yr  <-  c(2003,2011,2011,2012,2012,2013,2013,2013,2014,2014,2014,2015,2015,2015,2016,2016,2016)
  #g.mon <-  c(6,1,6,5,10,3,8,9,2,7,12,6,10,11,4,9,10)

#as GSFC no whole data in 2016; so just read data from 2003 to 2015
  g.yr  <-  c(2003,2011,2011,2012,2012,2013,2013,2013,2014,2014,2014,2015,2015,2015)
  g.mon <-  c(6,1,6,5,10,3,8,9,2,7,12,6,10,11)

  yr.start  <-  2003
  yr.end    <-  2015

  t.c <- 142

  path    <-  '/home/surface4/vyin/data/grace/new/'
  if (dat == "CSR")
  {
    t1      <-  'GRACE_CSR_200204_201701_CN_M.nc'
    t.s <- 8
  } else if (dat == "JPL")
  {
    t1      <-  'GRACE_JPL_200204_201706_CN_M.nc'
    t.s <- 8
  } else if (dat == "GSFC")
  {
    t1      <-  'GRACE_GSFC_200301_201607_CN_M.nc'
    t.s <- 1
  }

  nc  <-  open.nc(paste0(path,t1))
  if (is.na(t.s))
  {
    val <-  var.get.nc(nc,id)
  } else
    val <-  var.get.nc(nc,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))

  close.nc(nc)

  num.yr  <-  yr.end - yr.start + 1
  out <-  array(NA,dim=c(dim(val)[1:2],(yr.end-yr.start+1)*12))  #lat*lon*time

  #pointer to the old data
  p.o <-  1
  #pointer to the new data
  p.n <-  1
  #pointer to the gap date
  p.g <-  1

  for (yr in yr.start:yr.end)
  for (mon in 1:12)
  {
    #found gap year
    if (p.g <= length(g.yr) & yr == g.yr[p.g] & mon == g.mon[p.g])
    {
      p.n <-  p.n+1
      p.g <-  p.g+1
    }
    else
    {
      out[,,p.n]  <-  val[,,p.o]
      p.n <-  p.n+1
      p.o <-  p.o+1
    }
  }

  #interpolation
  for (nx in 1:dim(out)[1])
  for (ny in 1:dim(out)[2])
  {
    if (!is.na(out[nx,ny,1]) & !is.na(out[nx,ny,num.yr]))
      out[nx,ny,] <-  na.approx(out[nx,ny,])
  }

  return(out)
}

AnnualAverage <-  function(var,num.y){
#var is the monthly input
#num.y is number of years
    output  <-  array(NA,dim=c(dim(var)[1:2],num.y))
    for (yr in 1:num.y)
        {
            output[,,yr]    <-
                apply(var[,,(12*(yr-1)+1):(12*yr)],
                      c(1,2),mean,na.rm=T)
        }

    return(output)
}

AnnualAverage1D <-  function(var){
#var is the monthly input
#num.y is number of years
    output  <-  array(NA,dim=c(length(var)/12))
    for (yr in 1:length(output))
        {
            output[yr]  <-
                mean(var[(12*(yr-1)+1):(12*yr)],
                      na.rm=T)
        }

    return(output)
}

SeasonalAverage <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1:2],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,,mon]   <-  output[,,mon]+var[,,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}


SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SpatialAverage  <-  function(id,input,bmap,n.len){
    #id is the region id for averaging
    #input is the val used as input
    #bmap is the basin map
    #n.len is the length of the time series
    val <-  array(NA,dim=n.len)
    for (i in 1:n.len)
    {
        v.tmp   <-  input[,,i]
        if (id < 0)
            val[i] <-  mean(v.tmp,na.rm=T)
        else
            val[i] <-  mean(v.tmp[bmap == id],na.rm=T)
    }
    return(val)
}

ReadBasinMap    <-  function(){
    filei   <-  'mask/basin.nc'
    bm.nc   <-  open.nc(filei)
    bmap    <-  var.get.nc(bm.nc,'basinmap')
    close.nc(bm.nc)
    return(bmap)
}

DeSeason1D <-  function(val){
  #val is a matrix: [pro,time series]
  num.yr  <-  length(val)/12
  out <-  val - rep(SeasonalAverage1D(val,num.yr),num.yr)
  return(out)
}

ReadMaskMap    <-  function(){
    filei   <-  'mask/mask.nc'
    bm.nc   <-  open.nc(filei)
    cnland  <-  var.get.nc(bm.nc,'mask')
    close.nc(bm.nc)
    return(cnland)
}

D2M <-  function(){
    num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)
    return(output)
}

#~~~~~~~~~~~PARAMETERS and MASKS~~~~~~~~~~~~
id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
bmap    <-  ReadBasinMap()

#mask data to only China region
cnland  <-  ReadMaskMap()
