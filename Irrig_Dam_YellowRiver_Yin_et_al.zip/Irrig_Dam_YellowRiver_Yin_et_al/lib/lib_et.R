#here are functions and parameters used for ET analysis
library('RNetCDF')
library('hydroGOF')
library('spacetime')
library('trend')

ReadET  <-  function(id,freq,irr,t.s=NA,t.c=NA,dim=3){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_'
    t1      <-  '_05deg_8214Y_CN_'
    t2      <-  '.nc'

    nc      <-  open.nc(paste0(path,irr,t1,freq,t2))
    if (is.na(t.s))
    {
        val <-  var.get.nc(nc,id)
    } else
    {
        if (dim == 3)
        {
            val     <-  var.get.nc(nc,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))
        } else if (dim == 4)
        {
            val     <-  var.get.nc(nc,id,start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
        }
    }

    close.nc(nc)
    return(val)
}

ReadScolETr <-  function(freq,irr,t.s=NA,t.c=NA){
#read soil column based ET related flux, rate only
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_'
    t1      <-  '_05deg_8214Y_CN_'
    t2      <-  '.nc'

    nc      <-  open.nc(paste0(path,irr,t1,freq,t2))
    if (is.na(t.s))
    {
      evp.tmp  <-  var.get.nc(nc,'evapnu_soil')
      tsp.tmp  <-  var.get.nc(nc,'transpir_soil')
      dra.tmp  <-  var.get.nc(nc,'drainage_soil')
      run.tmp  <-  var.get.nc(nc,'runoff_soil')
      sm.tmp   <-  var.get.nc(nc,'humtot_soil')
      int.tmp  <-  var.get.nc(nc,'inter')
      mfc      <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
      evp.tmp  <-  var.get.nc(nc,'evapnu_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      tsp.tmp  <-  var.get.nc(nc,'transpir_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      dra.tmp  <-  var.get.nc(nc,'drainage_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      run.tmp  <-  var.get.nc(nc,'runoff_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      sm.tmp   <-  var.get.nc(nc,'humtot_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      int.tmp  <-  var.get.nc(nc,'inter',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      mfc      <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    evp.r <-  GetFromScol(evp.tmp,mfc)
    tsp.r <-  GetFromScol(tsp.tmp,mfc)
    dra.r <-  GetFromScol(dra.tmp,mfc)
    run.r <-  GetFromScol(run.tmp,mfc)
    sm.r  <-  GetFromScol(sm.tmp,mfc)
    int.r <-  GetFromPFT(int.tmp,mfc)

    #soil

    #int.r <-  int/mfc
    #int.r[is.infinit(int.r) | is.na(int.r)]  <-  0

    val <-  list(evp=evp.r,tsp=tsp.r,dra=dra.r,
                 run=run.r,sm=sm.r,int=int.r)

    return(val)
}

ReadScolETa <-  function(freq,irr,t.s=NA,t.c=NA){
#read soil column based ET related flux, amount only
#amount is flux * maxvegetfrac
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_'
    t1      <-  '_05deg_8214Y_CN_'
    t2      <-  '.nc'

    nc      <-  open.nc(paste0(path,irr,t1,freq,t2))
    if (is.na(t.s))
    {
      evp.tmp  <-  var.get.nc(nc,'evapnu_soil')
      tsp.tmp  <-  var.get.nc(nc,'transpir_soil')
      dra.tmp  <-  var.get.nc(nc,'drainage_soil')
      run.tmp  <-  var.get.nc(nc,'runoff_soil')
      sm.tmp   <-  var.get.nc(nc,'humtot_soil')
      int.tmp  <-  var.get.nc(nc,'inter')
      mfc      <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
      evp.tmp  <-  var.get.nc(nc,'evapnu_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      tsp.tmp  <-  var.get.nc(nc,'transpir_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      dra.tmp  <-  var.get.nc(nc,'drainage_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      run.tmp  <-  var.get.nc(nc,'runoff_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      sm.tmp   <-  var.get.nc(nc,'humtot_soil',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      int.tmp  <-  var.get.nc(nc,'inter',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
      mfc      <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    evp.a <-  GetFromScol(evp.tmp,mfc,flux=F)
    tsp.a <-  GetFromScol(tsp.tmp,mfc,flux=F)
    dra.a <-  GetFromScol(dra.tmp,mfc,flux=F)
    run.a <-  GetFromScol(run.tmp,mfc,flux=F)
    sm.a  <-  GetFromScol(sm.tmp,mfc,flux=F)
    int.a <-  GetFromPFT(int.tmp,mfc,flux=F)

    #soil

    #int.r <-  int/mfc
    #int.r[is.infinit(int.r) | is.na(int.r)]  <-  0

    val <-  list(evp=evp.a,tsp=tsp.a,dra=dra.a,
                 run=run.a,sm=sm.a,int=int.a)

    return(val)
}

GetFromScol <-  function(val,mfc,flux=TRUE){
  #get soil tile data from soil column
  #val: should be flux
  #mfc.in: maximum vegetation fraction
  #if flux = True, output will be flux rate
  #otherwise output will be flux*mfc

  #out dimension: nx*ny*scol[soil, tree, grass, crop]*time
  out <-  array(NA,dim=c(dim(val)[1:2],4,dim(val)[4]))

  if (flux)
  {
    #bare soil
    out[,,1,] <-  val[,,1,]

    #trees
    out[,,2,] <-  val[,,2,]

    #grasses
    out[,,3,] <-  val[,,3,]

    #crops
    out[,,4,] <-  apply(val[,,4:6,]*mfc[,,12:14,],c(1,2,4),sum,na.rm=T)/
                  apply(mfc[,,12:14,],c(1,2,4),sum,na.rm=T)
  } else
  {
    #bare soil
    out[,,1,] <-  val[,,1,]*mfc[,,1,]

    #trees
    out[,,2,] <-  val[,,2,]*apply(mfc[,,2:9,],c(1,2,4),sum,na.rm=T)

    #grasses
    out[,,3,] <-  val[,,3,]*apply(mfc[,,10:11,],c(1,2,4),sum,na.rm=T)

    #crops
    out[,,4,] <-  apply(val[,,4:6,]*mfc[,,12:14,],c(1,2,4),sum,na.rm=T)
  }


  return(out)
}

GetFromPFT <-  function(val,mfc,flux=TRUE){
  #get soil tile data from PFT dimension
  #val: should be flux
  #mfc: maximum vegetation fraction
  #if flux = True, output will be flux rate
  #otherwise output will be flux*mfc

  #out dimension: nx*ny*scol[soil, tree, grass, crop]*time
  out <-  array(NA,dim=c(dim(val)[1:2],4,dim(val)[4]))

  if (flux)
  {
    #bare soil
    out[,,1,] <-  val[,,1,]

    #trees
    out[,,2,] <-  apply(val[,,2:9,]*mfc[,,2:9,],c(1,2,4),sum,na.rm=T)/
                  apply(mfc[,,2:9,],c(1,2,4),sum,na.rm=T)

    #grasses
    out[,,3,] <-  apply(val[,,10:11,]*mfc[,,10:11,],c(1,2,4),sum,na.rm=T)/
                  apply(mfc[,,10:11,],c(1,2,4),sum,na.rm=T)

    #crops
    out[,,4,] <-  apply(val[,,12:14,]*mfc[,,12:14,],c(1,2,4),sum,na.rm=T)/
                  apply(mfc[,,12:14,],c(1,2,4),sum,na.rm=T)
  } else
  {
    #bare soil
    out[,,1,] <-  val[,,1,]*mfc[,,1,]

    #trees
    out[,,2,] <-  apply(val[,,2:9,]*mfc[,,2:9,],c(1,2,4),sum,na.rm=T)

    #grasses
    out[,,3,] <-  apply(val[,,10:11,]*mfc[,,10:11,],c(1,2,4),sum,na.rm=T)

    #crops
    out[,,4,] <-  apply(val[,,12:14,]*mfc[,,12:14,],c(1,2,4),sum,na.rm=T)
  }

  return(out)
}

AnnualAverage   <-  function(var,num.y){
#var is the monthly input
#num.y is number of years
    output  <-  array(NA,dim=c(dim(var)[1:2],num.y))
    for (yr in 1:num.y)
        {
            output[,,yr]    <-
                apply(var[,,(12*(yr-1)+1):(12*yr)],c(1,2),mean,na.rm=T)
        }

    return(output)
}

AnnualAverageScol <-  function(var,num.y){
#var is the monthly input
#num.y is number of years
  output  <-  array(NA,dim=c(dim(var)[1:3],num.y))
  for (yr in 1:num.y)
      {
          output[,,,yr]   <-
              apply(var[,,,(12*(yr-1)+1):(12*yr)],c(1,2,3),mean,na.rm=T)
      }

  return(output)
}

SeasonalAverage <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1:2],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,,mon]   <-  output[,,mon]+var[,,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SeasonalAverageScol <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1:3],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,,,mon]  <-  output[,,,mon]+var[,,,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SeasonalAverage1DScol <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,mon]  <-  output[,mon]+var[,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SpatialAverage  <-  function(id,input,bmap,n.len){
    #id is the region id for averaging
    #input is the val used as input
    #bmap is the basin map
    #n.len is the length of the time series
    val <-  array(NA,dim=n.len)
    for (i in 1:n.len)
    {
        v.tmp   <-  input[,,i]
        if (id < 0)
            val[i] <-  mean(v.tmp,na.rm=T)
        else
            val[i] <-  mean(v.tmp[bmap == id],na.rm=T)
    }
    return(val)
}

SpatialAverageScol  <-  function(id,input,bmap,n.len){
    #id is the region id for averaging
    #input is the val used as input
    #bmap is the basin map
    #n.len is the length of the time series
    val <-  array(NA,dim=c(dim(input)[3],n.len))
    for (i in 1:n.len)
    for (k in 1:dim(input)[3])
    {
        v.tmp   <-  input[,,k,i]
        if (id < 0)
            val[k,i] <-  mean(v.tmp,na.rm=T)
        else
            val[k,i] <-  mean(v.tmp[bmap == id],na.rm=T)
    }
    return(val)
}

ReadBasinMap    <-  function(){
    filei   <-  'mask/basin.nc'
    bm.nc   <-  open.nc(filei)
    bmap    <-  var.get.nc(bm.nc,'basinmap')
    close.nc(bm.nc)
    return(bmap)
}

ReadMaskMap    <-  function(){
    filei   <-  'mask/mask.nc'
    bm.nc   <-  open.nc(filei)
    cnland  <-  var.get.nc(bm.nc,'mask')
    close.nc(bm.nc)
    return(cnland)
}

D2M <-  function(){
    num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)
    return(output)
}

ReadGLEAM   <-  function(id){
    t.s <-  1
    t.c <-  396
    path    <-  '/home/surface4/vyin/data/gleam/v3.2/a/'
    filet   <-  '_GLEAM_v32a_8214_05deg_CN_M.nc'

    nc.gl   <-  open.nc(paste0(path,id,filet))
    v.tmp   <-
    var.get.nc(nc.gl,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))
    close.nc(nc.gl)
    #the original format is (lat,lon,time). should change to
    #(lon,lat,time)
    val     <-
        array(0,dim=c(dim(v.tmp)[2],dim(v.tmp)[1],dim(v.tmp)[3]))
    for (i in 1:dim(v.tmp)[3])
        val[,,i]    <-  t(v.tmp[,,i])

    return(val)
}

ReadMPI <-  function(id,t.s=1,t.c=360){
    # l is the coefficient to change the unit from MJ.m-2.d-1 to mm.d-1
    l   <-  1e6/(3600*24*28.94)
    filei   <-  '/home/surface4/vyin/data/MPI/ET/ET_MPI_05deg_8211_CN_M.nc'

    nc.mp   <-  open.nc(filei)
    val <-  var.get.nc(nc.mp,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))*l
    close.nc(nc.mp)

    return(val)
}

CorET   <-  function(val.ob,val.orc,id,irr,cnland,dat,freq)
{
#val.ob: input of obs
#val.orc: input of orc
#id: variable name
#irr: irrigation scheme
#cnland: mask of CN land
#dat: abbreviation name like 'ni', 'mp', 'gl'
#freq: frequency in the name of output, like 'm','a','d'
    cor.o <-  array(NA,dim=dim(val.orc)[1:2])
    p.o   <-  array(NA,dim=dim(val.orc)[1:2])
    rmse.o<-  array(NA,dim=dim(val.orc)[1:2])
    sb.o  <-  array(NA,dim=dim(val.orc)[1:2])
    sdsd.o<-  array(NA,dim=dim(val.orc)[1:2])
    lcs.o <-  array(NA,dim=dim(val.orc)[1:2])

    for (nx in 1:dim(val.orc)[1])
    for (ny in 1:dim(val.orc)[2])
    {
        print(paste0('nx=',nx,';ny=',ny))
        if (cnland[nx,ny] < .5)
            next
        ob.tmp  <-  val.ob[nx,ny,]
        orc.tmp <-  val.orc[nx,ny,]
        if (length(ob.tmp[!is.na(ob.tmp)]) < 20 | length(orc.tmp[!is.na(orc.tmp)]) < 20)
            next

        cor.tmp     <-  cor.test(ob.tmp,orc.tmp)
        p.o[nx,ny]  <-  as.numeric(cor.tmp$p.value)
        cor.o[nx,ny]    <-  as.numeric(cor.tmp$estimate)
        rmse.o[nx,ny]   <-  rmse(ob.tmp,orc.tmp,na.rm=T)
        sb.o[nx,ny] <-  SB(ob.tmp,orc.tmp)
        sdsd.o[nx,ny]   <-  SDSD(ob.tmp,orc.tmp)
        lcs.o[nx,ny]    <-  LCS(ob.tmp,orc.tmp)
    }

    write.table(cor.o,paste0('tab/cor.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(p.o,paste0('tab/p.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(rmse.o,paste0('tab/rmse.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(sb.o,paste0('tab/sb.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(sdsd.o,paste0('tab/sdsd.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(lcs.o,paste0('tab/lcs.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
}

CorET   <-  function(val.ob,val.orc,id,irr,cnland,dat,freq)
{
#val.ob: input of obs
#val.orc: input of orc
#id: variable name
#irr: irrigation scheme
#cnland: mask of CN land
#dat: abbreviation name like 'ni', 'mp', 'gl'
#freq: frequency in the name of output, like 'm','a','d'
    cor.o <-  array(NA,dim=dim(val.orc)[1:2])
    p.o   <-  array(NA,dim=dim(val.orc)[1:2])
    rmse.o<-  array(NA,dim=dim(val.orc)[1:2])
    sb.o  <-  array(NA,dim=dim(val.orc)[1:2])
    sdsd.o<-  array(NA,dim=dim(val.orc)[1:2])
    lcs.o <-  array(NA,dim=dim(val.orc)[1:2])

    for (nx in 1:dim(val.orc)[1])
    for (ny in 1:dim(val.orc)[2])
    {
        print(paste0('nx=',nx,';ny=',ny))
        if (cnland[nx,ny] < .5)
            next
        ob.tmp  <-  val.ob[nx,ny,]
        orc.tmp <-  val.orc[nx,ny,]
        if (length(ob.tmp[!is.na(ob.tmp)]) < 20 | length(orc.tmp[!is.na(orc.tmp)]) < 20)
            next

        cor.tmp     <-  cor.test(ob.tmp,orc.tmp)
        p.o[nx,ny]  <-  as.numeric(cor.tmp$p.value)
        cor.o[nx,ny]    <-  as.numeric(cor.tmp$estimate)
        rmse.o[nx,ny]   <-  rmse(ob.tmp,orc.tmp,na.rm=T)
        sb.o[nx,ny] <-  SB(ob.tmp,orc.tmp)
        sdsd.o[nx,ny]   <-  SDSD(ob.tmp,orc.tmp)
        lcs.o[nx,ny]    <-  LCS(ob.tmp,orc.tmp)
    }

    write.table(cor.o,paste0('tab/cor.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(p.o,paste0('tab/p.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(rmse.o,paste0('tab/rmse.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(sb.o,paste0('tab/sb.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(sdsd.o,paste0('tab/sdsd.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
    write.table(lcs.o,paste0('tab/lcs.',id,'.',freq,'.',dat,'.',irr),row.names=F,col.names=F,sep='\t')
}


DifET   <-  function(val.ob,val.orc,id,irr,dat,freq)
{
#val.ob: input of obs
#val.orc: input of orc
#id: variable name
#irr: irrigation scheme
#dat: abbreviation name like 'ni', 'mp', 'gl'
#freq: frequency in the name of output, like 'm','a','d'
    dif.o   <-  val.ob - val.orc
    write.table(dif.o,paste('tab/dif.',id,'.',freq,'.',dat,'.',irr,sep=''),row.names=F,col.names=F,sep='\t')
}

Trend3D <-  function(val,mask,id,freq,dat)
{
  #calculate the trend of 3D data [lon,lat,time]
  #val: data of 3D
  #mask: is a flag matrix of land
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  #id: variable id, e.g., 'et'
  #freq: frequency, e.g., 'm'
  #dat: dat name or simulation name, e.g., 'gl','ir'
  p.tmp <-  array(NA,dim=dim(val)[1:2])
  k.tmp<-  array(NA,dim=dim(val)[1:2])

  for (nx in 1:dim(val)[1])
  for (ny in 1:dim(val)[2])
  {
    if (mask[nx,ny] < .5)
      next

    v.tmp <-  val[nx,ny,]
    v.tmp <-  v.tmp[!is.na(v.tmp)]
    if (length(v.tmp) < 10)
      next

    ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
    tr.tmp  <-  mk.test(ts.tmp)
    slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
    #sen.tmp <-  sens.slope(ts.tmp)
    p.tmp[nx,ny]  <-  tr.tmp$pvalue
    k.tmp[nx,ny]  <-  as.numeric(slo.tmp$coefficients[2])
  }

  write.table(p.tmp,paste0('tab/tr.p.',id,'.',freq,'.',dat),
              row.names=F,col.names=F,sep='\t')
  write.table(k.tmp,paste0('tab/tr.k.',id,'.',freq,'.',dat),
              row.names=F,col.names=F,sep='\t')
}

Trend3DSeason <-  function(val,mask,id,dat)
{
  #calculate the trend of 3D data [lon,lat,time]
  #val: data of 3D
  #mask: is a flag matrix of land
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  #id: variable id, e.g., 'et'
  #dat: dat name or simulation name, e.g., 'gl','ir'
  p.tmp <-  array(NA,dim=c(dim(val)[1:2],12))
  k.tmp<-  array(NA,dim=c(dim(val)[1:2],12))

  for (nx in 1:dim(val)[1])
  for (ny in 1:dim(val)[2])
  {
    if (mask[nx,ny] < .5)
      next

    for (mon in 1:12)
    {
      v.tmp <-  val[nx,ny,seq(mon,dim(val)[3],12)]
      v.tmp <-  v.tmp[!is.na(v.tmp)]
      if (length(v.tmp) < 10)
        next

      ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
      tr.tmp  <-  mk.test(ts.tmp)
      slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
      p.tmp[nx,ny,mon]  <-  tr.tmp$pvalue
      k.tmp[nx,ny,mon]  <-  as.numeric(slo.tmp$coefficients[2])
    }
  }

  write.table(p.tmp,paste0('tab/tr.p.',id,'.season.',dat),
              row.names=F,col.names=F,sep='\t')
  write.table(k.tmp,paste0('tab/tr.k.',id,'.season.',dat),
              row.names=F,col.names=F,sep='\t')
}

TrendScol3D <-  function(val,mask,id,freq,dat)
{
  #calculate the trend of 3D data [lon,lat,time]
  #val: data of 3D
  #mask: is a flag matrix of land
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  #id: variable id, e.g., 'et'
  #freq: frequency, e.g., 'm'
  #dat: dat name or simulation name, e.g., 'gl','ir'
  p.tmp <-  array(NA,dim=dim(val)[1:3])
  k.tmp<-  array(NA,dim=dim(val)[1:3])

  for (nx in 1:dim(val)[1])
  for (ny in 1:dim(val)[2])
  for (k  in 1:dim(val)[3])
  {
    if (mask[nx,ny] < .5)
      next

    v.tmp <-  val[nx,ny,k,]
    v.tmp <-  v.tmp[!is.na(v.tmp)]
    if (length(v.tmp) < 10)
      next

    ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
    tr.tmp  <-  mk.test(ts.tmp)
    slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
    #sen.tmp <-  sens.slope(ts.tmp)
    p.tmp[nx,ny,k]  <-  tr.tmp$pvalue
    k.tmp[nx,ny,k]  <-  as.numeric(slo.tmp$coefficients[2])
  }

  write.table(p.tmp,paste0('tab/scol/tr.p.',id,'.',freq,'.',dat),
              row.names=F,col.names=F,sep='\t')
  write.table(k.tmp,paste0('tab/scol/tr.k.',id,'.',freq,'.',dat),
              row.names=F,col.names=F,sep='\t')
}

Trend1D <-  function(val)
{
  #calculate the trend of 1D data [time]
  #val: data of 1D
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  v.tmp <-  val[!is.na(val)]
  if (length(v.tmp) < 10)
    next

  ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
  tr.tmp  <-  mk.test(ts.tmp)
  #sen.tmp <-  sens.slope(ts.tmp)
  slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
  p.tmp  <-  tr.tmp$pvalue
  k.tmp  <-  as.numeric(slo.tmp$coefficients[2])

  out <-  list(p=p.tmp,k=k.tmp)

  return(out)
}

#~~~~~~~~~~~PARAMETERS and MASKS~~~~~~~~~~~~
id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
bmap    <-  ReadBasinMap()

#mask data to only China region
cnland  <-  ReadMaskMap()
