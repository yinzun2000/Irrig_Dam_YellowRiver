library('rgdal')
library('maptools')

sys.id  <-  Sys.info()['nodename']
if (grepl('obelix',sys.id)){
            wk.dir  <-  'obelix'
} else if (grepl('lsce',sys.id)){
            wk.dir  <-  'mbp'
} else if (grepl('furion',sys.id)){
            wk.dir  <-  'mbp'
} else{
            stop('unknown computer')
}

if (wk.dir == 'mbp')
{
            path.gis    <-  '~/Documents/data/GIS/'
} else
{
            path.gis    <-  '/home/surface4/data/GIS/'
}

if (!exists('rbsin.gis'))
{
    #read China province data
    filei   <-  paste(path.gis,'Provinces_1997/province_reprojected.shp',sep='')
    pro.gis <-  readOGR(filei)
    proj4string(pro.gis)    <-  '+proj=longlat +datum=WGS84'

        #read China data
        filei   <-  paste(path.gis,'Provinces_1997/China.shp',sep='')
            cn.gis  <-  readOGR(filei)
            proj4string(cn.gis)     <-  '+proj=longlat +datum=WGS84'
            #read river basin data
            filei   <-  paste(path.gis,'cn_wtrshed_coarse/ch_wtrshed_30mar11.shp',sep='')
            #rbsin.gis   <-  readShapePoly(filei)
            rbsin.gis   <-  readOGR(filei)
            proj4string(rbsin.gis)  <-  '+proj=longlat +datum=WGS84'

            #read river network data
            filei   <-  paste(path.gis,'River_network_CN/River_basin_num2.shp',sep='')
            rnet.gis    <-  readOGR(filei)
            proj4string(rnet.gis)   <-  '+proj=longlat +datum=WGS84'
}
            
#id of river basin
RCODE.yl    <-  10
RCODE.yz    <-  13

PlotCNRiver <-  function(){
  plot(cn.gis,add=T,border=gray(.5))
  plot(rbsin.gis[rbsin.gis$RCODE == RCODE.yl,],add=T,border=6)
  plot(rbsin.gis[rbsin.gis$RCODE == RCODE.yz,],add=T,border=2)
  #for (i in 1:3)
  #{
  #    plot(rnet.gis[rnet.gis$REGION == 'Yellow River' & rnet.gis$LEVEL_RIVE == i,],add=T,col=4)
  #    plot(rnet.gis[rnet.gis$REGION == 'Yangzi River' & rnet.gis$LEVEL_RIVE == i,],add=T,col=4)
  #}
}

PlotCN <-  function(){
  plot(cn.gis,add=T,border=gray(.5))
}


PlotYLRiver <-  function(){
  plot(cn.gis,add=T,border=gray(.5))
  plot(rbsin.gis[rbsin.gis$RCODE == RCODE.yl,],add=T,col=6,lwd=2)
  for (i in 1:3)
    plot(rnet.gis[rnet.gis$REGION == 'Yellow River' & rnet.gis$LEVEL_RIVE == i,],add=T,col=4)
}

PlotYZRiver <-  function(){
  plot(cn.gis,add=T,border=gray(.5))
  plot(rbsin.gis[rbsin.gis$RCODE == RCODE.yz,],add=T,col=2,lwd=2)
  for (i in 1:3)
    plot(rnet.gis[rnet.gis$REGION == 'Yangzi River' & rnet.gis$LEVEL_RIVE == i,],add=T,col=4)
}
