#here are functions and parameters used for LAI analysis
library('RNetCDF')

ReadMFC   <-  function(freq,t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ir_05deg_8214Y_CN_'
    t1      <-  '.nc'

    nc      <-  open.nc(paste0(path,freq,t1))
    if (is.na(t.s))
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    #calculate the mean maxvegetfrac of crops
    val <-  apply(mfc,c(1,2,3),mean,na.rm=T)

    return(val)
}

ReadMFCSoil <-  function(freq,t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ir_05deg_8214Y_CN_'
    t1      <-  '.nc'

    nc      <-  open.nc(paste0(path,freq,t1))
    if (is.na(t.s))
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    #calculate the mean maxvegetfrac of crops
    val <-  mfc[,,1,]

    return(val)
}

ReadMFCCrop <-  function(freq,t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ir_05deg_8214Y_CN_'
    t1      <-  '.nc'

    nc      <-  open.nc(paste0(path,freq,t1))
    if (is.na(t.s))
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    #calculate the mean maxvegetfrac of crops
    val <-  apply(mfc[,,12:14,],c(1,2,4),sum,na.rm=T)

    return(val)
}

ReadMFCTree <-  function(freq,t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ir_05deg_8214Y_CN_'
    t1      <-  '.nc'

    nc      <-  open.nc(paste0(path,freq,t1))
    if (is.na(t.s))
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    #calculate the mean maxvegetfrac of crops
    val <-  apply(mfc[,,2:9,],c(1,2,4),sum,na.rm=T)

    return(val)
}

ReadMFCGrass <-  function(freq,t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ir_05deg_8214Y_CN_'
    t1      <-  '.nc'

    nc      <-  open.nc(paste0(path,freq,t1))
    if (is.na(t.s))
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac')
    } else
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    #calculate the mean maxvegetfrac of crops
    val <-  apply(mfc[,,10:11,],c(1,2,4),sum,na.rm=T)

    return(val)
}

Trend3D <-  function(val,mask,id,freq,dat)
{
  #calculate the trend of 3D data [lon,lat,time]
  #val: data of 3D
  #mask: is a flag matrix of land
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  #id: variable id, e.g., 'et'
  #freq: frequency, e.g., 'm'
  #dat: dat name or simulation name, e.g., 'gl','ir'
  p.tmp <-  array(NA,dim=dim(val)[1:2])
  k.tmp<-  array(NA,dim=dim(val)[1:2])

  for (nx in 1:dim(val)[1])
  for (ny in 1:dim(val)[2])
  {
    if (mask[nx,ny] < .5)
      next

    v.tmp <-  val[nx,ny,]
    v.tmp <-  v.tmp[!is.na(v.tmp)]
    if (length(v.tmp) < 10)
      next

    ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
    tr.tmp  <-  mk.test(ts.tmp)
    slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
    #sen.tmp <-  sens.slope(ts.tmp)
    p.tmp[nx,ny]  <-  tr.tmp$pvalue
    k.tmp[nx,ny]  <-  as.numeric(slo.tmp$coefficients[2])
  }

  write.table(p.tmp,paste0('tab/scol/tr.p.',id,'.',freq,'.',dat),
              row.names=F,col.names=F,sep='\t')
  write.table(k.tmp,paste0('tab/scol/tr.k.',id,'.',freq,'.',dat),
              row.names=F,col.names=F,sep='\t')
}

Trend1D <-  function(val)
{
  #calculate the trend of 1D data [time]
  #val: data of 1D
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  v.tmp <-  val[!is.na(val)]
  if (length(v.tmp) < 10)
    next

  ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
  tr.tmp  <-  mk.test(ts.tmp)
  #sen.tmp <-  sens.slope(ts.tmp)
  slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
  p.tmp  <-  tr.tmp$pvalue
  k.tmp  <-  as.numeric(slo.tmp$coefficients[2])

  out <-  list(p=p.tmp,k=k.tmp)

  return(out)
}


id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
#bmap    <-  ReadBasinMap()

#mask data to only China region
#cnland  <-  ReadMaskMap()
