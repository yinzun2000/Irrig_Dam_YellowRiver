library('trend')
#calculate annual mean
AnnualMean  <-  function(val,num.yr){
    output  <-  array(0,dim=c(dim(val)[1],num.yr))

    for (yr in 1:num.yr)
        output[,yr] <-  apply(val[,(12*(yr-1)+1):(12*yr)],1,mean,na.rm=T)

    return(output)
}

SeasonalAverage2D <-  function(var,num.y){
  #var: [st,time]
  v.tmp   <-  array(0,dim=c(dim(var)[1],12,num.y))
  for (yr in 1:num.y)
  for (mon in 1:12)
      v.tmp[,mon,yr] <-  var[,(12*(yr-1)+mon)]

  output <-  apply(v.tmp,c(1,2),mean,na.rm=T)

  return(output)
}

SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SeasonalSum1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    return(output)
}


Trend1D <-  function(val)
{
  #calculate the trend of 1D data [time]
  #val: data of 1D
  #out: list: p value of trend based on Mann-Kendall test;
  #rate of trend
  v.tmp <-  val[!is.na(val)]
  if (length(v.tmp) < 10)
    next

  ts.tmp  <-  ts(v.tmp,start=c(1980,1),frequency=12)
  tr.tmp  <-  mk.test(ts.tmp)
  #sen.tmp <-  sens.slope(ts.tmp)
  slo.tmp <-  lm(v.tmp~seq(1,length(v.tmp)))
  p.tmp  <-  tr.tmp$pvalue
  k.tmp  <-  as.numeric(slo.tmp$coefficients[2])

  out <-  list(p=p.tmp,k=k.tmp)

  return(out)
}
