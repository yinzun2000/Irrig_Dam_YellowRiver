#some functions often used for analysis

SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

Anomaly1D <-  function(val)
{
  #val: is 1D [time] input data
  #n.len: length of time series
  len.a <-  length(val)/12
  val.c <-  SeasonalAverage1D(val,len.a)

  out <-  val
  for (yr in 1:len.a)
  for (mon in 1:12)
    out[12*(yr-1)+mon]  <-  val[12*(yr-1)+mon] - val.c[mon]

  return(out)
}

Anomaly3D <-  function(val,regmap)
{
  #val: is 3D [lon,lat,time] input data
  #regmap: is the region map 0 or 1
  out <-  val
  for (nx in 1:dim(val)[1])
  for (ny in 1:dim(val)[2])
  {
    if (regmap[nx,ny] < .5)
    {
      out[nx,ny,] <-  NA
    } else
      out[nx,ny,] <-  Anomaly1D(val[nx,ny,])
  }

  return(out)
}

CorCoe3D  <-  function(val1,val2,cnland)
{
#val1: input 1 3d [lon,lat,time]
#val2: input 2 3d [lon,lat,time]
#cnland: mask of CN land
    cor.o <-  array(NA,dim=dim(val1)[1:2])
    p.o   <-  array(NA,dim=dim(val1)[1:2])

    for (nx in 1:dim(val2)[1])
    for (ny in 1:dim(val2)[2])
    {
        print(paste0('nx=',nx,';ny=',ny))
        if (cnland[nx,ny] < .5)
            next
        v1.tmp  <-  val1[nx,ny,]
        v2.tmp  <-  val2[nx,ny,]
        if (length(v1.tmp[!is.na(v1.tmp)]) < 20 | length(v2.tmp[!is.na(v2.tmp)]) < 20)
            next

        cor.tmp     <-  cor.test(v1.tmp,v2.tmp)
        p.o[nx,ny]  <-  as.numeric(cor.tmp$p.value)
        cor.o[nx,ny]    <-  as.numeric(cor.tmp$estimate)
    }

    out <-  list(cor=cor.o,p=p.o)
    return(out)
}


#a function to calculate the continuous quantile curve
QuantilCurve    <-  function(val.x,val.y,pro=.95,w.t){
    #val.x is x value ploted
    #val.y is y value ploted
    #w.t is the width of tile of val.x
    #pro is the prob
    #it is a percentage width
    max.x.tmp   <-  max(val.x,na.rm=T)
    min.x.tmp   <-  min(val.x,na.rm=T)
    b.tmp   <-  seq(min.x.tmp,max.x.tmp,
                    w.t*(max.x.tmp-min.x.tmp))

    x.tmp   <-  b.tmp
    y.tmp   <-  b.tmp

    for (i in 1:(length(b.tmp)-1))
    {
        min.tmp <-  b.tmp[i]
        max.tmp <-  b.tmp[i+1]
        x.tmp[i]    <-  (min.tmp+max.tmp)/2.
        v.tmp   <-  val.y[!is.na(val.y) & !is.na(val.y) & (val.x > min.tmp) & (val.x < max.tmp)]
        if (length(v.tmp) == 0)
        {
            y.tmp[i]    <-  NA
        } else
            y.tmp[i]    <-  quantile(v.tmp,probs=pro,na.rm=T)
    }

    out <-  list('x'=x.tmp[1:(length(x.tmp)-1)],
                 'y'=y.tmp[1:(length(y.tmp)-1)])

    return(out)
}
