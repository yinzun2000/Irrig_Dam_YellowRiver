#here is the library only read PNT
#year: 1990
#4 points; 3 irrigation schemes
#name like PNTni1.nc
library('RNetCDF')

ReadPNT  <-  function(id,pft=TRUE){
#id is the name of variable
#irr is irrigation scheme
#pft: either pft or soil
#output will be a [irr,reg,crop,time] matrix
  irr <-  c('ni','ir','fi')
  reg <-  seq(1,4)

  path    <-  '/home/surface4/vyin/data/NewCrop/PNT/PNT'
  t2      <-  '.nc'

  val <-  array(NA,dim=c(3,4,3,365))

  for (i in 1:length(irr))
  for (k in 1:length(reg))
  {
    if (pft)
    {
      nc  <-  open.nc(paste0(path,irr[i],reg[k],t2))
      val[i,k,,] <-  var.get.nc(nc,id,start=c(NA,NA,12,NA),
                                count=c(NA,NA,3,NA))
    } else
    {
      nc  <-  open.nc(paste0(path,irr[i],reg[k],t2))
      val[i,k,,] <-  var.get.nc(nc,id,start=c(NA,NA,4,NA),
                                count=c(NA,NA,3,NA))
    }
    close.nc(nc)
  }

  return(val)
}

ReadPrePNT  <-  function(){
#output will be a [reg,time] matrix
  reg <-  seq(1,4)

  path    <-  '/home/surface4/vyin/data/NewCrop/PNT/PNTni'
  t2      <-  '.nc'

  val <-  array(NA,dim=c(4,365))

  for (i in 1:length(reg))
  {
    nc  <-  open.nc(paste0(path,reg[i],t2))
    val[i,] <-  var.get.nc(nc,'rain') + var.get.nc(nc,'snowf')

    close.nc(nc)
  }

  return(val)
}

