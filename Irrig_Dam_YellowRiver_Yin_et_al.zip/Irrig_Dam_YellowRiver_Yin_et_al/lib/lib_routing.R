#Library of routing
library("RNetCDF")

#create a matrix of index of nx and ny according to given lon, lat
IDX <-  function(idxs,idx.i){

  #find the border
  #---------(idx.x.max,idx.y.max)
  #|                            |
  #|                            |
  #(idx.x.min,idx.y.min)---------
  len <-  length(idx.i)
  idx.min <-  which.min(abs(idxs - idx.i[1]))
  idx.max <-  which.min(abs(idxs - idx.i[len]))

  out <- seq(idx.min,idx.max,1) 

  return(out)
}

#calculate four vectors (x0,y0,x1,y1) for routing direction map plot as
#arrows(x0,y0,x1,y1) 
GetDirectionVector  <-  function(fd,lons,lats,lon.i,lat.i){
  #fd: flow direction map: value from 1-9
  #*****
  #*812*
  #*7*3*
  #*654*
  #*****
  #lons: longitude range of fd
  #lats: latitude range of fd
  #lon.i: longitude range of plots
  #lat.i: latitude range of plots

  idx.x <-  IDX(lons,lon.i)
  idx.y <-  IDX(lats,lat.i)

  x0  <-  array(0,dim=length(lon.i)*length(lat.i))
  y0  <-  array(0,dim=length(lon.i)*length(lat.i))
  x1  <-  array(0,dim=length(lon.i)*length(lat.i))
  y1  <-  array(0,dim=length(lon.i)*length(lat.i))

  t.tmp <-  1
  for (nx in 1:length(lon.i))
  for (ny in 1:length(lat.i))
  {
    x0[t.tmp] <-  lon.i[nx]
    y0[t.tmp] <-  lat.i[ny]

    v.tmp <-  fd[idx.x[nx],idx.y[ny]]

    if (is.na(v.tmp))
      next

    if (v.tmp == 1) #up
    {
      x1[t.tmp] <-  lons[idx.x[nx]]
      y1[t.tmp] <-  lats[idx.y[ny]+1]
    } else if (v.tmp == 2)  #upright
    {
      x1[t.tmp] <-  lons[idx.x[nx]+1]
      y1[t.tmp] <-  lats[idx.y[ny]+1]
    } else if (v.tmp == 3)  #right
    {
      x1[t.tmp] <-  lons[idx.x[nx]+1]
      y1[t.tmp] <-  lats[idx.y[ny]]
    } else if (v.tmp == 4)  #downright
    {
      x1[t.tmp] <-  lons[idx.x[nx]+1]
      y1[t.tmp] <-  lats[idx.y[ny]-1]
    } else if (v.tmp == 5)  #down
    {
      x1[t.tmp] <-  lons[idx.x[nx]]
      y1[t.tmp] <-  lats[idx.y[ny]-1]
    } else if (v.tmp == 6)  #downleft
    {
      x1[t.tmp] <-  lons[idx.x[nx]-1]
      y1[t.tmp] <-  lats[idx.y[ny]-1]
    } else if (v.tmp == 7)  #left
    {
      x1[t.tmp] <-  lons[idx.x[nx]-1]
      y1[t.tmp] <-  lats[idx.y[ny]]
    } else if (v.tmp == 8)  #upleft
    {
      x1[t.tmp] <-  lons[idx.x[nx]-1]
      y1[t.tmp] <-  lats[idx.y[ny]+1]
    } else
    {
      x1[t.tmp] <-  NA
      y1[t.tmp] <-  NA
      x0[t.tmp] <-  NA
      y0[t.tmp] <-  NA
    }

    t.tmp <-  t.tmp+1
  }

#  x0.o  <-  x0[!is.na(x0)]
#  x1.o  <-  x1[!is.na(x1)]
#  y0.o  <-  y0[!is.na(y0)]
#  y1.o  <-  y1[!is.na(y1)]
#
  #out <-  list(X0=x0.o,Y0=y0.o,X1=x1.o,Y1=y1.o)
  out <-  list(X0=x0,Y0=y0,X1=x1,Y1=y1)
  return(out)
}

OutBorder <-  function(x,y,x.r,y.r){
  #x: given lon index
  #y: given lat index
  #x.r: maximum of x
  #y.r: maximum of y
  #out: TRUE/FALSE if (x,y) out of the border
  if ((x < 1) | (x > x.r) | (y < 1) | (y > y.r))
  {
    out = TRUE
  } else
    out = FALSE

  return(out)
}

FindChain <-  function(i,j,idx.x,idx.y,fd){
  #i: x index of start point
  #j: y index of start point
  #idx.x: chosen point of outlet
  #idx.y: chosen point of outlet
  #fd: flow direction matrix
  #out: $nx: x index of flow chain
  #out: $ny: y index of flow chain
  #out: $loc: TRUE/FALSE if the chain end at the outlet
  nx.tmp  <-  i
  ny.tmp  <-  j
  #position of current point
  x.tmp <-  i
  y.tmp <-  j

  len.x <-  dim(fd)[1]
  len.y <-  dim(fd)[2]

  log.tmp <-  TRUE

  while (!((x.tmp == idx.x) & (y.tmp == idx.y)))
  {
    v.tmp <-  fd[x.tmp,y.tmp]
    if(is.na(v.tmp))
    {
      log.tmp <-  FALSE
      break
    }

    if (v.tmp == 1) #up
    {
      x.tmp  <-  x.tmp
      y.tmp  <-  y.tmp+1
    } else if (v.tmp == 2)  #upright
    {
      x.tmp  <-  x.tmp+1
      y.tmp  <-  y.tmp+1
    } else if (v.tmp == 3)  #right
    {
      x.tmp  <-  x.tmp+1
      y.tmp  <-  y.tmp
    } else if (v.tmp == 4)  #downright
    {
      x.tmp  <-  x.tmp+1
      y.tmp  <-  y.tmp-1
    } else if (v.tmp == 5)  #down
    {
      x.tmp  <-  x.tmp
      y.tmp  <-  y.tmp-1
    } else if (v.tmp == 6)  #downleft
    {
      x.tmp  <-  x.tmp-1
      y.tmp  <-  y.tmp-1
    } else if (v.tmp == 7)  #left
    {
      x.tmp  <-  x.tmp-1
      y.tmp  <-  y.tmp
    } else if (v.tmp == 8)  #upleft
    {
      x.tmp  <-  x.tmp-1
      y.tmp  <-  y.tmp+1
    } else
    {
      log.tmp <-  FALSE
      break
    }

    if (OutBorder(x.tmp,y.tmp,len.x,len.y))
    {
      log.tmp <-  FALSE
      break
    }

    #check if it is a loop chain
    l.tmp <-  1
    loop.tmp <-  TRUE
    while (!((nx.tmp[l.tmp] == x.tmp) & (ny.tmp[l.tmp] == y.tmp)))
    {
      if (l.tmp == length(nx.tmp))
      {
        loop.tmp <-  FALSE
        break
      }
      l.tmp <-  l.tmp+1
    }

    #has a loop chain
    if (loop.tmp)
    {
      log.tmp <-  FALSE
      break
    }

    nx.tmp  <-  c(nx.tmp, x.tmp)
    ny.tmp  <-  c(ny.tmp, y.tmp)
  }
  
  out <-  list(nx=nx.tmp,ny=ny.tmp,loc=log.tmp)

  return(out)
}

FindBasin <-  function(lon.i,lat.i,fd,lons,lats,lon.r,lat.r){
  #lon.i: longitude of chosen point
  #lat.i: latitude of chosen point
  #fd: flow direction map
  #lons: longitude range of fd
  #lats: latitude range of fd
  #lon.r: longitude range of interesting region
  #lat.r: latitude range of interesting region
  #first find the corresponding point then calculate a matrix to show the region

  idx.lon <-  IDX(lons,lon.r)
  idx.lat <-  IDX(lats,lat.r)

  #create a sub flow direction matrix
  fd.sub  <-  fd[idx.lon,idx.lat]

  idx.x <-  which.min(abs(lon.r-lon.i))
  idx.y <-  which.min(abs(lat.r-lat.i))

  out <-  array(0,dim=c(length(lon.r),length(lat.r)))

  for(i in 1:length(lon.r))
  for(j in 1:length(lat.r))
  {
    ch.tmp  <-  FindChain(i,j,idx.x,idx.y,fd.sub)

    if(ch.tmp$loc)
    {
      for (l in 1:length(ch.tmp$nx))
        out[ch.tmp$nx[l],ch.tmp$ny[l]] <-  1
    }
  }

  return(out)

}

BasinMinus  <-  function(bsin1,bsin2){
  out <-  bsin1+bsin2
  out[out == 2] <-  0
  return(out)
}

BasinCombine  <-  function(bsin1,bsin2){
  out <-  bsin1+bsin2
  out[out == 2] <-  1
  return(out)
}

ExtractSub  <-  function(val,subr){
  #val is 3D matrix [lon,lat,time]
  #subr is a 3D matrix, [lon,lat,subregion], 0 is no, 1 is yes
  #out is a output of 2 dimension [subregion, time]

  out <-  array(NA,dim=c(dim(subr)[3],dim(val)[3]))

  for (i in 1:dim(subr)[3])
  for (k in 1:dim(val)[3])
    out[i,k]  <-  mean((val[,,k])[subr[,,i] > .5],na.rm=T)

  return(out)
}

ExtractSub2 <-  function(val,subr){
  #val is 3D matrix [lon,lat,time]
  #subr is a 3D matrix, [lon,lat,subregion], 0 is no, 1 is yes
  #out is a output of 2 dimension [subregion, time]
  #the diference between ExtractSub and ExtractSub2 is
  #ExtractSub2 just several independent regions

  out <-  array(NA,dim=c(dim(subr)[3],dim(val)[3]))
  sub.tmp   <-  subr

  for (i in 2:dim(subr)[3])
    sub.tmp[,,i] <-  subr[,,i] - subr[,,i-1]

  for (i in 1:dim(subr)[3])
  for (k in 1:dim(val)[3])
    out[i,k]  <-  mean((val[,,k])[sub.tmp[,,i] > .5],na.rm=T)

  return(out)
}


#read routing data
sys.id  <-  Sys.info()['nodename']
if (grepl('obelix',sys.id)){
            wk.dir  <-  'obelix'
} else if (grepl('lsce',sys.id)){
            wk.dir  <-  'mbp'
} else{
            stop('unknown computer')
}

if (wk.dir == 'mbp')
{
  filei <-  "~/data/mask/routing_revised.nc"
} else
{
  filei <-  "/home/surface4/vyin/data/mask/routing_revised.nc"
}
nci <-  open.nc(filei)
fd  <-  var.get.nc(nci,"trip")
close.nc(nci)
lons  <-  seq(-179.75,179.75,.5)
lats  <-  seq(-89.75,89.75,.5)

lon.r    <-  seq(70.25,135.75,.5)
lat.r    <-  seq(16.25,53.75,.5)
