library(pracma)


DeTrend <-  function(val){
  #val is a matrix: [pro,time series]
  out <-  val
  for (i in 1:dim(val)[1])
    out[i,] <-  detrend(val[i,])

  return(out)
}

DeSeason <-  function(val){
  #val is a matrix: [pro,time series]
  out <-  val


  return(out)
}
