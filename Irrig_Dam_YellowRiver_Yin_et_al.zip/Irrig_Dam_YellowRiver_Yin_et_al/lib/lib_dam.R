CapLvl  <-  function(lvl.t,cap.t,lvl.in){
  #cap.t  <-  lookup table, capacity part
  #lvl.t  <-  lookup table, water level part
  #lvl.in <-  input water level

  out <-  lvl.in

  for (i in 1:length(lvl.in))
  {
    lvl.tmp <-  lvl.in[i]
    tt.tmp  <-  lvl.t - lvl.tmp
    tt.tmp[tt.tmp <= 0]  <-  1e3
    idx.tmp <-  which.min(tt.tmp)

    out[i] <-  cap.t[idx.tmp-1] + (cap.t[idx.tmp] - cap.t[idx.tmp-1])*
      (lvl.tmp - lvl.t[idx.tmp-1])/(lvl.t[idx.tmp] - lvl.t[idx.tmp-1])
  }

  return(out)
}
