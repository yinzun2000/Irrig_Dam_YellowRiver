#Here will try to locate the exact pixel for the site of discharge
#lon.s, lat,s: lon and lat of the site
#dis.s: discharge data of the site

#lons,lats: lon and lat of the simulation
#dis.d: discharge data of the output
#npxl: how far (number of pixels) you want to check at suroundings

#here the method is to check who has the lowest RMSE

library(hydroGOF)

locate4dis  <-  function(lon.s,lat.s,dis.s,lons,lats,dis.d,npxl=2){
#check if the time series has the same length
    if (length(dis.s) != dim(dis.d)[3])
        stop('Time series lenghs are not equal')

#locate the nearest pixel
    nx  <-  which.min(abs(lons-lon.s))
    ny  <-  which.min(abs(lats-lat.s))

#check if the surrouding is out of the border
    if ((nx-npxl) > 0){
    lon.min <- nx-npxl 
    } else {
        lon.min <-  1
    }

    if ((nx+npxl) < length(lons)){
    lon.max <- nx+npxl 
    } else {
        lon.max <-  length(lons)
    }

    if ((ny-npxl) > 0){
    lat.min <- ny-npxl 
    } else {
        lat.min <-  1
    }

    if ((ny+npxl) < length(lats)){
    lat.max <- ny+npxl 
    } else {
        lat.max <-  length(lats)
    }

    v.rmse  <-  9999
    lonlat  <-  c(nx,ny)

    for (i in lon.min:lon.max)
    for (j in lat.min:lat.max)
    {
        rmse.tmp    <-  rmse(dis.s,dis.d[i,j,],na.rm=T)
        #rmse.tmp    <-  cor(dis.s,dis.d[i,j,],use='complete.obs')
        
        if (rmse.tmp < v.rmse)
        {
            v.rmse  <-  rmse.tmp
            lonlat[1]   <-  i
            lonlat[2]   <-  j
        }
    }

    return(lonlat)
}
