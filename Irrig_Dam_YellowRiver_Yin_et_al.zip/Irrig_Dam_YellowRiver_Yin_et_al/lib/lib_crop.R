#here are functions and parameters used for crop related analysis
library('RNetCDF')
library('hydroGOF')
library('spacetime')
library('trend')

ReadMFCCROP <-  function(freq,t.s=NA,t.c=NA){
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ni_05deg_8214Y_CN_'
    t2      <-  '.nc'

    nc      <-  open.nc(paste0(path,freq,t2))
    if (is.na(t.s))
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,12,t.s),count=c(NA,NA,3,t.c))
    } else
    {
        mfc <-  var.get.nc(nc,'maxvegetfrac',start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
    }
    close.nc(nc)

    #calculate the mean LAI
    val <-  apply(mfc,c(1,2,4),sum,na.rm=T)

    return(val)
}

AnnualAverage   <-  function(var,num.y){
#var is the monthly input
#num.y is number of years
    output  <-  array(NA,dim=c(dim(var)[1:2],num.y))
    for (yr in 1:num.y)
        {
            output[,,yr]    <-
                apply(var[,,(12*(yr-1)+1):(12*yr)],c(1,2),mean,na.rm=T)
        }

    return(output)
}

SeasonalAverage <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1:2],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,,mon]   <-  output[,,mon]+var[,,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}


SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SpatialAverage  <-  function(id,input,bmap,n.len){
    #id is the region id for averaging
    #input is the val used as input
    #bmap is the basin map
    #n.len is the length of the time series
    val <-  array(NA,dim=n.len)
    for (i in 1:n.len)
    {
        v.tmp   <-  input[,,i]
        if (id < 0)
            val[i] <-  mean(v.tmp,na.rm=T)
        else
            val[i] <-  mean(v.tmp[bmap == id],na.rm=T)
    }
    return(val)
}

ReadBasinMap    <-  function(){
    filei   <-  'mask/basin.nc'
    bm.nc   <-  open.nc(filei)
    bmap    <-  var.get.nc(bm.nc,'basinmap')
    close.nc(bm.nc)
    return(bmap)
}

ReadMaskMap    <-  function(){
    filei   <-  'mask/mask.nc'
    bm.nc   <-  open.nc(filei)
    cnland  <-  var.get.nc(bm.nc,'mask')
    close.nc(bm.nc)
    return(cnland)
}

D2M <-  function(){
    num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)
    return(output)
}

#~~~~~~~~~~~PARAMETERS and MASKS~~~~~~~~~~~~
id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
bmap    <-  ReadBasinMap()

#mask data to only China region
cnland  <-  ReadMaskMap()
