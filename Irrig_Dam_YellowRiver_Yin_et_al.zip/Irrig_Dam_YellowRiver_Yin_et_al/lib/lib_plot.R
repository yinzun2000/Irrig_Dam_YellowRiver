#some often used settings for plots
library('RNetCDF')
library('fields')
library('mapdata')
library('RColorBrewer')

col.pre <-  colorRampPalette(brewer.pal(9,'Blues'))
col.val <-  colorRampPalette(brewer.pal(9,'YlGnBu'))
col.df  <-  colorRampPalette(brewer.pal(11,'RdBu'))
col.df2 <-  colorRampPalette(brewer.pal(11,'BrBG'))
col.var <-  colorRampPalette(brewer.pal(9,'Greens'))
col.cor <-  colorRampPalette(brewer.pal(11,'RdYlBu'))
col.ind <-  colorRampPalette(brewer.pal(12,'Set3'))
col.st1 <-  colorRampPalette(brewer.pal(9,'Set1'))
col.idk <-  colorRampPalette(brewer.pal(8,'Dark2'))

#read province information and make a province map
source('read/read_frac.R')

#read province map
filei <-  '~/Documents/data/mask/province_01deg_subCN.nc'
nci <-  open.nc(filei)
id  <-  var.get.nc(nci,'ID')
lons.pro  <-  var.get.nc(nci,'lon')
lats.pro  <-  var.get.nc(nci,'lat')
close.nc(nci)

#unit km^2
area.pro  <-  as.matrix(read.table('~/Documents/data/mask/pro_area.txt'))

#a function to create a matrix with province
ProvinceMap <-  function(val,promap,proarea=NA){
  #val: vector with value of each province
  #promap: a 2D matrix; id equals to province
  #proarea: vector of province area
  #out: a 2D matrix filled by val
  out <-  promap
  if (length(proarea) == 1)
  {
    for (i in 1:length(val))
      out[promap == i]  <-  val[i]
  } else
  {
    for (i in 1:length(val))
      out[promap == i]  <-  val[i]/area[i]
  }
  return(out)
}

#prepare for contour plots
#we have lons, lats and a matrix
PreContour  <-  function(lon.i,lat.i,val,sp=.75,deg=2){
  #lons, lats: coordinates
  #val: a matrix
  x.tmp <-  array(NA,dim=length(lon.i)*length(lat.i))
  y.tmp <-  array(NA,dim=length(lon.i)*length(lat.i))
  val.tmp   <-  array(NA,dim=length(lon.i)*length(lat.i))

  p.tmp <-  1
  for (nx in 1:length(lon.i))
  for (ny in 1:length(lat.i))
  {
    x.tmp[p.tmp]  <-  lon.i[nx]
    y.tmp[p.tmp]  <-  lat.i[ny]
    val.tmp[p.tmp]  <-  val[nx,ny]
    p.tmp <-  p.tmp+1
  }

  val.df  <- data.frame(x=x.tmp, y=y.tmp, z=val.tmp)

  val.loess <-  loess(z~x*y, data=val.df,
                      span=sp, degree=deg)

  val.fit <-  expand.grid(list(x=lon.i, y=lat.i))

  z <- predict(val.loess, newdata=val.fit)

  return(z)
}

#make test with a different color border
shadowtext <- function(x, y=NULL, labels, col='black', bg='white',
theta= seq(pi/4, 2*pi, length.out=8), r=0.1, ... ){
    xy <- xy.coords(x,y)
    xo <- r*strwidth('x')
    yo <- r*strheight('x')

    for (i in theta)
        text( xy$x + cos(i)*xo, xy$y + sin(i)*yo, labels, col=bg, ... )

    text(xy$x, xy$y, labels, col=col, ... )
}

lab.m   <-  c('J','F','M','A','M','J','J','A','S','O','N','D')

ErrBar  <-  function(at,mean,sd,wd,frac=0.2, ...){
  #mean: mean value
  #sd: standard deveration value
  #wd: width of the bar
  #frac: how wide the error bar is in fraction of width
  for (i in 1:length(at))
  {
    segments(at[i],mean[i]-sd[i],at[i],mean[i]+sd[i], ...)
    segments(at[i]-frac*wd,mean[i]-sd[i],at[i]+frac*wd,mean[i]-sd[i], ...)
    segments(at[i]-frac*wd,mean[i]+sd[i],at[i]+frac*wd,mean[i]+sd[i], ...)
  }
}
