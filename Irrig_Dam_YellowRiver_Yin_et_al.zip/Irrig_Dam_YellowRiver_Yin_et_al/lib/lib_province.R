library("RNetCDF")

#read province fraction data
if (!exists("frac"))
{
  filei <-  "tab/pro_frac.nc"
  nci   <-  open.nc(filei)
  frac.pro  <-  var.get.nc(nci,"frac")
  close.nc(nci)
}

#This script will convert annual China data in to province based dataset, in txt format
Convert2Province  <-  function(val,area,len.t,frac=frac.pro){
  #val: input value, with same lon*lat as frac, with time length as len.t
  #the val should be grid cell averaged (amount/grid cell area)
  #frac: fraction of provice, lon*lat*id.province
  #area: area of the grid cell [m2]
  #len.t: length of time series

  if (len.t == 1)
  {
    out <-  array(NA,dim=dim(frac)[3])
    for (pro in 1:dim(frac)[3])
      out[pro]  <-  sum(frac[,,pro]*area*val,na.rm=T)
  } else
  {
    out <-  array(NA,dim=c(dim(frac)[3],len.t))

    for (i in 1:len.t)
    for (pro in 1:dim(frac)[3])
      out[pro,i]  <-  sum(frac[,,pro]*area*val[,,i],na.rm=T)
  }

  return(out)
}

ProvinceArea  <-  function(area,frac=frac.pro){
  #frac: fraction of provice, lon*lat*id.province
  #area: area of the grid cell [m2]

  out <-  array(NA,dim=dim(frac)[3])

  for (pro in 1:dim(frac)[3])
    out[pro]  <-  sum(frac[,,pro]*area,na.rm=T)

  return(out)
}

MultiIFC  <-  function(val,irrfrac){
  #irrigation ammount mulitplied by irrigation fraction
  #val: input total simulated irrigation amount
  #irrfrac: irrigation fraction map
  out <-  val
  for (i in 1:dim(val)[3])
    out[,,i]  <-  val[,,i]*irrfrac

  return(out)
}
