
ReadBasinMap    <-  function(){
    filei   <-  'mask/basin.nc'
    bm.nc   <-  open.nc(filei)
    bmap    <-  var.get.nc(bm.nc,'basinmap')
    close.nc(bm.nc)
    return(bmap)
}

ReadMaskMap    <-  function(){
    filei   <-  'mask/mask.nc'
    bm.nc   <-  open.nc(filei)
    cnland  <-  var.get.nc(bm.nc,'mask')
    close.nc(bm.nc)
    return(cnland)
}

id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
bmap    <-  ReadBasinMap()

#mask data to only China region
cnland  <-  ReadMaskMap()
