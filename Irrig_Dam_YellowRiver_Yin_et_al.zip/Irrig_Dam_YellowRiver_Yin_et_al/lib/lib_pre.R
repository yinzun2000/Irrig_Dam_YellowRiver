#here are functions and parameters used for ET analysis
library('RNetCDF')

ReadPRE  <-  function(t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    filei   <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_ni_05deg_8214Y_CN_M.nc'

    nc      <-  open.nc(filei)
    if (is.na(t.s))
    {
      rain <-  var.get.nc(nc,"rain")
      snow <-  var.get.nc(nc,"snowf")
    } else
    {
      rain <-  var.get.nc(nc,"rain",start=c(NA,NA,t.s),count=c(NA,NA,t.c))
      snow <-  var.get.nc(nc,"snowf",start=c(NA,NA,t.s),count=c(NA,NA,t.c))
    }
    close.nc(nc)

    val <-  rain+snow

    return(val)
}

ReadPREL <-  function(freq='M',t.s=NA,t.c=NA){
    f.h <-  '/home/surface4/vyin/data/GSWP3/GSWP3_precipitation_1901_2010_'
    f.t <-  '.nc'

    filei <-  paste0(f.h,freq,f.t)

    x.s <-  501
    x.c <-  132
    y.s <-  213
    y.c <-  76

    nc      <-  open.nc(filei)
    if (is.na(t.s))
    {
      pre  <-  var.get.nc(nc,"pre",start=c(x.s,y.s,NA),count=c(x.c,y.c,NA))
    } else
    {
      pre  <-  var.get.nc(nc,"pre",start=c(x.s,y.s,t.s),count=c(x.c,y.c,t.c))
    }
    close.nc(nc)

    return(pre)
}

ReadMS  <-  function(t.s=NA,t.c=NA){
#id is the name of variable
#irr is irrigation scheme
    filei   <-  '/home/surface4/vyin/data/MSWEP/v2.0/monthly/MSWEP_v2_05deg_7916_CN_M.nc'

    nc      <-  open.nc(filei)
    if (is.na(t.s))
    {
      val   <-  var.get.nc(nc,"precipitation")
    } else
    {
      val   <-  var.get.nc(nc,"precipitation",start=c(NA,NA,t.s),count=c(NA,NA,t.c))
    }
    close.nc(nc)

    return(val)
}

AnnualAverage   <-  function(var,num.y){
#var is the monthly input
#num.y is number of years
    output  <-  array(NA,dim=c(dim(var)[1:2],num.y))
    for (yr in 1:num.y)
        {
            output[,,yr]    <-
                apply(var[,,(12*(yr-1)+1):(12*yr)],c(1,2),mean,na.rm=T)
        }

    return(output)
}

SeasonalAverage <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1:2],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,,mon]   <-  output[,,mon]+var[,,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}


SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SpatialAverage  <-  function(id,input,bmap,n.len){
    #id is the region id for averaging
    #input is the val used as input
    #bmap is the basin map
    #n.len is the length of the time series
    val <-  array(NA,dim=n.len)
    for (i in 1:n.len)
    {
        v.tmp   <-  input[,,i]
        if (id < 0)
            val[i] <-  mean(v.tmp,na.rm=T)
        else
            val[i] <-  mean(v.tmp[bmap == id],na.rm=T)
    }
    return(val)
}

ReadBasinMap    <-  function(){
    filei   <-  'mask/basin.nc'
    bm.nc   <-  open.nc(filei)
    bmap    <-  var.get.nc(bm.nc,'basinmap')
    close.nc(bm.nc)
    return(bmap)
}

ReadMaskMap    <-  function(){
    filei   <-  'mask/mask.nc'
    bm.nc   <-  open.nc(filei)
    cnland  <-  var.get.nc(bm.nc,'mask')
    close.nc(bm.nc)
    return(cnland)
}

D2M <-  function(){
    num.day <-  c(31,28,31,30,31,30,31,31,30,31,30,31)
    return(num.day)
}

ReadGLEAM   <-  function(id){
    t.s <-  25
    t.c <-  312
    path    <-  '/home/surface4/vyin/data/gleam/v3.1/a/'
    filet   <-  '_GLEAM_v31a_8015_05deg_CN_M.nc'

    nc.gl   <-  open.nc(paste0(path,id,filet))
    v.tmp   <-
    var.get.nc(nc.gl,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))
    close.nc(nc.gl)
    #the original format is (lat,lon,time). should change to
    #(lon,lat,time)
    val     <-
        array(0,dim=c(dim(v.tmp)[2],dim(v.tmp)[1],dim(v.tmp)[3]))
    for (i in 1:dim(v.tmp)[3])
        val[,,i]    <-  t(v.tmp[,,i])

    return(val)
}

ReadMPI <-  function(id,t.s=1,t.c=312){
    # l is the coefficient to change the unit from MJ.m-2.d-1 to mm.d-1
    l   <-  1e6/(3600*24*28.94)
    filei   <-  '/home/surface4/vyin/data/MPI/ET/ET_MPI_05deg_8211_CN_M.nc'

    nc.mp   <-  open.nc(filei)
    val <-  var.get.nc(nc.mp,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))*l
    close.nc(nc.mp)

    return(val)
}

#~~~~~~~~~~~PARAMETERS and MASKS~~~~~~~~~~~~
id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
bmap    <-  ReadBasinMap()

#mask data to only China region
cnland  <-  ReadMaskMap()
