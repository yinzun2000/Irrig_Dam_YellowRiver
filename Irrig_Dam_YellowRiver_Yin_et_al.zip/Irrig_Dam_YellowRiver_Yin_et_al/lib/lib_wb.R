library('RNetCDF')

## the depth of the top soil layer
#topdep  <-  9.77517107e-4
## number of soil layers
#nlay    <-  11
##calculate the depth of the 11 nodes dep.node
#dep.node    <-  array(0,dim=nlay)
## bottom of each layer
#dep.bot     <-  array(0,dim=nlay)
## depth of each soil layer
#dep.lay <-  array(0,dim=nlay)
#
#for (i in 2:nlay)
#{
#    dep.node[i] <-  topdep*2.0*(2**(i-1)-1)
#    dep.bot[i-1]    <-  mean(dep.node[(i-1):i])
#}
#
#dep.bot[nlay]   <-  dep.node[nlay]
#
#dep.lay[2:nlay] <-  dep.bot[1:(nlay-1)]
#dep.lay <-  dep.bot - dep.lay

#------------function------------
SpatialAverage  <-  function(id,input,bmap,n.len){
#id is the region id for averaging
#input is the val used as input
#bmap is the basin map
    val <-  array(NA,dim=n.len)
    for (i in 1:n.len)
    {
        v.tmp   <-  input[,,i]
        if (id < 0)
            val[i] <-  mean(v.tmp,na.rm=T)
        else
            val[i] <-  mean(v.tmp[bmap == id],na.rm=T)
    }

    return(val)
}

ReadORC <-  function(id,freq,irr,t.s=NA,t.c=NA,dim=3){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_'
    t1      <-  '_05deg_8214Y_CN_'
    t2      <-  '.nc'

    nc      <-  open.nc(paste0(path,irr,t1,freq,t2))
    if (is.na(t.s))
    {
        if (dim == 3) 
        {
          val <-  var.get.nc(nc,id)
        } else if (dim == 4)
        {
          val.tmp <-  var.get.nc(nc,id)
          val <-  apply(val.tmp,c(1,2,4),sum,na.rm=T)
        }

    } else
    {
        if (dim == 3)
        {
            val     <-  var.get.nc(nc,id,start=c(NA,NA,t.s),count=c(NA,NA,t.c))
        } else if (dim == 4)
        {
          val.tmp <-  var.get.nc(nc,id,start=c(NA,NA,NA,t.s),count=c(NA,NA,NA,t.c))
          val <-  apply(val.tmp,c(1,2,4),sum,na.rm=T)
        }
    }

    close.nc(nc)
    return(val)
}

ReadPre <-  function(freq,irr,t.s=NA,t.c=NA,dim=3){
#id is the name of variable
#irr is irrigation scheme
    path    <-  '/home/surface4/vyin/data/NewCrop/NCRR_GSWP3_'
    t1      <-  '_05deg_8214Y_CN_'
    t2      <-  '.nc'

    nc      <-  open.nc(paste0(path,irr,t1,freq,t2))

    if (is.na(t.s))
    {
        rain  <-  var.get.nc(nc,'rain')
        snow  <-  var.get.nc(nc,'snowf')
    } else
    {
        rain  <-  var.get.nc(nc,'rain')
        snow  <-  var.get.nc(nc,'snowf')
    }

    close.nc(nc)

    return(rain+snow)
}

AnnualAverage   <-  function(var,num.y){
#var is the monthly input
#num.y is number of years 
    output  <-  array(NA,dim=c(dim(var)[1:2],num.y))
    for (yr in 1:num.y)
    {
        output[,,yr]    <-
        apply(var[,,(12*(yr-1)+1):(12*yr)],c(1,2),mean,na.rm=T)
    }
    return(output)    
}

SeasonalAverage <-  function(var,num.y){
    output  <-  array(0,dim=c(dim(var)[1:2],12))
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[,,mon]   <-  output[,,mon]+var[,,12*(yr-1)+mon]

    output  <-  output/num.y
    return(output)
}

SeasonalAverage1D   <-  function(var,num.y){
    output  <-  array(0,dim=12)
    for (yr in 1:num.y)
    for (mon in 1:12)
        output[mon] <-  output[mon]+var[12*(yr-1)+mon]

    output  <-  output/num.y

    return(output)
}

ReadBasinMap    <-  function(){
    filei   <-  'mask/basin.nc'
    bm.nc   <-  open.nc(filei)
    bmap    <-  var.get.nc(bm.nc,'basinmap')
    close.nc(bm.nc)
    return(bmap)
}

ReadMaskMap    <-  function(){
    filei   <-  'mask/mask.nc'
    bm.nc   <-  open.nc(filei)
    cnland  <-  var.get.nc(bm.nc,'mask')
    close.nc(bm.nc)
    return(cnland)
}

#~~~~~~~~~~~PARAMETERS and MASKS~~~~~~~~~~~~
id.yz   <-  13
id.yl   <-  27
id.cn   <-  -1

lons    <-  seq(70.25,135.75,.5)
lats    <-  seq(16.25,53.75,.5)

#read basinmap
bmap    <-  ReadBasinMap()

#mask data to only China region
cnland  <-  ReadMaskMap()

#read the 27-layer scheme values
dep.lay <-  as.matrix(read.table("tab/dep.lay"))
dep.node<-  as.matrix(read.table("tab/dep.node"))
# number of soil layers
nlay    <-  length(dep.lay)
# bottom of each layer
dep.bot     <-  dep.lay

for (i in 2:nlay)
    dep.bot[i]  <-  dep.bot[i-1]+dep.lay[i]
